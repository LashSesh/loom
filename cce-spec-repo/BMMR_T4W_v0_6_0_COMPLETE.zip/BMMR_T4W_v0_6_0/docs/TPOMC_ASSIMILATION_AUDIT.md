# TPOMC-Assimilationsaudit

## Gesamturteil

TPOMC verändert das frühere Urteil deutlich:

- **vorher:** Cash_ZNS war ein tragfähiger Architekturkeim ohne eigene
  thermodynamische Knochen;
- **jetzt:** TPOMC + PSP + PhaseMatrix liefern ein weitgehend typisiertes,
  deterministisches und auditierbares kybernetisches Exoskelett;
- **weiterhin offen:** eine physische Thermodynamik mit Einheiten,
  Konstitutivgesetzen, Wärmebädern, Entropieproduktion und Kalibrierung.

Der richtige Status ist daher nicht „fertige Physik“, sondern
**ausführbare formale Systemthermodynamik mit offenem physischem Adapter**.

## Claim-Matrix der Primärquelle

| TPOMC-Element | Urteil | v0.6-Vertrag |
|---|---|---|
| kanonischer Zustand `(G,z,Π,μ,H,RD)` | übernehmen | typisierter Zustand, unveränderlicher Run Descriptor, Trace und Provenienz |
| partielle getypte Operatoren | übernehmen | nur registrierte Domäne/Kodomäne und Admissibility |
| SI1–SI9 und Proof-Status | übernehmen | Modellfirewall, Replay, keine versteckten IO-Kanäle, offene Pflichten blockieren Commit |
| Constraint-Lattice und Hysterese | übernehmen | monotone Schnitte; Relaxation getrennt; On/Off-Schwellen |
| Stitcher/Mirror als Adjunktion | begrenzt übernehmen | Adjunktion ist Konsistenz, nicht Beobachtbarkeit |
| „Adjunktion ⇒ Anti-Stealth“ | korrigieren | positive untere Frame-/Observabilitätsschranke oder registrierter Linksinversenfehler nötig |
| Mandorla `A∩B` | übernehmen | gemessener Schnitt, positive Masse und Konditionierung |
| „Reguläre Werte ⇒ nichttrivialer Schnitt“ | widerlegt | reguläre Superlevelmengen können leer/disjunkt sein |
| Banach-Fixpunkt unter echter Kontraktion | übernehmen | Vollständigkeit, Selbstabbildung und `L<1` explizit zertifizieren |
| Identitätsdämpfung repariert `L_T>1` | widerlegt | `β+(1-β)L_T ≥ 1` für jedes `L_T≥1`; v0.6 nutzt Energieabstieg/Backtracking |
| schrumpfende Feasible Sets ⇒ Konzentration | ergänzen | realisierter bzw. probabilistischer Zustand muss in jedem Schritt im Support liegen |
| endliche topologische Kondensation aus Durchmesser | widerlegt | skalierte Kreise/Annuli behalten Löcher bei jedem endlichen Schritt |
| Topologiebeobachter | übernehmen | exakte und auflösungsabhängige Signatur getrennt; endliche Closure nur gemessen |
| `min(d_box,d_PR)` sei konservativ | korrigieren | `max` ist konservativ, wenn beide Zeugen Last tragen; Nullkovarianz erhält Konvention 0 |
| Interventions-„Energie“ | umbenennen | Aktionsnorm/Kostenfunktion, solange keine Joule-Semantik vorliegt |
| TIC als Fixpunkt | übernehmen als Softwarebegriff | stabiler Fixpunkt ist kein physikalischer Zeitkristall |
| Butterfly-Leverage-Bound | quarantänisieren | heuristisch/model-specific; ohne empirisch identifiziertes Übergangsmodell kein Produktbeweis |
| Earth-truth decrement | übernehmen | keine Verdichtung ohne extern gemessene Verbesserung |
| Fail-closed / Evidence / Manifest | übernehmen | direkter Bestandteil von T4W-Lauf und Paket |

## Vier ausführbare Gegenzeugen

### 1. Adjunktion ohne Beobachtbarkeit

`S=0` und `M=0` erfüllen `M=S*`. Dennoch verschwindet jedes Signal im Kern.
Deshalb prüft v0.6 zusätzlich einen positiven unteren Frame-Bound von `S*S`.

### 2. Leere Mandorla

Auf `[0,1]` seien `U(x)=x` und `V(x)=1-x`. Für genügend hohe reguläre
Schwellen sind beide Superlevelmengen nichtleer, ihr Schnitt aber leer.
Kompaktheit und Regularität erzeugen keine Überlappung.

### 3. Expansive Dämpfung

Für `Tβ=(1-β)T+βId` gilt allgemein nur

```text
Lip(Tβ) ≤ β + (1-β)L_T.
```

Bei `L_T=1.2, β=0.5` ergibt sich 1.1, nicht `<1`. Identitätsmischung kann
eine bereits kontraktive Abbildung glätten, aber Expansion nicht allgemein
heilen.

### 4. Schrumpfende Löcher

Die Kreisfolge `Ω_t={x: ||x||=2^{-t}}` besitzt Durchmesser gegen null und
Schnitt `{0}` im Abschluss, aber Betti-Signatur `(1,1)` für jeden endlichen
Schritt. Deshalb darf endliche topologische Closure nicht aus metrischer
Schrumpfung abgeleitet werden.

## Assimilation der Stützquellen

### PSP

Liefert die tragende Verfassung: Typen, Operatorregister, Run Descriptor,
Kanonisierung, Statusdisziplin, Modellfirewall, Replay und
Beweisverpflichtungen. Das ist die Hauptstatik des Workbody.

### PhaseMatrix-Hivemind

Liefert die Fliesen: PhaseCell, Pool, Cluster, Morphology, ConvergenceField,
bounded feedback, Dissolution mit Trace-Erhalt und Boundary-Gates. Die
Fliesen werden in v0.6 physikalisch neutral als Feldzellen verwendet, nicht
als Menschen oder Organisationen.

### nxalien

Liefert einen normierten Kontext-Hypercube und ein ausführbares HDAG. Die acht
Koordinaten sind Metadaten-/Kontextachsen; sie werden nicht als physische
Dimensionen ausgegeben. T4W verwendet stattdessen genau vier binäre,
beobachtbare Makroachsen.

### Seraphic Calibration

Liefert Benchmark-Feedback, Gain Scheduling und den Wechsel zwischen lokalen
Kontraktionsregionen. Die Akzeptanz von Qualität/Stabilität/Effizienz beweist
jedoch keine Kontraktion; v0.6 verlangt zusätzlich Speicherabstieg oder ein
eigenes Stabilitätszertifikat.

### Hypertorus Toolkit

Liefert Phasenuhren, Fenster und deterministische Scheduler. Irrationale
Frequenzverhältnisse erzeugen im kontinuierlichen Ideal dichte Bahnen; bei
endlicher Numerik werden daraus keine kollisionsfreien oder kryptographisch
zufälligen Sequenzen. T4W nutzt sie nur als Scheduler-Vertrag.

## Was „Thermodynamik“ jetzt exakt bedeutet

### G0 – Analogie

Wörter wie Energie, Temperatur oder Phase ohne Einheiten, Bilanz oder
Dynamik. Nicht ausreichend.

### G1 – operative Systemthermodynamik (in v0.6 erreicht)

- extensiver, konservierter Träger;
- nichtkonservierter Ordnungsparameter;
- bistabiles Speicherfunktional;
- Kopplungs-/Grenzflächenkosten;
- Drive-Arbeit und Dissipationsbilanz;
- monotoner passiver Relaxationspfad;
- klar beobachtete Phasengrenzen;
- deterministischer Trace und Replay.

### G2 – physische Thermodynamik (offen)

- Energien in Joule und Temperatur in Kelvin;
- definiertes System, Bad und Grenzfläche;
- kalibrierte Wärme-/Arbeitsmessung;
- lokale Detailbilanz oder spezifizierte Nichtgleichgewichtsdynamik;
- Entropieproduktion und Fluktuationstests;
- experimentelle Material- bzw. Hardwareparameter.

## Ontologischer Rest

Der Workbody kann Reichtum als operative Transformationsressource und
Information als kausalen Policy-Rohstoff verarbeiten. Er kann daraus jedoch
nicht allein eine physische Substanz machen. Eine Zuordnung
`Nat → k_B T·Nat` ist nur in einem konkreten physikalischen Feedbacksystem
zulässig; eine Zuordnung `Nat → Geldrendite` bleibt der getrennte
log-optimale BMMR-Vertrag. Diese drei Einheiten dürfen nicht ineinander
„gewaschen“ werden.

