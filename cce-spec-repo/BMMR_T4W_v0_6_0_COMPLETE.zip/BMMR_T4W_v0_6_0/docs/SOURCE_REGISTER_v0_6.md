# Quellenregister v0.6

Alle Dateien wurden aus den im Arbeitsraum bereitgestellten Kopien gelesen.
Die SHA-256-Digests binden genau die geprüfte Fassung.

| Rolle | Datei | Seiten | SHA-256 |
|---|---|---:|---|
| Primärquelle | `TPOMC_bySebastianKlemm_v1.0.pdf` | 105 | `b50bb423db95527c3bb3a28e652c29609e3fccffd8e07354458ef8b580cc7338` |
| formale Verfassung | `PSP_Formal_Specification_v1.0.0_Sebastian_Klemm(2).pdf` | 101 | `5786f0053b5a18726bbadb1b3ce9bb719d190c401fe2beae2c4a6ecb0d98fddb` |
| Zellen-/Feldsubstrat | `PHASEMATRIX_HIVEMIND_03(1).pdf` | 25 | `ca3c4e120de731620bdbcd45db49e8f8a941ba8300bf7fd87b6ccba5c79de0cc` |
| Kontext-Hypercube/HDAG | `nxalien_specification(2).pdf` | 16 | `fccc1112e6825adf8ec4c009ea9cb5ec66cf147480343efa3adeabc74992a8af` |
| Kalibrierung | `SeraphicCalibrationModule(2).pdf` | 5 | `3cc9147a70c7e090815c27419d4bc0c27fa81b20b5f28d653705a5c03e5ffcc6` |
| Phasenuhr/Scheduler | `HypertorusToolkit(2).pdf` | 3 | `bf62c567b1d5d3892ef3869ac529abdb890cad0169f4870676fe1354f1f72add` |

## Prüfverfahren

- PDF-Metadaten und Seitenzahl mit Poppler;
- Layout-erhaltende Textextraktion;
- visuelle Rasterprüfung von Titel-, Definitionen-, Beweis- und
  Implementierungsseiten;
- Vergleich load-bearing Aussagen mit Primärliteratur;
- Übersetzung tragfähiger Aussagen in Code, Tests und negative Zeugen;
- keine Autoritätsübernahme aus dem Quellennamen.

## Externe mathematisch-physikalische Primärquellen

- J. W. Cahn, J. E. Hilliard, *Free Energy of a Nonuniform System. I*,
  J. Chem. Phys. 28, 258–267 (1958), DOI
  [10.1063/1.1744102](https://doi.org/10.1063/1.1744102).
- S. M. Allen, J. W. Cahn, *A microscopic theory for antiphase boundary
  motion*, Acta Metallurgica 27, 1085–1095 (1979), DOI
  [10.1016/0001-6160(79)90196-2](https://doi.org/10.1016/0001-6160(79)90196-2).
- R. Landauer, *Irreversibility and Heat Generation in the Computing
  Process*, IBM J. Res. Dev. 5, 183–191 (1961), DOI
  [10.1147/rd.53.0183](https://doi.org/10.1147/rd.53.0183).
- T. Sagawa, M. Ueda, *Generalized Jarzynski Equality under Nonequilibrium
  Feedback Control*, Phys. Rev. Lett. 104, 090602 (2010), DOI
  [10.1103/PhysRevLett.104.090602](https://doi.org/10.1103/PhysRevLett.104.090602).
- U. Seifert, *Entropy Production along a Stochastic Trajectory*, Phys. Rev.
  Lett. 95, 040602 (2005), DOI
  [10.1103/PhysRevLett.95.040602](https://doi.org/10.1103/PhysRevLett.95.040602).
- D. Cohen-Steiner, H. Edelsbrunner, J. Harer, *Stability of Persistence
  Diagrams*, Discrete Comput. Geom. 37, 103–120 (2007), DOI
  [10.1007/s00454-006-1276-5](https://doi.org/10.1007/s00454-006-1276-5).
- A. Bérut et al., *Experimental verification of Landauer's principle*,
  Nature 483, 187–189 (2012), DOI
  [10.1038/nature10872](https://doi.org/10.1038/nature10872).

