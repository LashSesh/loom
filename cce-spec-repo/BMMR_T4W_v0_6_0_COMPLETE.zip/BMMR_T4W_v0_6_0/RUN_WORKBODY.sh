#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

PYTHONPATH=src python3 -m bmmr.workbody_lab --output output/t4w_v0_6
PYTHONPATH=src python3 -m unittest discover -s tests -v

