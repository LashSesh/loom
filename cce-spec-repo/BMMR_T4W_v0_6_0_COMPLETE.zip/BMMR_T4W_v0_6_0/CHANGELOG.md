# Changelog

## 0.6.0 – Thermodynamic Tesseract Workbody

- TPOMC als Primärquelle gebunden und Claim-für-Claim geprüft;
- vier load-bearing TPOMC-Schlüsse mit ausführbaren Gegenzeugen korrigiert;
- `Q₄` als 16-Kammer-Moduskörper mit vollständigem cubicalen Zellbestand;
- orientierte Randabbildung mit maschinell geprüftem `∂² = 0`;
- vier Makroachsen: Closure, Mobilität, Ordnung, Informationsaktivität;
- diagonale Moduswechsel in primitive Facettenübergänge zerlegt;
- bistabiles, gekoppeltes Phasenfeld mit Thermostat-/Drive-Steuerung;
- monotone Gradientenrelaxation mit expliziter Speicherbilanz;
- phasengesteuerter, mengenbewahrender Ressourcentransport;
- G0/G1/G2-Semantikfirewall für thermodynamische Begriffe;
- Wealth-Phase-Bridge auf den Tesseraktmodus;
- deterministischer Referenzlauf, Run Descriptor und Hashmanifest;
- 91 automatisierte Tests.
