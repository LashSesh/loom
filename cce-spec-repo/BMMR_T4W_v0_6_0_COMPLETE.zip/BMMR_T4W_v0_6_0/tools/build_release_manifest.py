"""Build a deterministic SHA-256 manifest for a BMMR-T4W release tree."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path


MANIFEST_NAME = "MANIFEST.sha256.json"


def digest_file(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def build_manifest(root: Path) -> dict[str, object]:
    files = sorted(
        path
        for path in root.rglob("*")
        if path.is_file() and path.name != MANIFEST_NAME
    )
    return {
        "schema": "bmmr.t4w.release-manifest.v1",
        "version": "0.6.0",
        "files": {
            path.relative_to(root).as_posix(): digest_file(path)
            for path in files
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = build_manifest(root)
    output = root / MANIFEST_NAME
    output.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"{len(manifest['files'])} files -> {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
