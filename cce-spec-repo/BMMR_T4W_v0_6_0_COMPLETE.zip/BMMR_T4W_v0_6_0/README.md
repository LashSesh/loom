# BMMR-T4W v0.6.0

Eigenständiger Forschungs- und Implementierungskorpus für einen
**Thermodynamischen Tesserakt-Workbody**: einen vierfach gegateten,
deterministischen Phasen-, Ressourcen- und Informationskörper für den BMMR.

Primärquelle dieser Iteration ist `TPOMC_bySebastianKlemm_v1.0.pdf`. PSP,
PhaseMatrix-Hivemind, nxalien, Seraphic Calibration und Hypertorus Toolkit
dienen als Stütz- und Gegenprüfmaterial. Der Korpus übernimmt keine Aussage
aufgrund ihres Namens, sondern nur als Typ, Operator, Invariante, Messgröße,
Beweisverpflichtung oder negativer Zeuge.

## Ergebnis in einem Satz

Aus dem bisherigen Architekturkeim ist ein ausführbares formales
Workbody-Skelett geworden: Ein cubicaler 4-Körper ordnet Makromodi, ein
bistabiles Phasenfeld öffnet und schließt Transport, ein konservierter Träger
fließt entlang gemessener Potentialdifferenzen, und jede externe Modulation
wird gegen Speicherung und Dissipation bilanziert.

Das ist **G1-Systemthermodynamik**. Eine physikalische G2-Thermodynamik würde
zusätzlich Joule, Kelvin, Wärmebäder, lokale Detailbilanz, kalibrierte
Materialparameter und Messdaten verlangen.

## Der Tesserakt ist nicht dekorativ

Der Makromodus ist

```text
b = (closure, mobility, order, information) ∈ {0,1}⁴.
```

Damit besitzt der Workbody exakt:

- 16 Moduskammern;
- 32 primitive Übergangskanten;
- 24 Quadratflächen;
- 8 dreidimensionale Zellen;
- einen vierdimensionalen Körper.

Ein diagonaler Zustandswechsel wird in Hamming-Distanz-1-Übergänge zerlegt.
Jede überschrittene Grenze erhält dadurch einen eigenen Kausal- und
Evidenzpunkt. Die implementierte cubicale Randabbildung erfüllt `∂² = 0`.

## Thermostat- und Phasenfeldkern

Jede Feldfliese besitzt eine mobile Phasenfraktion `q ∈ [0,1]`. Die beiden
terminalen Zustände entsprechen einer gesperrten und einer mobilen Phase. Das
dimensionlose lokale Speicherfunktional lautet

```text
f(q) = A q²(1-q)² + Δg(θ,u) q.
```

`A` erzeugt die Barriere, `θ` moduliert die thermische Steuerkoordinate und
`u` einen externen Drive. Kopplungsterme bestrafen Phasensprünge zwischen
Nachbarfliesen. Ein deterministischer, projizierter Gradientenlauf akzeptiert
nur nicht-steigende freie Speicherenergie.

Die mobile Phase moduliert anschließend die Leitfähigkeit eines getrennten,
konservierten Trägers. Der Transport bewahrt die Gesamtmenge exakt und senkt
sein quadratisches Speicherfunktional. Dauerndes Ping-Pong ist deshalb kein
kostenloses Gleichgewicht: Persistente Oszillation erfordert externen Drive
und wird als Nichtgleichgewichtsbetrieb bilanziert.

## TPOMC: übernommen und repariert

Tragfähig übernommen wurden Zustands- und Operatortypisierung, Run Descriptor,
Proof-Status, Constraint-Lattice, Hysterese, Gate/Evidence, Fail-Closed und
Replay. Vier load-bearing Aussagen wurden verschärft:

1. Adjunktion allein impliziert keine Beobachtbarkeit. Erforderlich ist ein
   positiver unterer Frame-/Observabilitätswert.
2. Reguläre Superlevelmengen können disjunkt sein. Eine Mandorla benötigt
   gemessene positive Schnittmasse und Konditionierung.
3. `(1-β)T + β Id` macht eine expansive Abbildung nicht kontraktiv. Der
   allgemeine Bound bleibt bei `L_T ≥ 1` mindestens eins.
4. Schrumpfender Durchmesser impliziert keine endliche exakte
   Topologieauflösung. Endliche Closure wird nur durch gemessene Signatur,
   registrierte Auflösung oder einen diskreten cubicalen Collapse akzeptiert.

Die vollständige Claim-für-Claim-Prüfung steht in
`docs/TPOMC_ASSIMILATION_AUDIT.md`.

## Referenzlauf

```bash
./RUN_WORKBODY.sh
```

Oder direkt:

```bash
PYTHONPATH=src python3 -m bmmr.workbody_lab --output output/t4w_v0_6
PYTHONPATH=src python3 -m unittest discover -s tests -v
```

Der synthetische Lauf zeigt:

- cubicale Topologie: `16/32/24/8/1`, `∂²=0`;
- Phasenmodus: `1010 → 1110 → 1111`;
- mittlere mobile Phase: `0.050000 → 0.946574`;
- konservierte Ressource: `1.000000 → 1.000000`;
- Ressourcenspeicher: `0.410000 → 0.125000`;
- Wealth-Bridge: Basis `1111`, Stress `0010`;
- 91 Unit-, Integrations- und Negativtests.

Die Zahlen sind Semantik- und Invariantenzeugen, keine Markt- oder
Profitabilitätsevidenz.

## Laufartefakte

`output/t4w_v0_6/` enthält:

- `REPORT.md` – kondensierter Befund;
- `tesseract_topology.json` – Zellen, Euler-Charakteristik und `∂²`;
- `phase_field.json` – Drive, Relaxation, Transport und Bilanzen;
- `tpomc_repairs.json` – positive und negative Beweiszeugen;
- `wealth_tesseract.json` – Abbildung der Wealth-Phase auf `Q₄`;
- `run_descriptor.json` – deterministische Laufidentität;
- `MANIFEST.sha256.json` – Hashbindung aller Artefakte.

## Produktgrenze

Der Workbody ist als deterministischer Simulator und Regelkern real. Noch
offen sind G2-Kalibrierung, stochastische lokale Detailbilanz, physische
Wärme-/Arbeitsmessung, empirische Marktparameter, kausale historische Daten,
Orderbuchausführung, Paper-/Shadow-Betrieb und eine produktspezifische
Abnahme. Ohne diese Schichten ist er weder eine neue Materiephase noch ein
Geldautomat.
