from __future__ import annotations

from math import log
from pathlib import Path
import json
import tempfile
import unittest

from bmmr.core import ReactorConfig
from bmmr.dataset import load_dataset
from bmmr.experiment import run_experiment
from bmmr.information_phase import InformationBudget, mutual_information_nats
from bmmr.lab import full_run
from bmmr.operation_algebra import (
    ResourceOperation,
    additive_operation,
    certify_prefix_viability,
    commutation_certificate,
    reference_operation_witness,
    structurally_independent,
)
from bmmr.wealth_phase import (
    Claim,
    ConversionEdge,
    ConversionNetwork,
    Liability,
    WealthPhaseThresholds,
    WealthState,
    analyze_anisotropy,
    detect_phase_transition,
    evaluate_wealth_phase,
    load_wealth_phase,
    value_wealth_state,
    wealth_phase_artifact,
)


ROOT = Path(__file__).resolve().parents[1]
WEALTH_DEMO = ROOT / "examples" / "demo_wealth_phase.json"
MARKET_DEMO = ROOT / "examples" / "demo_market.csv"


def edge(
    source: str,
    target: str,
    rate: float,
    route: str,
    latency: float = 10.0,
    capacity: float = 1000.0,
    weight: float = 1.0,
) -> ConversionEdge:
    return ConversionEdge(
        source,
        target,
        rate,
        0.01,
        0.02,
        capacity,
        latency,
        weight,
        route,
    )


class InformationPhaseTest(unittest.TestCase):
    def test_independent_variables_have_zero_mutual_information(self) -> None:
        self.assertAlmostEqual(
            mutual_information_nats(((0.25, 0.25), (0.25, 0.25))),
            0.0,
        )

    def test_perfect_binary_side_information_has_log_two_nats(self) -> None:
        self.assertAlmostEqual(
            mutual_information_nats(((0.5, 0.0), (0.0, 0.5))),
            log(2.0),
        )

    def test_noncausal_information_has_no_growth_budget(self) -> None:
        budget = InformationBudget(log(2.0), causal_available=False)
        self.assertEqual(budget.gross_log_growth_bound, 0.0)
        self.assertEqual(budget.usable_log_growth_bound, 0.0)

    def test_drag_can_only_reduce_the_information_bound(self) -> None:
        budget = InformationBudget(
            0.3,
            estimation_penalty_nats=0.05,
            execution_drag_nats=0.04,
            latency_drag_nats=0.03,
            model_class_penalty_nats=0.02,
        )
        self.assertAlmostEqual(budget.usable_log_growth_bound, 0.16)
        self.assertLessEqual(
            budget.usable_log_growth_bound,
            budget.gross_log_growth_bound,
        )


class WealthValuationTest(unittest.TestCase):
    def test_multihop_path_liquidates_a_claim(self) -> None:
        network = ConversionNetwork(
            (
                edge("BTC", "USDC", 50000.0, "a", capacity=1.0),
                edge("USDC", "EUR", 0.99, "b"),
            )
        )
        state = WealthState("EUR", (Claim("BTC", 0.001),))
        report = value_wealth_state(state, network, 100.0, 0.0)
        self.assertTrue(report.liquid)
        self.assertGreater(report.robust_horizon_value, 40.0)

    def test_robust_value_never_exceeds_nominal_value(self) -> None:
        network = ConversionNetwork((edge("BTC", "EUR", 50000.0, "a"),))
        state = WealthState("EUR", (Claim("BTC", 0.001),))
        report = value_wealth_state(state, network, 100.0, 0.0)
        self.assertLessEqual(
            report.robust_horizon_value,
            report.nominal_horizon_value,
        )

    def test_uncovered_due_liability_prevents_accounting_closure(self) -> None:
        state = WealthState(
            "EUR",
            (Claim("EUR", 100.0),),
            (Liability("BTC", 0.001, due_delay_ms=10.0),),
        )
        report = value_wealth_state(state, ConversionNetwork(()), 100.0, 50.0)
        self.assertFalse(report.accounting_closed)
        self.assertFalse(report.solvent)
        self.assertEqual(report.uncovered_liabilities, ("BTC",))

    def test_horizon_separates_pending_from_immediate_wealth(self) -> None:
        network = ConversionNetwork((edge("USDC", "EUR", 1.0, "a"),))
        state = WealthState(
            "EUR",
            (Claim("USDC", 20.0, settled=False, settlement_delay_ms=50.0),),
        )
        report = value_wealth_state(state, network, 100.0, 0.0)
        self.assertEqual(report.robust_immediate_value, 0.0)
        self.assertGreater(report.robust_horizon_value, 0.0)

    def test_claim_beyond_horizon_is_visible_as_locked(self) -> None:
        state = WealthState(
            "EUR",
            (
                Claim(
                    "EUR",
                    20.0,
                    settled=False,
                    settlement_delay_ms=200.0,
                ),
            ),
        )
        report = value_wealth_state(state, ConversionNetwork(()), 100.0, 0.0)
        self.assertFalse(report.liquid)
        self.assertEqual(report.unliquidatable_assets, ("EUR",))

    def test_partial_route_capacity_does_not_claim_liquidation_closure(self) -> None:
        network = ConversionNetwork(
            (edge("BTC", "EUR", 50000.0, "a", capacity=0.001),)
        )
        state = WealthState("EUR", (Claim("BTC", 0.002),))
        report = value_wealth_state(state, network, 100.0, 0.0)
        self.assertGreater(report.robust_horizon_value, 0.0)
        self.assertFalse(report.liquid)
        self.assertEqual(report.unliquidatable_assets, ("BTC",))

    def test_liability_capacity_is_compared_in_source_units(self) -> None:
        network = ConversionNetwork(
            (edge("EUR", "BTC", 0.01, "a", capacity=50.0),)
        )
        state = WealthState(
            "EUR",
            (Claim("EUR", 200.0),),
            (Liability("BTC", 1.0, due_delay_ms=0.0),),
        )
        report = value_wealth_state(state, network, 100.0, 0.0)
        self.assertFalse(report.accounting_closed)
        self.assertEqual(report.uncovered_liabilities, ("BTC",))
        self.assertLess(report.robust_horizon_value, 100.0)

    def test_anisotropy_is_a_measured_order_parameter(self) -> None:
        network = ConversionNetwork(
            (
                edge("EUR", "BTC", 0.00002, "a", weight=10.0),
                edge("BTC", "EUR", 50000.0, "b", weight=10.0),
                edge("EUR", "USDC", 1.0, "c", weight=0.01),
                edge("USDC", "EUR", 1.0, "d", weight=0.01),
            )
        )
        report = analyze_anisotropy(
            network, "EUR", ("EUR", "BTC", "USDC"), 100.0
        )
        self.assertGreater(report.order_parameter, 0.9)
        self.assertEqual(report.active_edge_count, 4)


class WealthPhaseTest(unittest.TestCase):
    def test_reference_input_is_deterministic(self) -> None:
        first = load_wealth_phase(WEALTH_DEMO)
        second = load_wealth_phase(WEALTH_DEMO)
        self.assertEqual(first.digest, second.digest)
        self.assertEqual(
            wealth_phase_artifact(first),
            wealth_phase_artifact(second),
        )

    def test_reference_base_is_information_active_and_liquid(self) -> None:
        artifact = wealth_phase_artifact(load_wealth_phase(WEALTH_DEMO))
        self.assertEqual(
            artifact["base"]["regime"],
            "informationally_active_anisotropic_fluid",
        )
        self.assertTrue(artifact["base"]["valuation"]["liquid"])
        self.assertTrue(artifact["base"]["valuation"]["solvent"])

    def test_reference_stress_crosses_declared_phase_boundaries(self) -> None:
        artifact = wealth_phase_artifact(load_wealth_phase(WEALTH_DEMO))
        transition = artifact["transition"]
        self.assertTrue(transition["changed"])
        self.assertIn("solvency_boundary_crossed", transition["reasons"])
        self.assertIn("conversion_topology_changed", transition["reasons"])

    def test_controller_work_is_required_for_information_activity(self) -> None:
        loaded = load_wealth_phase(WEALTH_DEMO)
        scenario = loaded.base
        snapshot = evaluate_wealth_phase(
            "passive",
            scenario.state,
            scenario.network,
            scenario.information,
            scenario.thresholds,
            False,
        )
        self.assertFalse(snapshot.informationally_active)
        self.assertEqual(snapshot.regime, "anisotropic_fluid")

    def test_phase_transition_is_not_triggered_by_identical_snapshots(self) -> None:
        loaded = load_wealth_phase(WEALTH_DEMO)
        scenario = loaded.base
        snapshot = evaluate_wealth_phase(
            "same",
            scenario.state,
            scenario.network,
            scenario.information,
            scenario.thresholds,
            scenario.controller_expends_work,
        )
        transition = detect_phase_transition(snapshot, snapshot)
        self.assertFalse(transition.changed)
        self.assertEqual(transition.reasons, ())

    def test_run_identity_binds_wealth_phase_input(self) -> None:
        dataset = load_dataset(MARKET_DEMO)
        first = run_experiment(dataset, ReactorConfig(), wealth_phase_digest="a")
        second = run_experiment(dataset, ReactorConfig(), wealth_phase_digest="b")
        self.assertNotEqual(first.descriptor.run_id, second.descriptor.run_id)


class OperationAlgebraTest(unittest.TestCase):
    def test_independent_operations_commute(self) -> None:
        left = additive_operation("left", {"a": 1.0})
        right = additive_operation("right", {"b": 2.0})
        certificate = commutation_certificate(left, right, {"a": 0.0, "b": 0.0})
        self.assertTrue(structurally_independent(left, right))
        self.assertTrue(certificate.observationally_commutes)

    def test_shared_resource_operations_are_not_freely_commutative(self) -> None:
        def halve(state: dict[str, float]) -> dict[str, float]:
            return {**state, "cash": state["cash"] / 2.0}

        left = ResourceOperation(
            "halve", frozenset({"cash"}), frozenset({"cash"}), halve
        )
        right = additive_operation("add", {"cash": 10.0}, reads=("cash",))
        certificate = commutation_certificate(left, right, {"cash": 100.0})
        self.assertFalse(certificate.structurally_independent)
        self.assertFalse(certificate.observationally_commutes)

    def test_viability_is_checked_after_every_prefix(self) -> None:
        spend = additive_operation("spend", {"cash": -60.0}, reads=("cash",))
        certificate = certify_prefix_viability(
            (spend, spend),
            {"cash": 100.0},
            lambda state: state["cash"] >= 0.0,
        )
        self.assertFalse(certificate.viable)
        self.assertEqual(certificate.failed_after_operation, "spend")

    def test_reference_witness_contains_positive_and_negative_cases(self) -> None:
        witness = reference_operation_witness()
        self.assertTrue(witness["independent_pair"]["observationally_commutes"])
        self.assertFalse(witness["conflicting_pair"]["observationally_commutes"])


class IntegratedLabTest(unittest.TestCase):
    def test_lab_writes_wealth_phase_and_extended_conformance(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            full_run(
                MARKET_DEMO,
                directory,
                folds=3,
                wealth_phase_path=WEALTH_DEMO,
            )
            output = Path(directory)
            self.assertTrue((output / "wealth_phase.json").exists())
            self.assertTrue((output / "operation_algebra.json").exists())
            report = json.loads(
                (output / "conformance.json").read_text(encoding="utf-8")
            )
            self.assertTrue(report["overall_pass"])
            self.assertEqual(report["checks"][-1]["check_id"], "BMMR-10")


if __name__ == "__main__":
    unittest.main()
