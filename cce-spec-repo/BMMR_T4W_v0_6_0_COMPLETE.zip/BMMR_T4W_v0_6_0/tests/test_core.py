from __future__ import annotations

import unittest

from bmmr.cli import demo_frames
from bmmr.core import (
    Frame,
    Reactor,
    ReactorConfig,
    RouteObservation,
    RouteState,
)
from bmmr.observer import ObserverEstimate
from bmmr.timing import LatencyProfile


def observed_route(**values: object) -> RouteObservation:
    predicted = float(values["predicted_edge"])
    route_id = str(values["route_id"])
    return RouteObservation(
        **values,
        observer_estimates=(
            ObserverEstimate(f"{route_id}:left", predicted - 0.001),
            ObserverEstimate(f"{route_id}:right", predicted + 0.001),
        ),
        latency=LatencyProfile(1, 1, 1, 1, 1, 1, 1),
        edge_lifetime_ms=100.0,
        gap_loss_rate=0.001,
        adverse_loss_rate_per_second=0.001,
    )


class LedgerSemanticsTest(unittest.TestCase):
    def test_committed_capital_is_not_finalized_value(self) -> None:
        reactor = Reactor(ReactorConfig(initial_commitment=100.0))
        self.assertEqual(reactor.ledger.reactor_equity, 100.0)
        self.assertEqual(reactor.ledger.screen_value, 100.0)
        self.assertEqual(reactor.ledger.finalized_objective_value, 0.0)
        self.assertEqual(reactor.ledger.continuation_value, 99.0)
        self.assertEqual(reactor.ledger.balanced_objective_value, 99.0)

    def test_harvest_is_the_only_vault_transition(self) -> None:
        result = Reactor(ReactorConfig()).run(demo_frames())
        self.assertGreater(result.ledger.vault_value, 0.0)
        self.assertAlmostEqual(
            result.ledger.vault_value,
            result.ledger.cumulative_harvest,
        )
        self.assertGreater(result.ledger.total_liquidation_value, 100.0)


class AvalancheTest(unittest.TestCase):
    def test_evidence_increases_leverage_and_gross_exposure(self) -> None:
        result = Reactor(ReactorConfig()).run(demo_frames(8))
        active_records = [
            record for record in result.trace if record.executed_gross > 0
        ]
        self.assertGreaterEqual(len(active_records), 2)
        self.assertGreater(
            active_records[-1].leverage,
            active_records[0].leverage,
        )
        self.assertGreater(
            result.max_gross_exposure,
            active_records[0].executed_gross,
        )
        self.assertGreater(result.max_amplified_exposure, 0.0)
        self.assertTrue(
            all(
                record.preservation_pole_gross
                <= record.desired_gross
                <= record.expansion_pole_gross
                for record in active_records
            )
        )

    def test_negative_control_route_remains_in_mirror(self) -> None:
        result = Reactor(ReactorConfig()).run(demo_frames(3))
        self.assertTrue(
            all(
                any(item.route_id == "A-X-A" for item in record.mirror)
                for record in result.trace
            )
        )

    def test_route_activation_and_exposure_are_separate(self) -> None:
        config = ReactorConfig(
            maximum_leverage=1.0,
            base_leverage=1.0,
            amplification_source="internal_equity_only",
        )
        result = Reactor(config).run(demo_frames(4))
        self.assertTrue(any(record.primary for record in result.trace))
        self.assertTrue(
            all(record.leverage == 1.0 for record in result.trace)
        )


class ReflectionBoundaryTest(unittest.TestCase):
    def test_duplicate_family_cannot_multiply_desired_exposure(self) -> None:
        config = ReactorConfig(
            activation_threshold=0.01,
            deactivation_threshold=0.001,
            base_leverage=1.0,
            maximum_leverage=1.0,
            amplification_source="internal_equity_only",
            family_exposure_limit=0.40,
            capital_floor_fraction=0.0,
            harvest_trigger_multiple=100.0,
            harvest_reseed_multiple=99.0,
        )
        frame = Frame(
            event_id=0,
            observations=tuple(
                observed_route(
                    route_id=f"ALIAS-{index}",
                    predicted_edge=0.10,
                    realized_return=0.0,
                    cost_rate=0.0,
                    capacity=10_000.0,
                    stress_loss_rate=0.01,
                    evidence_family="same_signal",
                )
                for index in range(3)
            ),
        )
        reactor = Reactor(config)
        for observation in frame.observations:
            reactor.route_states[observation.route_id] = RouteState(
                witness_evidence=1.0
            )
        record = reactor.step(frame)
        self.assertEqual(record.binding_constraint, "correlation_family")
        self.assertAlmostEqual(record.desired_gross, 100.0)
        self.assertAlmostEqual(record.executed_gross, 40.0)

    def test_reflection_boundary_scales_to_continuation_budget(self) -> None:
        config = ReactorConfig(
            activation_threshold=0.01,
            deactivation_threshold=0.001,
            base_leverage=1.0,
            maximum_leverage=10.0,
            avalanche_half_saturation=0.01,
            capital_floor_fraction=0.5,
            boundary_utilization=1.0,
            risk_factor_exposure_limit=1.0,
            harvest_trigger_multiple=100.0,
            harvest_reseed_multiple=99.0,
        )
        frame = Frame(
            event_id=0,
            observations=(
                observed_route(
                    route_id="BOUNDARY",
                    predicted_edge=0.20,
                    realized_return=0.0,
                    cost_rate=0.0,
                    capacity=10_000.0,
                    stress_loss_rate=0.5,
                ),
            ),
        )
        reactor = Reactor(config)
        reactor.route_states["BOUNDARY"] = RouteState(witness_evidence=1.0)
        record = reactor.step(frame)
        self.assertEqual(record.binding_constraint, "continuation_reflection")
        self.assertTrue(record.on_reflection_boundary)
        self.assertLess(record.boundary_scale, 1.0)
        self.assertAlmostEqual(record.reflection_budget, 50.0)
        self.assertAlmostEqual(record.stressed_loss, 50.0)
        self.assertAlmostEqual(record.executed_gross, 100.0)
        self.assertAlmostEqual(record.reflection_utilization, 1.0)

    def test_default_run_uses_boundary_without_external_shortfall(self) -> None:
        result = Reactor(ReactorConfig()).run(demo_frames())
        self.assertGreater(result.reflection_limited_events, 0)
        self.assertLessEqual(result.max_reflection_utilization, 1.0 + 1e-12)
        self.assertEqual(result.ledger.external_shortfall, 0.0)


class TraceTest(unittest.TestCase):
    def test_replay_digest_is_deterministic(self) -> None:
        config = ReactorConfig()
        first = Reactor(config).run(demo_frames(10))
        second = Reactor(config).run(demo_frames(10))
        self.assertEqual(first.trace_digest, second.trace_digest)
        self.assertEqual(first.trace, second.trace)

    def test_event_order_is_strict(self) -> None:
        reactor = Reactor(ReactorConfig())
        frame = demo_frames(1)[0]
        reactor.step(frame)
        with self.assertRaises(ValueError):
            reactor.step(frame)


class FailureAccountingTest(unittest.TestCase):
    def test_ruin_does_not_reenter_harvested_vault(self) -> None:
        reactor = Reactor(
            ReactorConfig(
                capital_floor_fraction=0.0,
                boundary_utilization=1.0,
                risk_factor_exposure_limit=1.0,
                liquidation_haircut=0.0,
            )
        )
        reactor.run(demo_frames(16))
        vault_before = reactor.ledger.vault_value
        self.assertGreater(vault_before, 0.0)

        active_id = "A-B-C-A"
        ruin_frame = Frame(
            event_id=16,
            observations=(
                observed_route(
                    route_id=active_id,
                    predicted_edge=0.10,
                    realized_return=-1.0,
                    cost_rate=0.0,
                    capacity=100_000.0,
                    stress_loss_rate=0.01,
                ),
            ),
        )
        reactor.step(ruin_frame)
        self.assertTrue(reactor.ledger.ruined)
        self.assertEqual(reactor.ledger.reactor_equity, 0.0)
        self.assertEqual(reactor.ledger.vault_value, vault_before)
        self.assertGreater(reactor.ledger.external_shortfall, 0.0)

    def test_invalid_hysteresis_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            ReactorConfig(
                activation_threshold=0.02,
                deactivation_threshold=0.02,
            )

    def test_invalid_boundary_parameter_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            ReactorConfig(capital_floor_fraction=1.0)

    def test_invalid_family_limit_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            ReactorConfig(family_exposure_limit=0.0)


if __name__ == "__main__":
    unittest.main()
