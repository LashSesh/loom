from __future__ import annotations

from dataclasses import replace
from pathlib import Path
import tempfile
import unittest

from bmmr.carrier import (
    CarrierLadder,
    CarrierLadderConfig,
    CarrierSignal,
    CarrierSpec,
)
from bmmr.conformance import evaluate_conformance
from bmmr.core import Frame, Reactor, ReactorConfig, RouteObservation, RouteState
from bmmr.dataset import dataset_from_rows, load_dataset
from bmmr.dependency import analyze_dependencies
from bmmr.experiment import run_experiment
from bmmr.fingerprint import implementation_digest
from bmmr.observer import ObserverEstimate, assess_observers
from bmmr.residue import build_residue_ledger, summarize_residues
from bmmr.stress import stress_dataset
from bmmr.timing import LatencyProfile, assess_temporal_realizability


ROOT = Path(__file__).resolve().parents[1]
DEMO = ROOT / "examples" / "demo_market.csv"


def route(
    route_id: str = "R",
    predicted: float = 0.10,
    realized: float = 0.08,
    *,
    latency: LatencyProfile | None = None,
    lifetime: float | None = 100.0,
    gap: float = 0.001,
    adverse: float = 0.001,
    observers: tuple[ObserverEstimate, ...] | None = None,
) -> RouteObservation:
    return RouteObservation(
        route_id=route_id,
        predicted_edge=predicted,
        realized_return=realized,
        cost_rate=0.0,
        capacity=10_000.0,
        stress_loss_rate=0.01,
        evidence_family=f"family:{route_id}",
        observer_estimates=(
            observers
            if observers is not None
            else (
                ObserverEstimate(f"{route_id}:left", predicted - 0.001),
                ObserverEstimate(f"{route_id}:right", predicted + 0.001),
            )
        ),
        latency=latency or LatencyProfile(1, 1, 1, 1, 1, 1, 1),
        edge_lifetime_ms=lifetime,
        gap_loss_rate=gap,
        adverse_loss_rate_per_second=adverse,
        risk_factors=("shared", route_id),
    )


class TemporalRealizabilityTest(unittest.TestCase):
    def test_loop_is_sum_of_all_components(self) -> None:
        profile = LatencyProfile(1, 2, 3, 4, 5, 6, 7)
        assessment = assess_temporal_realizability(
            profile, 40.0, 0.01, 0.10, 50.0
        )
        self.assertEqual(assessment.loop_latency_ms, 28.0)
        self.assertEqual(assessment.latency_margin_ms, 12.0)
        self.assertTrue(assessment.edge_feasible)

    def test_edge_deadline_rejects_slow_loop(self) -> None:
        assessment = assess_temporal_realizability(
            LatencyProfile(2, 2, 2, 2, 2, 2, 2),
            10.0,
            0.0,
            0.0,
            50.0,
        )
        self.assertFalse(assessment.edge_feasible)
        self.assertLess(assessment.latency_margin_ms or 0.0, 0.0)

    def test_temporal_damage_is_a_binding_portfolio_constraint(self) -> None:
        config = ReactorConfig(
            activation_threshold=0.01,
            deactivation_threshold=0.001,
            base_leverage=1.0,
            maximum_leverage=1.0,
            amplification_source="internal_equity_only",
            capital_floor_fraction=0.5,
            family_exposure_limit=1.0,
            risk_factor_exposure_limit=1.0,
            harvest_trigger_multiple=100.0,
            harvest_reseed_multiple=99.0,
        )
        observation = route(gap=0.80, adverse=0.0)
        reactor = Reactor(config)
        reactor.route_states[observation.route_id] = RouteState(
            witness_evidence=1.0
        )
        record = reactor.step(Frame(0, (observation,)))
        self.assertEqual(record.binding_constraint, "temporal_damage")
        self.assertAlmostEqual(record.temporal_damage, 50.0)
        self.assertAlmostEqual(record.executed_gross, 62.5)


class ObserverFieldTest(unittest.TestCase):
    def test_aliases_do_not_create_independent_parallax(self) -> None:
        assessment = assess_observers(
            (
                ObserverEstimate("same", 0.09),
                ObserverEstimate("same", 0.11),
            ),
            0.10,
            minimum_families=2,
            maximum_parallax=0.05,
            maximum_consensus_deviation=0.05,
        )
        self.assertFalse(assessment.observer_complete)
        self.assertEqual(assessment.independent_families, 1)

    def test_unresolved_parallax_enters_mirror(self) -> None:
        observation = route(
            observers=(
                ObserverEstimate("left", 0.03),
                ObserverEstimate("right", 0.17),
            )
        )
        reactor = Reactor(ReactorConfig())
        reactor.route_states[observation.route_id] = RouteState(
            witness_evidence=1.0
        )
        record = reactor.step(Frame(0, (observation,)))
        self.assertEqual(record.mirror[0].rejection_reason, "observer_parallax")


class CausalEvidenceAndDriftTest(unittest.TestCase):
    def test_expectation_prepares_and_outcome_anchors_next_event(self) -> None:
        config = ReactorConfig(
            activation_threshold=0.02,
            deactivation_threshold=0.005,
            family_exposure_limit=1.0,
            risk_factor_exposure_limit=1.0,
        )
        observation = route()
        reactor = Reactor(config)
        first = reactor.step(Frame(0, (observation,)))
        second = reactor.step(Frame(1, (observation,)))
        self.assertEqual(
            first.mirror[0].rejection_reason,
            "insufficient_witness_evidence",
        )
        self.assertTrue(second.primary)

    def test_drift_hysteresis_is_causal_and_path_dependent(self) -> None:
        config = ReactorConfig(
            activation_threshold=0.01,
            deactivation_threshold=0.001,
            drift_decay=0.0,
            drift_on_threshold=0.05,
            drift_off_threshold=0.01,
            family_exposure_limit=1.0,
            risk_factor_exposure_limit=1.0,
        )
        bad = route(predicted=0.10, realized=-0.10)
        good = replace(bad, realized_return=0.10)
        reactor = Reactor(config)
        reactor.route_states[bad.route_id] = RouteState(witness_evidence=1.0)
        first = reactor.step(Frame(0, (bad,)))
        second = reactor.step(Frame(1, (good,)))
        third = reactor.step(Frame(2, (good,)))
        self.assertTrue(first.primary)
        self.assertEqual(first.state_updates[0].drift_mode_after, "reanchor")
        self.assertEqual(second.mirror[0].rejection_reason, "model_drift_reanchor")
        self.assertEqual(second.state_updates[0].drift_mode_after, "compensate")
        self.assertTrue(third.primary)


class ResidueAndDependencyTest(unittest.TestCase):
    def test_residue_register_matures_rejected_counterfactuals(self) -> None:
        dataset = load_dataset(DEMO)
        result = run_experiment(dataset, ReactorConfig()).result
        records = build_residue_ledger(result.trace)
        summary = summarize_residues(records)
        self.assertEqual(summary.total, sum(len(r.mirror) for r in result.trace))
        self.assertGreater(summary.missed_positive, 0)
        self.assertGreater(summary.avoided_negative, 0)

    def test_chordal_dependency_graph_needs_no_fill(self) -> None:
        report = analyze_dependencies(
            (("A", ("ab",)), ("B", ("ab", "bc")), ("C", ("bc",)))
        )
        self.assertTrue(report.chordal)
        self.assertEqual(report.fill_in_edges, ())

    def test_chordless_cycle_exposes_fill_in_residue(self) -> None:
        report = analyze_dependencies(
            (
                ("A", ("ab", "da")),
                ("B", ("ab", "bc")),
                ("C", ("bc", "cd")),
                ("D", ("cd", "da")),
            )
        )
        self.assertFalse(report.chordal)
        self.assertEqual(len(report.fill_in_edges), 1)
        self.assertEqual(report.treewidth_upper_bound, 2)


class CarrierLadderTest(unittest.TestCase):
    def setUp(self) -> None:
        specs = (
            CarrierSpec("primary", 0, "objective:A"),
            CarrierSpec("backup", 1, "objective:A"),
            CarrierSpec("recovery", 2, "objective:A"),
        )
        self.ladder = CarrierLadder(
            specs,
            "primary",
            CarrierLadderConfig(minimum_dwell_events=2),
        )

    def test_prepared_target_does_not_switch_without_active_pressure(self) -> None:
        record = self.ladder.step(
            0,
            (
                CarrierSignal("primary", 0.1, 0.1, 1.0, 1.0, 1.0),
                CarrierSignal("backup", 0.0, 0.0, 1.0, 1.0, 1.0),
            ),
        )
        self.assertIsNone(record)
        self.assertEqual(self.ladder.active_carrier, "primary")

    def test_pressure_plus_readiness_migrates_without_reset(self) -> None:
        first = self.ladder.step(
            0,
            (
                CarrierSignal("primary", 0.9, 0.1, 1.0, 1.0, 1.0),
                CarrierSignal("backup", 0.0, 0.0, 0.9, 0.9, 0.9),
            ),
        )
        self.assertIsNotNone(first)
        self.assertEqual(self.ladder.active_carrier, "backup")
        blocked = self.ladder.step(
            1,
            (
                CarrierSignal("backup", 0.9, 0.1, 1.0, 1.0, 1.0),
                CarrierSignal("recovery", 0.0, 0.0, 0.9, 0.9, 0.9),
            ),
        )
        self.assertIsNone(blocked)
        self.assertEqual(self.ladder.version, 1)


class IdentityAndConformanceTest(unittest.TestCase):
    def test_implementation_digest_is_content_sensitive(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "a.py"
            source.write_text("x = 1\n", encoding="utf-8")
            first = implementation_digest(root)
            source.write_text("x = 2\n", encoding="utf-8")
            second = implementation_digest(root)
            self.assertNotEqual(first, second)

    def test_run_id_binds_implementation_digest(self) -> None:
        dataset = load_dataset(DEMO)
        result = run_experiment(dataset, ReactorConfig())
        self.assertEqual(len(result.descriptor.implementation_digest), 64)
        self.assertEqual(len(result.descriptor.run_id), 64)

    def test_reference_run_passes_conformance(self) -> None:
        dataset = load_dataset(DEMO)
        first = run_experiment(dataset, ReactorConfig())
        second = run_experiment(dataset, ReactorConfig())
        report = evaluate_conformance(
            dataset,
            first,
            first.result.trace == second.result.trace,
        )
        self.assertTrue(report["overall_pass"])

    def test_partial_latency_profile_is_rejected_by_loader(self) -> None:
        row = {
            "event_id": 0,
            "route_id": "R",
            "predicted_edge": 0.1,
            "realized_return": 0.1,
            "cost_rate": 0.0,
            "capacity": 1.0,
            "latency_feed_ms": 1.0,
        }
        with self.assertRaises(ValueError):
            dataset_from_rows((row,))

    def test_latency_and_observer_stresses_hit_their_own_gates(self) -> None:
        dataset = load_dataset(DEMO)
        latency = run_experiment(
            stress_dataset(dataset, "latency_spike"), ReactorConfig()
        )
        observer = run_experiment(
            stress_dataset(dataset, "observer_divergence"), ReactorConfig()
        )
        self.assertGreater(latency.result.timing_rejections, 0)
        self.assertGreater(observer.result.observer_rejections, 0)


if __name__ == "__main__":
    unittest.main()
