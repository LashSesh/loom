from __future__ import annotations

import json
from pathlib import Path
import tempfile
import unittest

from bmmr.core import ReactorConfig
from bmmr.dataset import dataset_from_rows, load_dataset
from bmmr.experiment import run_benchmark, run_experiment, walk_forward
from bmmr.lab import full_run
from bmmr.stress import stress_dataset


ROOT = Path(__file__).resolve().parents[1]
DEMO = ROOT / "examples" / "demo_market.csv"


class DatasetContractTest(unittest.TestCase):
    def test_csv_load_and_digest_are_deterministic(self) -> None:
        first = load_dataset(DEMO)
        second = load_dataset(DEMO)
        self.assertEqual(len(first.frames), 12)
        self.assertEqual(first.digest, second.digest)
        self.assertEqual(first.core_frames, second.core_frames)

    def test_inconsistent_frame_metadata_is_rejected(self) -> None:
        rows = [
            {
                "event_id": 0, "route_id": "A", "predicted_edge": 0.1,
                "realized_return": 0.1, "cost_rate": 0.0, "capacity": 1,
                "regime": "left",
            },
            {
                "event_id": 0, "route_id": "B", "predicted_edge": 0.1,
                "realized_return": 0.1, "cost_rate": 0.0, "capacity": 1,
                "regime": "right",
            },
        ]
        with self.assertRaises(ValueError):
            dataset_from_rows(rows)


class ExperimentTest(unittest.TestCase):
    def setUp(self) -> None:
        self.dataset = load_dataset(DEMO)
        self.config = ReactorConfig()

    def test_run_identity_and_trace_replay(self) -> None:
        first = run_experiment(self.dataset, self.config)
        second = run_experiment(self.dataset, self.config)
        self.assertEqual(first.descriptor.run_id, second.descriptor.run_id)
        self.assertEqual(first.result.trace_digest, second.result.trace_digest)
        self.assertEqual(first.result.trace, second.result.trace)

    def test_benchmark_contains_both_poles_and_reflection(self) -> None:
        benchmark = run_benchmark(self.dataset, self.config)
        self.assertEqual(
            set(benchmark),
            {"preservation_pole", "dynamic_reflection", "expansion_pole"},
        )
        self.assertEqual(benchmark["preservation_pole"].result.max_leverage, 1.0)
        self.assertEqual(
            benchmark["expansion_pole"].result.max_leverage,
            self.config.maximum_leverage,
        )

    def test_walk_forward_is_chronological_and_non_overlapping(self) -> None:
        folds = walk_forward(self.dataset, self.config, 4)
        self.assertEqual(len(folds), 4)
        for left, right in zip(folds, folds[1:]):
            self.assertLess(left.descriptor.last_event_id, right.descriptor.first_event_id)

    def test_combined_stress_changes_digest_and_outcome(self) -> None:
        base = run_experiment(self.dataset, self.config)
        stressed_dataset = stress_dataset(self.dataset, "combined")
        stressed = run_experiment(stressed_dataset, self.config, "combined")
        self.assertNotEqual(self.dataset.digest, stressed_dataset.digest)
        self.assertLess(stressed.metrics.balanced_value_a, base.metrics.balanced_value_a)

    def test_full_lab_writes_replay_proof(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            full_run(DEMO, directory, folds=3)
            output = Path(directory)
            expected = {
                "REPORT.md", "START_HERE.txt", "summary.json", "benchmark.json",
                "benchmark.csv", "stress.json", "walk_forward.json", "trace.jsonl",
                "run_descriptor.json", "verification.json", "MANIFEST.sha256.json",
                "residue.json", "operational.json", "conformance.json",
            }
            self.assertTrue(expected <= {path.name for path in output.iterdir()})
            verification = json.loads(
                (output / "verification.json").read_text(encoding="utf-8")
            )
            self.assertTrue(verification["deterministic_replay_match"])
            manifest = json.loads(
                (output / "MANIFEST.sha256.json").read_text(encoding="utf-8")
            )
            self.assertNotIn("MANIFEST.sha256.json", manifest)


if __name__ == "__main__":
    unittest.main()
