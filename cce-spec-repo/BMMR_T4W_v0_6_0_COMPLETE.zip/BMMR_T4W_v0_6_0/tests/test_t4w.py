from __future__ import annotations

from pathlib import Path
import json
import tempfile
import unittest

from bmmr.tesseract import (
    CubicalCell,
    TesseractAxis,
    TesseractMode,
    adjacent,
    all_cells,
    all_modes,
    canonical_transition_path,
    cell_count,
    chain_boundary,
    changed_axis,
    hamming_distance,
    topology_certificate as tesseract_topology_certificate,
)
from bmmr.thermodynamic_workbody import (
    FieldCoupling,
    PhaseTile,
    Workbody,
    driven_cycle,
    relax_phase,
    transport_step,
)
from bmmr.tpomc_repairs import (
    damping_certificate,
    dimension_certificate,
    mandorla_certificate,
    observability_certificate,
    support_certificate,
    topology_certificate,
)
from bmmr.workbody_lab import DEFAULT_WEALTH, reference_workbody, run_lab


class TesseractTopologyTest(unittest.TestCase):
    def test_tesseract_has_sixteen_modes(self) -> None:
        self.assertEqual(len(all_modes()), 16)

    def test_cubical_cell_counts_are_exact(self) -> None:
        self.assertEqual([cell_count(k) for k in range(5)], [16, 32, 24, 8, 1])
        self.assertEqual(len(all_cells()), 81)

    def test_boundary_of_boundary_is_zero(self) -> None:
        body = CubicalCell((None, None, None, None))
        self.assertEqual(chain_boundary(body.boundary()), {})
        self.assertTrue(tesseract_topology_certificate()["boundary_squared_zero"])

    def test_euler_characteristic_is_one(self) -> None:
        self.assertEqual(tesseract_topology_certificate()["euler_characteristic"], 1)

    def test_diagonal_jump_is_decomposed_into_edges(self) -> None:
        source = TesseractMode(0, 0, 0, 0)
        target = TesseractMode(1, 1, 1, 1)
        path = canonical_transition_path(source, target)
        self.assertEqual(len(path), 5)
        self.assertTrue(all(adjacent(a, b) for a, b in zip(path, path[1:])))
        self.assertEqual(hamming_distance(source, target), 4)

    def test_axis_order_is_deterministic(self) -> None:
        path = canonical_transition_path(
            TesseractMode(0, 0, 0, 0),
            TesseractMode(1, 1, 0, 0),
            (
                TesseractAxis.MOBILITY,
                TesseractAxis.CLOSURE,
                TesseractAxis.ORDER,
                TesseractAxis.INFORMATION,
            ),
        )
        self.assertEqual(changed_axis(path[0], path[1]), TesseractAxis.MOBILITY)

    def test_observable_mapping_prioritises_closure(self) -> None:
        mode = TesseractMode.from_observables(
            accounting_closed=True,
            liquid=False,
            solvent=True,
            mobility=1.0,
            mobility_threshold=0.5,
            order_parameter=0.9,
            order_threshold=0.5,
            causal_information_active=True,
        )
        self.assertEqual(mode.bits, (0, 1, 1, 1))


class ThermodynamicWorkbodyTest(unittest.TestCase):
    def test_reference_body_is_canonical_and_conserves_one_unit(self) -> None:
        body = reference_workbody()
        self.assertEqual(tuple(tile.tile_id for tile in body.tiles), ("A", "B", "C", "D"))
        self.assertAlmostEqual(body.total_resource, 1.0)

    def test_passive_relaxation_does_not_increase_phase_energy(self) -> None:
        body = reference_workbody()
        relaxed, report = relax_phase(body, iterations=20)
        self.assertTrue(report.monotone)
        self.assertLessEqual(relaxed.phase_free_energy, body.phase_free_energy + 1e-12)

    def test_local_drive_nucleates_a_mobile_domain(self) -> None:
        body = reference_workbody()
        driven, report = driven_cycle(
            body,
            temperatures={"A": 2.0},
            drives={"A": 3.0},
            step=0.1,
            iterations=100,
        )
        self.assertGreater(driven.mean_phase_fraction, 0.8)
        self.assertTrue(report.monotone_relaxation)

    def test_driven_cycle_closes_its_storage_balance(self) -> None:
        _, report = driven_cycle(
            reference_workbody(),
            temperatures={"A": 2.0},
            drives={"A": 3.0},
            step=0.1,
            iterations=50,
        )
        self.assertAlmostEqual(report.balance_residual, 0.0, places=12)

    def test_transport_conserves_resource(self) -> None:
        body, _ = driven_cycle(
            reference_workbody(),
            temperatures={"A": 2.0},
            drives={"A": 3.0},
            step=0.1,
            iterations=100,
        )
        updated, report = transport_step(body, step=0.5)
        self.assertAlmostEqual(updated.total_resource, body.total_resource, places=12)
        self.assertAlmostEqual(report.conservation_residual, 0.0, places=12)

    def test_transport_storage_is_nonincreasing(self) -> None:
        body, _ = driven_cycle(
            reference_workbody(),
            temperatures={"A": 2.0},
            drives={"A": 3.0},
            step=0.1,
            iterations=100,
        )
        updated, report = transport_step(body, step=0.5)
        self.assertLessEqual(updated.resource_storage, body.resource_storage + 1e-12)
        self.assertGreaterEqual(report.dissipated, 0.0)

    def test_fully_locked_tiles_block_transport_without_leak(self) -> None:
        tiles = (
            PhaseTile("A", 0.0, 1.0, 1.0, 0.5),
            PhaseTile("B", 0.0, 0.0, 1.0, 0.5),
        )
        body = Workbody(tiles, (FieldCoupling("A", "B", 1.0, 1.0, 0.0),))
        updated, report = transport_step(body)
        self.assertEqual(updated, body)
        self.assertEqual(report.transfers, ())

    def test_interfacial_state_is_not_mislabeled_terminal(self) -> None:
        tile = PhaseTile("A", 0.5, 0.0, 1.0, 1.0)
        self.assertEqual(tile.phase_label, "interfacial")

    def test_unknown_control_target_is_rejected(self) -> None:
        with self.assertRaises(KeyError):
            reference_workbody().with_controls(drives={"unknown": 1.0})


class TpomcRepairTest(unittest.TestCase):
    def test_isometric_stitcher_is_observable(self) -> None:
        certificate = observability_certificate(
            ((1.0, 0.0), (0.0, 1.0), (0.0, 0.0)),
            ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0)),
        )
        self.assertTrue(certificate.adjunction_holds)
        self.assertTrue(certificate.observable)

    def test_zero_stitcher_refutes_adjunction_implies_observability(self) -> None:
        certificate = observability_certificate(
            ((0.0, 0.0), (0.0, 0.0), (0.0, 0.0)),
            ((0.0, 0.0, 0.0), (0.0, 0.0, 0.0)),
        )
        self.assertTrue(certificate.adjunction_holds)
        self.assertFalse(certificate.observable)

    def test_mandorla_can_be_empty_despite_regular_samples(self) -> None:
        certificate = mandorla_certificate(
            (0.0, 1.0),
            (1.0, 0.0),
            threshold_u=0.75,
            threshold_v=0.75,
            minimum_measure=0.1,
        )
        self.assertFalse(certificate.accepted)
        self.assertEqual(certificate.intersection_count, 0)

    def test_mandorla_acceptance_requires_measured_overlap(self) -> None:
        certificate = mandorla_certificate(
            (0.8, 0.9, 0.2),
            (0.9, 0.8, 0.9),
            threshold_u=0.75,
            threshold_v=0.75,
            minimum_measure=0.5,
        )
        self.assertTrue(certificate.accepted)

    def test_expansive_map_is_not_repaired_by_identity_damping(self) -> None:
        certificate = damping_certificate(1.2, 0.5)
        self.assertAlmostEqual(certificate.mixed_lipschitz_bound, 1.1)
        self.assertFalse(certificate.contraction_certified)
        self.assertFalse(certificate.expansive_map_repaired)

    def test_already_contractive_map_remains_contractive(self) -> None:
        self.assertTrue(damping_certificate(0.8, 0.25).contraction_certified)

    def test_shrinking_sets_need_state_support(self) -> None:
        sets = (frozenset({"a", "b"}), frozenset({"b"}))
        self.assertTrue(support_certificate(sets, ("a", "b")).concentration_claim_admissible)
        self.assertFalse(support_certificate(sets, ("a", "a")).concentration_claim_admissible)

    def test_dimension_uses_conservative_maximum(self) -> None:
        certificate = dimension_certificate(2.0, (1.0, 0.1, 0.0))
        self.assertEqual(certificate.conservative_effective_dimension, 2.0)

    def test_zero_covariance_has_explicit_zero_dimension(self) -> None:
        certificate = dimension_certificate(0.0, (0.0, 0.0))
        self.assertTrue(certificate.degenerate_covariance)
        self.assertEqual(certificate.participation_ratio_dimension, 0.0)

    def test_operational_topology_does_not_upgrade_exact_topology(self) -> None:
        certificate = topology_certificate(
            ((1, 1), (1, 1), (1, 1)),
            ((1, 1), (1, 0), (1, 0)),
        )
        self.assertFalse(certificate.exact_signature_reached)
        self.assertTrue(certificate.operational_signature_reached)


class WorkbodyLabTest(unittest.TestCase):
    def test_lab_is_replay_deterministic(self) -> None:
        with tempfile.TemporaryDirectory() as first_dir, tempfile.TemporaryDirectory() as second_dir:
            first = run_lab(Path(first_dir), DEFAULT_WEALTH)
            second = run_lab(Path(second_dir), DEFAULT_WEALTH)
            self.assertEqual(first["run_id"], second["run_id"])
            for name in first["files"]:
                first_bytes = (Path(first_dir) / name).read_bytes()
                second_bytes = (Path(second_dir) / name).read_bytes()
                self.assertEqual(first_bytes, second_bytes, name)

    def test_lab_manifest_binds_every_emitted_artifact(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            run_lab(output, DEFAULT_WEALTH)
            manifest = json.loads((output / "MANIFEST.sha256.json").read_text())
            self.assertEqual(
                set(manifest["files"]),
                {path.name for path in output.iterdir() if path.name != "MANIFEST.sha256.json"},
            )

    def test_repeated_lab_run_does_not_self_include_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            first = run_lab(output, DEFAULT_WEALTH)
            second = run_lab(output, DEFAULT_WEALTH)
            manifest = json.loads((output / "MANIFEST.sha256.json").read_text())
            self.assertNotIn("MANIFEST.sha256.json", manifest["files"])
            self.assertEqual(first["files"], second["files"])
            self.assertEqual(first["run_id"], second["run_id"])

    def test_wealth_bridge_decomposes_stress_transition(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            run_lab(output, DEFAULT_WEALTH)
            bridge = json.loads((output / "wealth_tesseract.json").read_text())
            transitions = bridge["mode_path"]["transitions"]
            self.assertTrue(transitions)
            self.assertTrue(all(item["hamming_distance"] == 1 for item in transitions))


if __name__ == "__main__":
    unittest.main()
