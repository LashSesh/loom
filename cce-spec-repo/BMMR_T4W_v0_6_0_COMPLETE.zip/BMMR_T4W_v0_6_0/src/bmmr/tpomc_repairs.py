"""Executable proof obligations repairing load-bearing TPOMC claims.

The functions in this module deliberately separate a named construction from
the additional hypotheses needed to make its strongest interpretation true.
They are small witnesses, not a general theorem prover.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from math import isfinite
from typing import Iterable, Sequence


Matrix = tuple[tuple[float, ...], ...]
TOLERANCE = 1e-10


def _shape(matrix: Matrix) -> tuple[int, int]:
    if not matrix or not matrix[0]:
        raise ValueError("matrix must be non-empty")
    columns = len(matrix[0])
    if any(len(row) != columns for row in matrix):
        raise ValueError("matrix rows must have equal length")
    if any(not isfinite(value) for row in matrix for value in row):
        raise ValueError("matrix entries must be finite")
    return len(matrix), columns


def transpose(matrix: Matrix) -> Matrix:
    rows, columns = _shape(matrix)
    return tuple(tuple(matrix[row][column] for row in range(rows)) for column in range(columns))


def multiply(left: Matrix, right: Matrix) -> Matrix:
    left_rows, left_columns = _shape(left)
    right_rows, right_columns = _shape(right)
    if left_columns != right_rows:
        raise ValueError("matrix dimensions do not compose")
    return tuple(
        tuple(
            sum(left[row][inner] * right[inner][column] for inner in range(left_columns))
            for column in range(right_columns)
        )
        for row in range(left_rows)
    )


def max_abs_difference(left: Matrix, right: Matrix) -> float:
    if _shape(left) != _shape(right):
        raise ValueError("matrix dimensions differ")
    return max(abs(a - b) for lrow, rrow in zip(left, right) for a, b in zip(lrow, rrow))


def identity(size: int) -> Matrix:
    if size < 1:
        raise ValueError("identity size must be positive")
    return tuple(tuple(float(row == column) for column in range(size)) for row in range(size))


@dataclass(frozen=True, slots=True)
class ObservabilityCertificate:
    adjunction_residual: float
    reconstruction_residual: float
    lower_frame_bound: float
    adjunction_holds: bool
    observable: bool
    interpretation: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def observability_certificate(
    stitcher: Matrix,
    mirror: Matrix,
    *,
    tolerance: float = TOLERANCE,
) -> ObservabilityCertificate:
    """Certify a sufficient finite-dimensional anti-stealth condition.

    ``M = S^T`` establishes the adjunction in Euclidean spaces.  It does not
    establish observability.  Observability additionally requires a positive
    lower frame bound of ``S^T S`` on the admissible subspace.  The returned
    Gershgorin bound is conservative but rigorous when positive.
    """

    s_rows, s_columns = _shape(stitcher)
    m_rows, m_columns = _shape(mirror)
    if (m_rows, m_columns) != (s_columns, s_rows):
        raise ValueError("mirror must map the stitcher codomain back to its domain")
    if tolerance < 0.0:
        raise ValueError("tolerance must be non-negative")

    adjunction_residual = max_abs_difference(mirror, transpose(stitcher))
    gram = multiply(transpose(stitcher), stitcher)
    lower_bounds = []
    for index, row in enumerate(gram):
        radius = sum(abs(value) for column, value in enumerate(row) if column != index)
        lower_bounds.append(row[index] - radius)
    lower_frame_bound = min(lower_bounds)
    reconstruction = multiply(mirror, stitcher)
    reconstruction_residual = max_abs_difference(reconstruction, identity(s_columns))
    adjunction_holds = adjunction_residual <= tolerance
    observable = adjunction_holds and lower_frame_bound > tolerance
    interpretation = (
        "adjunction plus positive lower frame bound"
        if observable
        else "adjunction alone is insufficient; a non-trivial kernel may remain"
    )
    return ObservabilityCertificate(
        adjunction_residual=adjunction_residual,
        reconstruction_residual=reconstruction_residual,
        lower_frame_bound=lower_frame_bound,
        adjunction_holds=adjunction_holds,
        observable=observable,
        interpretation=interpretation,
    )


@dataclass(frozen=True, slots=True)
class MandorlaCertificate:
    sample_count: int
    intersection_count: int
    intersection_measure: float
    minimum_measure: float
    accepted: bool


def mandorla_certificate(
    u_values: Sequence[float],
    v_values: Sequence[float],
    *,
    threshold_u: float,
    threshold_v: float,
    weights: Sequence[float] | None = None,
    minimum_measure: float = 0.0,
) -> MandorlaCertificate:
    """Measure an intersection instead of inferring it from regularity."""

    if len(u_values) != len(v_values) or not u_values:
        raise ValueError("U and V samples must have equal positive length")
    if weights is None:
        weights = tuple(1.0 / len(u_values) for _ in u_values)
    if len(weights) != len(u_values):
        raise ValueError("weights must match the sample count")
    if any(not isfinite(value) for value in (*u_values, *v_values, *weights)):
        raise ValueError("samples and weights must be finite")
    if any(weight < 0.0 for weight in weights) or sum(weights) <= 0.0:
        raise ValueError("weights must be non-negative with positive sum")
    if minimum_measure < 0.0:
        raise ValueError("minimum_measure must be non-negative")

    total_weight = sum(weights)
    mask = [u >= threshold_u and v >= threshold_v for u, v in zip(u_values, v_values)]
    measure = sum(weight for weight, included in zip(weights, mask) if included) / total_weight
    count = sum(mask)
    return MandorlaCertificate(
        sample_count=len(mask),
        intersection_count=count,
        intersection_measure=measure,
        minimum_measure=minimum_measure,
        accepted=count > 0 and measure >= minimum_measure,
    )


@dataclass(frozen=True, slots=True)
class SupportCertificate:
    nested: bool
    state_supported_at_every_step: bool
    intersection_size: int
    singleton_terminal_support: bool
    concentration_claim_admissible: bool


def support_certificate(
    feasible_sets: Sequence[frozenset[str]],
    realised_states: Sequence[str],
) -> SupportCertificate:
    """Check the missing viability premise in a shrinking-support argument."""

    if not feasible_sets or len(feasible_sets) != len(realised_states):
        raise ValueError("one non-empty feasible set is required per realised state")
    nested = all(next_set <= current for current, next_set in zip(feasible_sets, feasible_sets[1:]))
    supported = all(state in feasible for state, feasible in zip(realised_states, feasible_sets))
    intersection = set(feasible_sets[0])
    for feasible in feasible_sets[1:]:
        intersection.intersection_update(feasible)
    singleton = len(intersection) == 1
    return SupportCertificate(
        nested=nested,
        state_supported_at_every_step=supported,
        intersection_size=len(intersection),
        singleton_terminal_support=singleton,
        concentration_claim_admissible=nested and supported and singleton,
    )


@dataclass(frozen=True, slots=True)
class DampingCertificate:
    original_lipschitz_bound: float
    identity_weight: float
    mixed_lipschitz_bound: float
    contraction_certified: bool
    expansive_map_repaired: bool


def damping_certificate(lipschitz_bound: float, identity_weight: float) -> DampingCertificate:
    """Evaluate the only general bound for (1-beta)T + beta*Id.

    If the original bound is at least one, a convex blend with the identity
    approaches one from above and cannot certify contraction.
    """

    if not isfinite(lipschitz_bound) or lipschitz_bound < 0.0:
        raise ValueError("lipschitz_bound must be finite and non-negative")
    if not 0.0 <= identity_weight < 1.0:
        raise ValueError("identity_weight must lie in [0, 1)")
    mixed = identity_weight + (1.0 - identity_weight) * lipschitz_bound
    contraction = mixed < 1.0
    return DampingCertificate(
        original_lipschitz_bound=lipschitz_bound,
        identity_weight=identity_weight,
        mixed_lipschitz_bound=mixed,
        contraction_certified=contraction,
        expansive_map_repaired=lipschitz_bound >= 1.0 and contraction,
    )


@dataclass(frozen=True, slots=True)
class DimensionCertificate:
    box_dimension: float
    participation_ratio_dimension: float
    conservative_effective_dimension: float
    degenerate_covariance: bool


def dimension_certificate(
    box_dimension: float,
    singular_values: Iterable[float],
) -> DimensionCertificate:
    """Combine two dimension witnesses without optimistic minimum selection."""

    values = tuple(singular_values)
    if not isfinite(box_dimension) or box_dimension < 0.0:
        raise ValueError("box_dimension must be finite and non-negative")
    if any(not isfinite(value) or value < 0.0 for value in values):
        raise ValueError("singular values must be finite and non-negative")
    denominator = sum(value * value for value in values)
    degenerate = denominator <= TOLERANCE
    participation = 0.0 if degenerate else (sum(values) ** 2) / denominator
    return DimensionCertificate(
        box_dimension=box_dimension,
        participation_ratio_dimension=participation,
        conservative_effective_dimension=max(box_dimension, participation),
        degenerate_covariance=degenerate,
    )


@dataclass(frozen=True, slots=True)
class TopologyCertificate:
    exact_signature_reached: bool
    operational_signature_reached: bool
    first_exact_step: int | None
    first_operational_step: int | None
    inference_from_diameter_only_forbidden: bool = True


def topology_certificate(
    exact_signatures: Sequence[tuple[int, ...]],
    operational_signatures: Sequence[tuple[int, ...]],
) -> TopologyCertificate:
    """Certify finite topological closure only from an observed signature.

    Shrinking diameter alone is intentionally not an input: scaled circles or
    annuli retain non-trivial topology at every finite step while converging to
    a point in the limit.
    """

    if not exact_signatures or len(exact_signatures) != len(operational_signatures):
        raise ValueError("exact and operational signature histories must align")

    def target(signature: tuple[int, ...]) -> bool:
        return bool(signature) and signature[0] == 1 and all(value == 0 for value in signature[1:])

    exact_steps = [index for index, signature in enumerate(exact_signatures) if target(signature)]
    operational_steps = [
        index for index, signature in enumerate(operational_signatures) if target(signature)
    ]
    return TopologyCertificate(
        exact_signature_reached=bool(exact_steps),
        operational_signature_reached=bool(operational_steps),
        first_exact_step=exact_steps[0] if exact_steps else None,
        first_operational_step=operational_steps[0] if operational_steps else None,
    )
