"""Deterministic reference kernel for the BMMR architecture.

The kernel deliberately separates reactor equity, book value, vault value,
route activation and exposure amplification. It is a simulator and accounting
proof, not an exchange connector or a profitability claim.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
import json
import math
from typing import Iterable

from .dependency import DependencyReport, analyze_dependencies
from .observer import ObserverAssessment, ObserverEstimate, assess_observers
from .timing import (
    LatencyProfile,
    TemporalAssessment,
    assess_temporal_realizability,
)


EPSILON = 1e-12


@dataclass(frozen=True, slots=True)
class ReactorConfig:
    """Versioned parameters of one deterministic run."""

    initial_commitment: float = 100.0
    evidence_decay: float = 0.72
    evidence_gain: float = 1.0
    witness_evidence_gain: float = 1.0
    activation_threshold: float = 0.035
    deactivation_threshold: float = 0.012
    require_timing_evidence: bool = True
    required_latency_margin_ms: float = 0.0
    require_observer_evidence: bool = True
    minimum_observer_families: int = 2
    maximum_observer_parallax: float = 0.025
    maximum_consensus_deviation: float = 0.020
    drift_decay: float = 0.70
    drift_on_threshold: float = 0.040
    drift_off_threshold: float = 0.020
    drift_min_dwell_events: int = 1
    base_leverage: float = 1.0
    maximum_leverage: float = 5.0
    amplification_source: str = "derivative_margin"
    avalanche_half_saturation: float = 0.08
    avalanche_exponent: float = 2.0
    gross_allocation_fraction: float = 1.0
    family_exposure_limit: float = 0.65
    risk_factor_exposure_limit: float = 0.90
    capital_floor_fraction: float = 0.25
    boundary_utilization: float = 1.0
    liquidation_haircut: float = 0.01
    harvest_trigger_multiple: float = 2.0
    harvest_reseed_multiple: float = 1.25
    harvest_fraction: float = 0.75
    minimum_predicted_net_edge: float = 0.0
    stop_at_ruin: bool = True

    def __post_init__(self) -> None:
        positive = {
            "initial_commitment": self.initial_commitment,
            "activation_threshold": self.activation_threshold,
            "base_leverage": self.base_leverage,
            "maximum_leverage": self.maximum_leverage,
            "avalanche_half_saturation": self.avalanche_half_saturation,
            "avalanche_exponent": self.avalanche_exponent,
            "gross_allocation_fraction": self.gross_allocation_fraction,
            "harvest_trigger_multiple": self.harvest_trigger_multiple,
            "harvest_reseed_multiple": self.harvest_reseed_multiple,
        }
        for name, value in positive.items():
            if value <= 0:
                raise ValueError(f"{name} must be positive")
        if not 0 <= self.evidence_decay < 1:
            raise ValueError("evidence_decay must be in [0, 1)")
        if self.evidence_gain < 0:
            raise ValueError("evidence_gain must be non-negative")
        if self.witness_evidence_gain < 0:
            raise ValueError("witness_evidence_gain must be non-negative")
        if self.deactivation_threshold >= self.activation_threshold:
            raise ValueError(
                "deactivation_threshold must be below activation_threshold"
            )
        if self.base_leverage > self.maximum_leverage:
            raise ValueError("base_leverage cannot exceed maximum_leverage")
        if self.required_latency_margin_ms < 0 or not math.isfinite(
            self.required_latency_margin_ms
        ):
            raise ValueError(
                "required_latency_margin_ms must be non-negative and finite"
            )
        if self.minimum_observer_families < 1:
            raise ValueError("minimum_observer_families must be positive")
        if self.maximum_observer_parallax < 0 or not math.isfinite(
            self.maximum_observer_parallax
        ):
            raise ValueError(
                "maximum_observer_parallax must be non-negative and finite"
            )
        if self.maximum_consensus_deviation < 0 or not math.isfinite(
            self.maximum_consensus_deviation
        ):
            raise ValueError(
                "maximum_consensus_deviation must be non-negative and finite"
            )
        if not 0 <= self.drift_decay < 1:
            raise ValueError("drift_decay must be in [0, 1)")
        if self.drift_off_threshold < 0:
            raise ValueError("drift_off_threshold must be non-negative")
        if self.drift_on_threshold <= self.drift_off_threshold:
            raise ValueError(
                "drift_on_threshold must exceed drift_off_threshold"
            )
        if self.drift_min_dwell_events < 0:
            raise ValueError("drift_min_dwell_events must be non-negative")
        admissible_sources = {
            "derivative_margin",
            "secured_credit",
            "internal_equity_only",
        }
        if self.amplification_source not in admissible_sources:
            raise ValueError(
                "amplification_source must be derivative_margin, "
                "secured_credit or internal_equity_only"
            )
        if (
            self.amplification_source == "internal_equity_only"
            and self.maximum_leverage > 1
        ):
            raise ValueError(
                "internal_equity_only cannot create leverage above one"
            )
        if not 0 < self.harvest_fraction <= 1:
            raise ValueError("harvest_fraction must be in (0, 1]")
        if not 0 <= self.capital_floor_fraction < 1:
            raise ValueError("capital_floor_fraction must be in [0, 1)")
        if not 0 < self.family_exposure_limit <= 1:
            raise ValueError("family_exposure_limit must be in (0, 1]")
        if not 0 < self.risk_factor_exposure_limit <= 1:
            raise ValueError("risk_factor_exposure_limit must be in (0, 1]")
        if not 0 < self.boundary_utilization <= 1:
            raise ValueError("boundary_utilization must be in (0, 1]")
        if not 0 <= self.liquidation_haircut < 1:
            raise ValueError("liquidation_haircut must be in [0, 1)")
        if self.harvest_reseed_multiple >= self.harvest_trigger_multiple:
            raise ValueError(
                "harvest_reseed_multiple must be below harvest_trigger_multiple"
            )


@dataclass(frozen=True, slots=True)
class RouteObservation:
    """One executable cycle observation at one event time.

    predicted_edge and realized_return are gross decimal returns for the
    event. cost_rate includes all modeled fees, spread, funding, slippage and
    latency reserve. Capacity is expressed in the phase-A numeraire.
    """

    route_id: str
    predicted_edge: float
    realized_return: float
    cost_rate: float
    capacity: float
    stress_loss_rate: float = 0.22
    phase_from: str = "A"
    phase_to: str = "A"
    evidence_family: str = "default"
    observer_estimates: tuple[ObserverEstimate, ...] = ()
    latency: LatencyProfile | None = None
    edge_lifetime_ms: float | None = None
    gap_loss_rate: float = 0.0
    adverse_loss_rate_per_second: float = 0.0
    risk_factors: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.route_id:
            raise ValueError("route_id must not be empty")
        if self.cost_rate < 0 or not math.isfinite(self.cost_rate):
            raise ValueError("cost_rate must be non-negative and finite")
        if self.capacity < 0 or not math.isfinite(self.capacity):
            raise ValueError("capacity must be non-negative and finite")
        if self.stress_loss_rate <= 0 or not math.isfinite(
            self.stress_loss_rate
        ):
            raise ValueError("stress_loss_rate must be positive and finite")
        if not math.isfinite(self.predicted_edge):
            raise ValueError("predicted_edge must be finite")
        if not math.isfinite(self.realized_return):
            raise ValueError("realized_return must be finite")
        if not self.evidence_family:
            raise ValueError("evidence_family must not be empty")
        if self.edge_lifetime_ms is not None and (
            self.edge_lifetime_ms <= 0
            or not math.isfinite(self.edge_lifetime_ms)
        ):
            raise ValueError("edge_lifetime_ms must be positive and finite")
        if self.gap_loss_rate < 0 or not math.isfinite(self.gap_loss_rate):
            raise ValueError("gap_loss_rate must be non-negative and finite")
        if self.adverse_loss_rate_per_second < 0 or not math.isfinite(
            self.adverse_loss_rate_per_second
        ):
            raise ValueError(
                "adverse_loss_rate_per_second must be non-negative and finite"
            )
        if any(not factor for factor in self.risk_factors):
            raise ValueError("risk_factors must not contain empty values")

    @property
    def predicted_net_edge(self) -> float:
        return self.predicted_edge - self.cost_rate

    @property
    def realized_net_return(self) -> float:
        return self.realized_return - self.cost_rate

    @property
    def effective_risk_factors(self) -> tuple[str, ...]:
        return tuple(sorted(set(self.risk_factors))) or (
            f"evidence:{self.evidence_family}",
        )


@dataclass(frozen=True, slots=True)
class Frame:
    event_id: int
    observations: tuple[RouteObservation, ...]

    def __post_init__(self) -> None:
        if self.event_id < 0:
            raise ValueError("event_id must be non-negative")
        route_ids = [observation.route_id for observation in self.observations]
        if len(route_ids) != len(set(route_ids)):
            raise ValueError("a frame cannot contain a duplicate route_id")


@dataclass(slots=True)
class RouteState:
    prepared_evidence: float = 0.0
    witness_evidence: float = 0.0
    active: bool = False
    activations: int = 0
    drift_score: float = 0.0
    drift_mode: str = "compensate"
    last_drift_transition_event: int | None = None
    drift_transitions: int = 0

    @property
    def evidence(self) -> float:
        return min(self.prepared_evidence, self.witness_evidence)


@dataclass(slots=True)
class Ledger:
    """Capital state with distinct continuation and finalization roles."""

    committed_total: float
    reactor_equity: float
    liquidation_haircut: float = 0.0
    vault_value: float = 0.0
    cumulative_pnl: float = 0.0
    cumulative_costs: float = 0.0
    cumulative_harvest: float = 0.0
    external_shortfall: float = 0.0
    ruined: bool = False

    @classmethod
    def open(cls, commitment: float, liquidation_haircut: float = 0.0) -> "Ledger":
        if commitment <= 0:
            raise ValueError("commitment must be positive")
        if not 0 <= liquidation_haircut < 1:
            raise ValueError("liquidation_haircut must be in [0, 1)")
        return cls(
            committed_total=commitment,
            reactor_equity=commitment,
            liquidation_haircut=liquidation_haircut,
        )

    @property
    def screen_value(self) -> float:
        return self.reactor_equity

    @property
    def finalized_objective_value(self) -> float:
        return self.vault_value

    @property
    def continuation_value(self) -> float:
        return self.reactor_equity * (1.0 - self.liquidation_haircut)

    @property
    def balanced_objective_value(self) -> float:
        return self.vault_value + self.continuation_value

    @property
    def total_liquidation_value(self) -> float:
        return self.balanced_objective_value

    @property
    def net_result(self) -> float:
        return self.total_liquidation_value - self.committed_total


@dataclass(frozen=True, slots=True)
class RouteDecision:
    route_id: str
    evidence_family: str
    active: bool
    evidence: float
    prepared_evidence: float
    witness_evidence: float
    score: float
    exposure: float
    capacity: float
    stress_loss_rate: float
    predicted_net_edge: float
    realized_net_return: float
    timing_complete: bool
    loop_latency_ms: float | None
    edge_lifetime_ms: float | None
    latency_margin_ms: float | None
    temporal_damage_rate: float | None
    observer_complete: bool
    independent_observer_families: int
    observer_consensus_edge: float | None
    observer_parallax: float | None
    observer_consensus_deviation: float | None
    drift_score: float
    drift_mode: str
    risk_factors: tuple[str, ...]
    rejection_reason: str | None


@dataclass(frozen=True, slots=True)
class RouteStateUpdate:
    route_id: str
    witness_evidence_before: float
    witness_evidence_after: float
    drift_score_before: float
    drift_score_after: float
    drift_mode_before: str
    drift_mode_after: str
    drift_transitioned: bool


@dataclass(frozen=True, slots=True)
class TraceRecord:
    event_id: int
    reactor_equity_before: float
    reactor_equity_after: float
    vault_before: float
    vault_after: float
    evidence_level: float
    avalanche_gain: float
    leverage: float
    preservation_pole_gross: float
    expansion_pole_gross: float
    desired_gross: float
    pre_reflection_gross: float
    executed_gross: float
    continuation_floor: float
    reflection_budget: float
    stress_loss_before_reflection: float
    stressed_loss: float
    temporal_damage_before_reflection: float
    temporal_damage: float
    boundary_scale: float
    static_boundary_scale: float
    temporal_boundary_scale: float
    reflection_utilization: float
    temporal_damage_utilization: float
    max_loop_latency_ms: float | None
    minimum_latency_margin_ms: float | None
    timing_blindspots: int
    observer_blindspots: int
    max_observer_parallax: float | None
    binding_constraint: str
    on_reflection_boundary: bool
    family_exposures: tuple[tuple[str, float], ...]
    max_family_share: float
    risk_factor_exposures: tuple[tuple[str, float], ...]
    max_risk_factor_utilization: float
    dependency_chordal: bool
    dependency_fill_in_edges: tuple[tuple[str, str], ...]
    dependency_treewidth_upper_bound: int
    equity_funded_gross: float
    amplified_gross: float
    amplification_source: str
    gross_pnl: float
    modeled_costs: float
    net_pnl: float
    harvested: float
    external_shortfall: float
    ruined: bool
    drift_reanchor_routes: int
    primary: tuple[RouteDecision, ...]
    mirror: tuple[RouteDecision, ...]
    state_updates: tuple[RouteStateUpdate, ...]
    record_hash: str


@dataclass(frozen=True, slots=True)
class RunResult:
    ledger: Ledger
    trace: tuple[TraceRecord, ...]
    trace_digest: str
    max_gross_exposure: float
    max_amplified_exposure: float
    max_leverage: float
    reflection_limited_events: int
    max_reflection_utilization: float
    max_temporal_damage_utilization: float
    max_family_share: float
    max_risk_factor_utilization: float
    timing_rejections: int
    observer_rejections: int
    drift_rejections: int
    drift_transitions: int


def _canonical_json(value: object) -> str:
    return json.dumps(
        value,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def _record_hash(payload: dict[str, object]) -> str:
    return sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


class Reactor:
    """Stateful deterministic simulator."""

    def __init__(self, config: ReactorConfig):
        self.config = config
        self.ledger = Ledger.open(
            config.initial_commitment,
            liquidation_haircut=config.liquidation_haircut,
        )
        self.route_states: dict[str, RouteState] = {}
        self.trace: list[TraceRecord] = []

    def _route_state(self, route_id: str) -> RouteState:
        return self.route_states.setdefault(route_id, RouteState())

    def _update_route(
        self,
        observation: RouteObservation,
        temporal: TemporalAssessment,
        observer: ObserverAssessment,
    ) -> tuple[RouteState, str | None]:
        state = self._route_state(observation.route_id)
        innovation = self.config.evidence_gain * observation.predicted_net_edge
        state.prepared_evidence = max(
            0.0,
            self.config.evidence_decay * state.prepared_evidence + innovation,
        )

        if state.active:
            if (
                state.evidence <= self.config.deactivation_threshold
                or observation.predicted_net_edge
                <= self.config.minimum_predicted_net_edge
                or observation.capacity <= 0
            ):
                state.active = False
        elif (
            state.evidence >= self.config.activation_threshold
            and observation.predicted_net_edge
            > self.config.minimum_predicted_net_edge
            and observation.capacity > 0
        ):
            state.active = True
            state.activations += 1

        if observation.capacity <= 0:
            return state, "zero_capacity"
        if observation.predicted_net_edge <= self.config.minimum_predicted_net_edge:
            return state, "nonpositive_predicted_net_edge"
        if self.config.require_timing_evidence and not temporal.timing_complete:
            return state, "missing_timing_evidence"
        if temporal.timing_complete and not temporal.edge_feasible:
            return state, "nonpositive_latency_margin"
        if self.config.require_observer_evidence and not observer.observer_complete:
            return state, "observer_blindspot"
        if observer.observer_complete and not observer.stable:
            return state, "observer_parallax"
        if state.drift_mode == "reanchor":
            return state, "model_drift_reanchor"
        if (
            state.prepared_evidence >= self.config.activation_threshold
            and state.witness_evidence < self.config.activation_threshold
        ):
            return state, "insufficient_witness_evidence"
        if not state.active:
            return state, "below_activation_hysteresis"
        return state, None

    def _mature_route_state(
        self,
        event_id: int,
        observation: RouteObservation,
    ) -> RouteStateUpdate:
        """Apply only information that is available after the decision."""

        state = self._route_state(observation.route_id)
        witness_before = state.witness_evidence
        drift_before = state.drift_score
        mode_before = state.drift_mode
        state.witness_evidence = max(
            0.0,
            self.config.evidence_decay * state.witness_evidence
            + self.config.witness_evidence_gain
            * observation.realized_net_return,
        )
        innovation = abs(
            observation.realized_net_return
            - observation.predicted_net_edge
        )
        state.drift_score = (
            self.config.drift_decay * state.drift_score
            + (1.0 - self.config.drift_decay) * innovation
        )
        dwell_ok = (
            state.last_drift_transition_event is None
            or event_id - state.last_drift_transition_event
            >= self.config.drift_min_dwell_events
        )
        if (
            state.drift_mode == "compensate"
            and state.drift_score >= self.config.drift_on_threshold
            and dwell_ok
        ):
            state.drift_mode = "reanchor"
        elif (
            state.drift_mode == "reanchor"
            and state.drift_score <= self.config.drift_off_threshold
            and dwell_ok
        ):
            state.drift_mode = "compensate"
        transitioned = state.drift_mode != mode_before
        if transitioned:
            state.last_drift_transition_event = event_id
            state.drift_transitions += 1
            state.active = False
        return RouteStateUpdate(
            route_id=observation.route_id,
            witness_evidence_before=witness_before,
            witness_evidence_after=state.witness_evidence,
            drift_score_before=drift_before,
            drift_score_after=state.drift_score,
            drift_mode_before=mode_before,
            drift_mode_after=state.drift_mode,
            drift_transitioned=transitioned,
        )

    def _avalanche_gain(self, evidence_level: float) -> float:
        numerator = evidence_level**self.config.avalanche_exponent
        half = (
            self.config.avalanche_half_saturation
            ** self.config.avalanche_exponent
        )
        if numerator <= 0:
            return 0.0
        return numerator / (half + numerator)

    @staticmethod
    def _weighted_fill(
        desired: float,
        items: list[tuple[str, float, float]],
    ) -> dict[str, float]:
        """Deterministic score-weighted water fill for keyed capacities."""

        allocations = {key: 0.0 for key, _, _ in items}
        remaining = max(0.0, desired)
        open_items = sorted(items, key=lambda item: item[0])
        while remaining > EPSILON and open_items:
            total_score = sum(max(score, EPSILON) for _, score, _ in open_items)
            consumed = 0.0
            still_open: list[tuple[str, float, float]] = []
            for key, score, capacity in open_items:
                share = remaining * max(score, EPSILON) / total_score
                room = capacity - allocations[key]
                fill = min(share, max(0.0, room))
                allocations[key] += fill
                consumed += fill
                if room - fill > EPSILON:
                    still_open.append((key, score, capacity))
            if consumed <= EPSILON:
                break
            remaining -= consumed
            open_items = still_open
        return allocations

    def _capacity_allocate(
        self,
        desired_gross: float,
        candidates: list[
            tuple[
                RouteObservation,
                RouteState,
                float,
                TemporalAssessment,
                ObserverAssessment,
            ]
        ],
    ) -> tuple[dict[str, float], bool]:
        """Allocate first between evidence families, then between routes.

        A family is scored by its strongest member rather than by the number
        of aliases. Duplicate signals therefore cannot multiply priority or
        bypass the family concentration ceiling.
        """

        grouped: dict[
            str,
            list[
                tuple[
                    RouteObservation,
                    RouteState,
                    float,
                    TemporalAssessment,
                    ObserverAssessment,
                ]
            ],
        ] = {}
        for candidate in candidates:
            grouped.setdefault(candidate[0].evidence_family, []).append(candidate)

        family_items: list[tuple[str, float, float]] = []
        for family, members in grouped.items():
            raw_capacity = sum(item[0].capacity for item in members)
            family_capacity = min(
                raw_capacity,
                desired_gross * self.config.family_exposure_limit,
            )
            family_items.append(
                (family, max(item[2] for item in members), family_capacity)
            )

        family_allocations = self._weighted_fill(desired_gross, family_items)
        allocations = {item[0].route_id: 0.0 for item in candidates}
        for family, members in grouped.items():
            route_items = [
                (observation.route_id, score, observation.capacity)
                for observation, _, score, _, _ in members
            ]
            allocations.update(
                self._weighted_fill(family_allocations[family], route_items)
            )
        factor_limited = False
        factor_cap = desired_gross * self.config.risk_factor_exposure_limit
        factors = sorted(
            {
                factor
                for observation, _, _, _, _ in candidates
                for factor in observation.effective_risk_factors
            }
        )
        for factor in factors:
            members = [
                observation.route_id
                for observation, _, _, _, _ in candidates
                if factor in observation.effective_risk_factors
            ]
            exposure = sum(allocations[route_id] for route_id in members)
            if exposure > factor_cap + EPSILON and exposure > EPSILON:
                scale = factor_cap / exposure
                for route_id in members:
                    allocations[route_id] *= scale
                factor_limited = True
        return allocations, factor_limited

    @staticmethod
    def _decision(
        observation: RouteObservation,
        state: RouteState,
        score: float,
        exposure: float,
        temporal: TemporalAssessment,
        observer: ObserverAssessment,
        rejection_reason: str | None,
    ) -> RouteDecision:
        return RouteDecision(
            route_id=observation.route_id,
            evidence_family=observation.evidence_family,
            active=state.active,
            evidence=state.evidence,
            prepared_evidence=state.prepared_evidence,
            witness_evidence=state.witness_evidence,
            score=score,
            exposure=exposure,
            capacity=observation.capacity,
            stress_loss_rate=observation.stress_loss_rate,
            predicted_net_edge=observation.predicted_net_edge,
            realized_net_return=observation.realized_net_return,
            timing_complete=temporal.timing_complete,
            loop_latency_ms=temporal.loop_latency_ms,
            edge_lifetime_ms=temporal.edge_lifetime_ms,
            latency_margin_ms=temporal.latency_margin_ms,
            temporal_damage_rate=temporal.temporal_damage_rate,
            observer_complete=observer.observer_complete,
            independent_observer_families=observer.independent_families,
            observer_consensus_edge=observer.consensus_edge,
            observer_parallax=observer.parallax,
            observer_consensus_deviation=observer.consensus_deviation,
            drift_score=state.drift_score,
            drift_mode=state.drift_mode,
            risk_factors=observation.effective_risk_factors,
            rejection_reason=rejection_reason,
        )

    def step(self, frame: Frame) -> TraceRecord:
        if self.ledger.ruined and self.config.stop_at_ruin:
            raise RuntimeError("reactor is ruined and stop_at_ruin is enabled")
        if self.trace and frame.event_id <= self.trace[-1].event_id:
            raise ValueError("event_id must be strictly increasing")

        before_equity = self.ledger.reactor_equity
        before_vault = self.ledger.vault_value
        continuation_floor = before_equity * self.config.capital_floor_fraction
        reflection_budget = (
            max(0.0, before_equity - continuation_floor)
            * self.config.boundary_utilization
        )
        candidates: list[
            tuple[
                RouteObservation,
                RouteState,
                float,
                TemporalAssessment,
                ObserverAssessment,
            ]
        ] = []
        mirror_decisions: list[RouteDecision] = []
        assessments: list[
            tuple[RouteObservation, TemporalAssessment, ObserverAssessment]
        ] = []

        ordered_observations = tuple(sorted(
            frame.observations, key=lambda value: value.route_id
        ))
        for observation in ordered_observations:
            temporal = assess_temporal_realizability(
                observation.latency,
                observation.edge_lifetime_ms,
                observation.gap_loss_rate,
                observation.adverse_loss_rate_per_second,
                reflection_budget,
                self.config.required_latency_margin_ms,
            )
            observer = assess_observers(
                observation.observer_estimates,
                observation.predicted_edge,
                self.config.minimum_observer_families,
                self.config.maximum_observer_parallax,
                self.config.maximum_consensus_deviation,
            )
            assessments.append((observation, temporal, observer))
            state, rejection = self._update_route(
                observation, temporal, observer
            )
            score = max(0.0, state.evidence * observation.predicted_net_edge)
            if rejection is None:
                candidates.append(
                    (observation, state, score, temporal, observer)
                )
            else:
                mirror_decisions.append(
                    self._decision(
                        observation,
                        state,
                        score,
                        0.0,
                        temporal,
                        observer,
                        rejection,
                    )
                )

        if candidates:
            weighted_evidence = sum(
                max(score, EPSILON) * state.evidence
                for _, state, score, _, _ in candidates
            ) / sum(
                max(score, EPSILON)
                for _, _, score, _, _ in candidates
            )
        else:
            weighted_evidence = 0.0

        avalanche_gain = self._avalanche_gain(weighted_evidence)
        leverage = self.config.base_leverage + avalanche_gain * (
            self.config.maximum_leverage - self.config.base_leverage
        )
        preservation_pole_gross = (
            before_equity
            * self.config.base_leverage
            * self.config.gross_allocation_fraction
        )
        expansion_pole_gross = (
            before_equity
            * self.config.maximum_leverage
            * self.config.gross_allocation_fraction
        )
        desired_gross = (
            before_equity
            * leverage
            * self.config.gross_allocation_fraction
        )
        allocations, factor_limited = self._capacity_allocate(
            desired_gross, candidates
        )
        pre_reflection_gross = sum(allocations.values())
        stress_loss_before_reflection = sum(
            allocations[observation.route_id] * observation.stress_loss_rate
            for observation, _, _, _, _ in candidates
        )
        temporal_damage_before_reflection = sum(
            allocations[observation.route_id]
            * (temporal.temporal_damage_rate or 0.0)
            for observation, _, _, temporal, _ in candidates
        )

        def boundary_scale_for(loss: float) -> float:
            if loss <= EPSILON:
                return 1.0
            if reflection_budget <= EPSILON:
                return 0.0
            return min(1.0, reflection_budget / loss)

        static_boundary_scale = boundary_scale_for(
            stress_loss_before_reflection
        )
        temporal_boundary_scale = boundary_scale_for(
            temporal_damage_before_reflection
        )
        boundary_scale = min(
            static_boundary_scale, temporal_boundary_scale
        )
        if boundary_scale < 1.0 - EPSILON:
            allocations = {
                route_id: exposure * boundary_scale
                for route_id, exposure in allocations.items()
            }

        stressed_loss = sum(
            allocations[observation.route_id] * observation.stress_loss_rate
            for observation, _, _, _, _ in candidates
        )
        temporal_damage = sum(
            allocations[observation.route_id]
            * (temporal.temporal_damage_rate or 0.0)
            for observation, _, _, temporal, _ in candidates
        )
        reflection_utilization = (
            min(1.0, stressed_loss / reflection_budget)
            if reflection_budget > EPSILON
            else float(stressed_loss > EPSILON)
        )
        temporal_damage_utilization = (
            min(1.0, temporal_damage / reflection_budget)
            if reflection_budget > EPSILON
            else float(temporal_damage > EPSILON)
        )
        if not candidates:
            binding_constraint = "no_admissible_route"
        elif boundary_scale < 1.0 - EPSILON:
            if abs(static_boundary_scale - temporal_boundary_scale) <= EPSILON:
                binding_constraint = "joint_reflection"
            elif temporal_boundary_scale < static_boundary_scale:
                binding_constraint = "temporal_damage"
            else:
                binding_constraint = "continuation_reflection"
        elif factor_limited:
            binding_constraint = "risk_factor"
        elif pre_reflection_gross < desired_gross - EPSILON:
            raw_capacity = sum(item[0].capacity for item in candidates)
            binding_constraint = (
                "correlation_family"
                if raw_capacity >= desired_gross - EPSILON
                else "liquidity_capacity"
            )
        else:
            binding_constraint = "evidence_amplification"
        on_reflection_boundary = bool(candidates)

        primary_decisions: list[RouteDecision] = []
        gross_pnl = 0.0
        modeled_costs = 0.0
        for observation, state, score, temporal, observer in candidates:
            exposure = allocations[observation.route_id]
            gross_pnl += exposure * observation.realized_return
            modeled_costs += exposure * observation.cost_rate
            primary_decisions.append(
                self._decision(
                    observation,
                    state,
                    score,
                    exposure,
                    temporal,
                    observer,
                    None,
                )
            )

        executed_gross = sum(decision.exposure for decision in primary_decisions)
        family_totals: dict[str, float] = {}
        for decision in primary_decisions:
            family_totals[decision.evidence_family] = (
                family_totals.get(decision.evidence_family, 0.0)
                + decision.exposure
            )
        family_exposures = tuple(sorted(family_totals.items()))
        max_family_share = (
            max(family_totals.values()) / executed_gross
            if executed_gross > EPSILON and family_totals
            else 0.0
        )
        factor_totals: dict[str, float] = {}
        for decision in primary_decisions:
            for factor in decision.risk_factors:
                factor_totals[factor] = (
                    factor_totals.get(factor, 0.0) + decision.exposure
                )
        risk_factor_exposures = tuple(sorted(factor_totals.items()))
        factor_denominator = (
            desired_gross * self.config.risk_factor_exposure_limit
        )
        max_risk_factor_utilization = (
            max(factor_totals.values()) / factor_denominator
            if factor_totals and factor_denominator > EPSILON
            else 0.0
        )
        dependency: DependencyReport = analyze_dependencies(
            (
                observation.route_id,
                observation.effective_risk_factors,
            )
            for observation, _, _, _, _ in candidates
        )
        loop_latencies = [
            temporal.loop_latency_ms
            for _, temporal, _ in assessments
            if temporal.loop_latency_ms is not None
        ]
        latency_margins = [
            temporal.latency_margin_ms
            for _, temporal, _ in assessments
            if temporal.latency_margin_ms is not None
        ]
        parallaxes = [
            observer.parallax
            for _, _, observer in assessments
            if observer.parallax is not None
        ]
        max_loop_latency_ms = max(loop_latencies) if loop_latencies else None
        minimum_latency_margin_ms = (
            min(latency_margins) if latency_margins else None
        )
        timing_blindspots = sum(
            not temporal.timing_complete
            for _, temporal, _ in assessments
        )
        observer_blindspots = sum(
            not observer.observer_complete
            for _, _, observer in assessments
        )
        max_observer_parallax = max(parallaxes) if parallaxes else None
        equity_funded_gross = min(executed_gross, before_equity)
        amplified_gross = max(0.0, executed_gross - equity_funded_gross)
        net_pnl = gross_pnl - modeled_costs
        raw_equity = before_equity + net_pnl
        shortfall = max(0.0, -raw_equity)
        after_equity = max(0.0, raw_equity)

        self.ledger.cumulative_pnl += gross_pnl
        self.ledger.cumulative_costs += modeled_costs
        self.ledger.external_shortfall += shortfall
        self.ledger.reactor_equity = after_equity
        self.ledger.ruined = after_equity <= EPSILON

        harvested = self._harvest_if_due()
        state_updates = tuple(
            self._mature_route_state(frame.event_id, observation)
            for observation in ordered_observations
        )
        drift_reanchor_routes = sum(
            state.drift_mode == "reanchor"
            for state in self.route_states.values()
        )

        payload: dict[str, object] = {
            "event_id": frame.event_id,
            "reactor_equity_before": before_equity,
            "reactor_equity_after": self.ledger.reactor_equity,
            "vault_before": before_vault,
            "vault_after": self.ledger.vault_value,
            "evidence_level": weighted_evidence,
            "avalanche_gain": avalanche_gain,
            "leverage": leverage,
            "preservation_pole_gross": preservation_pole_gross,
            "expansion_pole_gross": expansion_pole_gross,
            "desired_gross": desired_gross,
            "pre_reflection_gross": pre_reflection_gross,
            "executed_gross": executed_gross,
            "continuation_floor": continuation_floor,
            "reflection_budget": reflection_budget,
            "stress_loss_before_reflection": stress_loss_before_reflection,
            "stressed_loss": stressed_loss,
            "temporal_damage_before_reflection": temporal_damage_before_reflection,
            "temporal_damage": temporal_damage,
            "boundary_scale": boundary_scale,
            "static_boundary_scale": static_boundary_scale,
            "temporal_boundary_scale": temporal_boundary_scale,
            "reflection_utilization": reflection_utilization,
            "temporal_damage_utilization": temporal_damage_utilization,
            "max_loop_latency_ms": max_loop_latency_ms,
            "minimum_latency_margin_ms": minimum_latency_margin_ms,
            "timing_blindspots": timing_blindspots,
            "observer_blindspots": observer_blindspots,
            "max_observer_parallax": max_observer_parallax,
            "binding_constraint": binding_constraint,
            "on_reflection_boundary": on_reflection_boundary,
            "family_exposures": family_exposures,
            "max_family_share": max_family_share,
            "risk_factor_exposures": risk_factor_exposures,
            "max_risk_factor_utilization": max_risk_factor_utilization,
            "dependency_chordal": dependency.chordal,
            "dependency_fill_in_edges": dependency.fill_in_edges,
            "dependency_treewidth_upper_bound": (
                dependency.treewidth_upper_bound
            ),
            "equity_funded_gross": equity_funded_gross,
            "amplified_gross": amplified_gross,
            "amplification_source": self.config.amplification_source,
            "gross_pnl": gross_pnl,
            "modeled_costs": modeled_costs,
            "net_pnl": net_pnl,
            "harvested": harvested,
            "external_shortfall": shortfall,
            "ruined": self.ledger.ruined,
            "drift_reanchor_routes": drift_reanchor_routes,
            "primary": [asdict(item) for item in primary_decisions],
            "mirror": [asdict(item) for item in mirror_decisions],
            "state_updates": [asdict(item) for item in state_updates],
        }
        record = TraceRecord(
            event_id=frame.event_id,
            reactor_equity_before=before_equity,
            reactor_equity_after=self.ledger.reactor_equity,
            vault_before=before_vault,
            vault_after=self.ledger.vault_value,
            evidence_level=weighted_evidence,
            avalanche_gain=avalanche_gain,
            leverage=leverage,
            preservation_pole_gross=preservation_pole_gross,
            expansion_pole_gross=expansion_pole_gross,
            desired_gross=desired_gross,
            pre_reflection_gross=pre_reflection_gross,
            executed_gross=executed_gross,
            continuation_floor=continuation_floor,
            reflection_budget=reflection_budget,
            stress_loss_before_reflection=stress_loss_before_reflection,
            stressed_loss=stressed_loss,
            temporal_damage_before_reflection=temporal_damage_before_reflection,
            temporal_damage=temporal_damage,
            boundary_scale=boundary_scale,
            static_boundary_scale=static_boundary_scale,
            temporal_boundary_scale=temporal_boundary_scale,
            reflection_utilization=reflection_utilization,
            temporal_damage_utilization=temporal_damage_utilization,
            max_loop_latency_ms=max_loop_latency_ms,
            minimum_latency_margin_ms=minimum_latency_margin_ms,
            timing_blindspots=timing_blindspots,
            observer_blindspots=observer_blindspots,
            max_observer_parallax=max_observer_parallax,
            binding_constraint=binding_constraint,
            on_reflection_boundary=on_reflection_boundary,
            family_exposures=family_exposures,
            max_family_share=max_family_share,
            risk_factor_exposures=risk_factor_exposures,
            max_risk_factor_utilization=max_risk_factor_utilization,
            dependency_chordal=dependency.chordal,
            dependency_fill_in_edges=dependency.fill_in_edges,
            dependency_treewidth_upper_bound=(
                dependency.treewidth_upper_bound
            ),
            equity_funded_gross=equity_funded_gross,
            amplified_gross=amplified_gross,
            amplification_source=self.config.amplification_source,
            gross_pnl=gross_pnl,
            modeled_costs=modeled_costs,
            net_pnl=net_pnl,
            harvested=harvested,
            external_shortfall=shortfall,
            ruined=self.ledger.ruined,
            drift_reanchor_routes=drift_reanchor_routes,
            primary=tuple(primary_decisions),
            mirror=tuple(mirror_decisions),
            state_updates=state_updates,
            record_hash=_record_hash(payload),
        )
        self.trace.append(record)
        return record

    def _harvest_if_due(self) -> float:
        trigger = (
            self.config.initial_commitment
            * self.config.harvest_trigger_multiple
        )
        if self.ledger.reactor_equity < trigger:
            return 0.0
        reseed = (
            self.config.initial_commitment
            * self.config.harvest_reseed_multiple
        )
        excess = max(0.0, self.ledger.reactor_equity - reseed)
        harvested = self.config.harvest_fraction * excess
        self.ledger.reactor_equity -= harvested
        self.ledger.vault_value += harvested
        self.ledger.cumulative_harvest += harvested
        return harvested

    def run(self, frames: Iterable[Frame]) -> RunResult:
        for frame in frames:
            if self.ledger.ruined and self.config.stop_at_ruin:
                break
            self.step(frame)

        digest_payload = [record.record_hash for record in self.trace]
        digest = sha256(_canonical_json(digest_payload).encode("utf-8")).hexdigest()
        return RunResult(
            ledger=self.ledger,
            trace=tuple(self.trace),
            trace_digest=digest,
            max_gross_exposure=max(
                (record.executed_gross for record in self.trace),
                default=0.0,
            ),
            max_amplified_exposure=max(
                (record.amplified_gross for record in self.trace),
                default=0.0,
            ),
            max_leverage=max(
                (record.leverage for record in self.trace),
                default=0.0,
            ),
            reflection_limited_events=sum(
                record.binding_constraint
                in {"continuation_reflection", "temporal_damage", "joint_reflection"}
                for record in self.trace
            ),
            max_reflection_utilization=max(
                (record.reflection_utilization for record in self.trace),
                default=0.0,
            ),
            max_temporal_damage_utilization=max(
                (
                    record.temporal_damage_utilization
                    for record in self.trace
                ),
                default=0.0,
            ),
            max_family_share=max(
                (record.max_family_share for record in self.trace),
                default=0.0,
            ),
            max_risk_factor_utilization=max(
                (
                    record.max_risk_factor_utilization
                    for record in self.trace
                ),
                default=0.0,
            ),
            timing_rejections=sum(
                decision.rejection_reason
                in {"missing_timing_evidence", "nonpositive_latency_margin"}
                for record in self.trace
                for decision in record.mirror
            ),
            observer_rejections=sum(
                decision.rejection_reason
                in {"observer_blindspot", "observer_parallax"}
                for record in self.trace
                for decision in record.mirror
            ),
            drift_rejections=sum(
                decision.rejection_reason == "model_drift_reanchor"
                for record in self.trace
                for decision in record.mirror
            ),
            drift_transitions=sum(
                update.drift_transitioned
                for record in self.trace
                for update in record.state_updates
            ),
        )


def result_as_dict(result: RunResult) -> dict[str, object]:
    """Stable JSON-compatible summary used by the CLI and tests."""

    return {
        "committed_total": result.ledger.committed_total,
        "reactor_equity": result.ledger.reactor_equity,
        "screen_value": result.ledger.screen_value,
        "vault_value": result.ledger.vault_value,
        "finalized_objective_value": result.ledger.finalized_objective_value,
        "continuation_value": result.ledger.continuation_value,
        "balanced_objective_value": result.ledger.balanced_objective_value,
        "total_liquidation_value": result.ledger.total_liquidation_value,
        "net_result": result.ledger.net_result,
        "cumulative_gross_pnl": result.ledger.cumulative_pnl,
        "cumulative_costs": result.ledger.cumulative_costs,
        "external_shortfall": result.ledger.external_shortfall,
        "ruined": result.ledger.ruined,
        "events": len(result.trace),
        "max_gross_exposure": result.max_gross_exposure,
        "max_amplified_exposure": result.max_amplified_exposure,
        "max_leverage": result.max_leverage,
        "reflection_limited_events": result.reflection_limited_events,
        "max_reflection_utilization": result.max_reflection_utilization,
        "max_temporal_damage_utilization": result.max_temporal_damage_utilization,
        "max_family_share": result.max_family_share,
        "max_risk_factor_utilization": result.max_risk_factor_utilization,
        "timing_rejections": result.timing_rejections,
        "observer_rejections": result.observer_rejections,
        "drift_rejections": result.drift_rejections,
        "drift_transitions": result.drift_transitions,
        "trace_digest": result.trace_digest,
    }
