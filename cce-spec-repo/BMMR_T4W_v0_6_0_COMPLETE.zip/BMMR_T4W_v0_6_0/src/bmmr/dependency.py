"""Dependency-graph diagnostics for local-to-global portfolio closure."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping


Graph = dict[str, set[str]]


@dataclass(frozen=True, slots=True)
class DependencyReport:
    nodes: tuple[str, ...]
    edges: tuple[tuple[str, str], ...]
    chordal: bool
    perfect_elimination_order: tuple[str, ...]
    fill_in_edges: tuple[tuple[str, str], ...]
    maximal_cliques: tuple[tuple[str, ...], ...]
    treewidth_upper_bound: int


def graph_from_risk_factors(
    routes: Iterable[tuple[str, tuple[str, ...]]],
) -> Graph:
    graph: Graph = {}
    factor_routes: dict[str, set[str]] = {}
    for route_id, factors in routes:
        graph.setdefault(route_id, set())
        for factor in set(factors):
            factor_routes.setdefault(factor, set()).add(route_id)
    for members in factor_routes.values():
        for left in members:
            graph[left].update(members - {left})
    return graph


def _mcs_order(graph: Mapping[str, set[str]]) -> tuple[str, ...]:
    weights = {node: 0 for node in graph}
    remaining = set(graph)
    selected: list[str] = []
    while remaining:
        node = max(remaining, key=lambda item: (weights[item], item))
        remaining.remove(node)
        selected.append(node)
        for neighbor in graph[node] & remaining:
            weights[neighbor] += 1
    return tuple(reversed(selected))


def _is_peo(graph: Mapping[str, set[str]], order: tuple[str, ...]) -> bool:
    position = {node: index for index, node in enumerate(order)}
    for node in order:
        later = sorted(
            (neighbor for neighbor in graph[node] if position[neighbor] > position[node]),
            key=position.__getitem__,
        )
        if not later:
            continue
        parent = later[0]
        if any(other not in graph[parent] for other in later[1:]):
            return False
    return True


def _triangulate(graph: Mapping[str, set[str]]) -> tuple[Graph, tuple[str, ...], tuple[tuple[str, str], ...]]:
    work: Graph = {node: set(neighbors) for node, neighbors in graph.items()}
    chordal: Graph = {node: set(neighbors) for node, neighbors in graph.items()}
    remaining = set(work)
    order: list[str] = []
    fill: set[tuple[str, str]] = set()
    while remaining:
        def missing_count(node: str) -> tuple[int, int, str]:
            neighbors = sorted(work[node] & remaining)
            missing = sum(
                right not in work[left]
                for index, left in enumerate(neighbors)
                for right in neighbors[index + 1 :]
            )
            return missing, len(neighbors), node

        node = min(remaining, key=missing_count)
        neighbors = sorted(work[node] & remaining)
        for index, left in enumerate(neighbors):
            for right in neighbors[index + 1 :]:
                if right not in work[left]:
                    edge = tuple(sorted((left, right)))
                    fill.add(edge)
                    work[left].add(right)
                    work[right].add(left)
                    chordal[left].add(right)
                    chordal[right].add(left)
        remaining.remove(node)
        order.append(node)
    return chordal, tuple(order), tuple(sorted(fill))


def _maximal_cliques(
    graph: Mapping[str, set[str]], order: tuple[str, ...]
) -> tuple[tuple[str, ...], ...]:
    position = {node: index for index, node in enumerate(order)}
    candidates = [
        frozenset(
            {node}
            | {
                neighbor
                for neighbor in graph[node]
                if position[neighbor] > position[node]
            }
        )
        for node in order
    ]
    maximal = {
        candidate
        for candidate in candidates
        if candidate and not any(candidate < other for other in candidates)
    }
    return tuple(sorted((tuple(sorted(item)) for item in maximal)))


def analyze_dependencies(
    routes: Iterable[tuple[str, tuple[str, ...]]],
) -> DependencyReport:
    graph = graph_from_risk_factors(routes)
    native_order = _mcs_order(graph)
    chordal = _is_peo(graph, native_order)
    if chordal:
        completed = {node: set(neighbors) for node, neighbors in graph.items()}
        order = native_order
        fill: tuple[tuple[str, str], ...] = ()
    else:
        completed, order, fill = _triangulate(graph)
    cliques = _maximal_cliques(completed, order)
    edges = tuple(
        sorted(
            tuple(sorted((node, neighbor)))
            for node, neighbors in graph.items()
            for neighbor in neighbors
            if node < neighbor
        )
    )
    width = max((len(clique) - 1 for clique in cliques), default=0)
    return DependencyReport(
        nodes=tuple(sorted(graph)),
        edges=edges,
        chordal=chordal,
        perfect_elimination_order=order,
        fill_in_edges=fill,
        maximal_cliques=cliques,
        treewidth_upper_bound=width,
    )
