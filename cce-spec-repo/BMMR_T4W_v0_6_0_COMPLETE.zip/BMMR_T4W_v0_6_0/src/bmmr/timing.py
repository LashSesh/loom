"""Temporal realizability primitives for BMMR.

The module turns the informal requirement "detect deviation before capital is
destroyed" into two explicit inequalities:

    loop_latency < edge_lifetime
    aggregate_damage(loop_latency) <= continuation_budget

It is deliberately free of exchange-specific assumptions.  Venue adapters
must supply the measured latency components and damage calibration.
"""

from __future__ import annotations

from dataclasses import dataclass
import math


@dataclass(frozen=True, slots=True)
class LatencyProfile:
    """Measured or declared components of one decision loop, in milliseconds."""

    feed_ms: float
    detect_ms: float
    infer_ms: float
    decide_ms: float
    transmit_ms: float
    fill_ms: float
    reconcile_ms: float

    def __post_init__(self) -> None:
        for name, value in (
            ("feed_ms", self.feed_ms),
            ("detect_ms", self.detect_ms),
            ("infer_ms", self.infer_ms),
            ("decide_ms", self.decide_ms),
            ("transmit_ms", self.transmit_ms),
            ("fill_ms", self.fill_ms),
            ("reconcile_ms", self.reconcile_ms),
        ):
            if value < 0 or not math.isfinite(value):
                raise ValueError(f"{name} must be non-negative and finite")

    @property
    def total_ms(self) -> float:
        return (
            self.feed_ms
            + self.detect_ms
            + self.infer_ms
            + self.decide_ms
            + self.transmit_ms
            + self.fill_ms
            + self.reconcile_ms
        )


@dataclass(frozen=True, slots=True)
class TemporalAssessment:
    timing_complete: bool
    loop_latency_ms: float | None
    edge_lifetime_ms: float | None
    latency_margin_ms: float | None
    edge_feasible: bool
    temporal_damage_rate: float | None
    temporal_capacity: float | None
    blindspot: str | None


def assess_temporal_realizability(
    latency: LatencyProfile | None,
    edge_lifetime_ms: float | None,
    gap_loss_rate: float,
    adverse_loss_rate_per_second: float,
    continuation_budget: float,
    required_margin_ms: float = 0.0,
) -> TemporalAssessment:
    """Assess the two temporal feasibility conditions for one route.

    ``temporal_damage_rate`` is the modeled loss fraction of notional over one
    complete control loop.  ``temporal_capacity`` is the largest single-route
    notional compatible with the supplied continuation budget.  Portfolio
    aggregation remains the reactor's responsibility.
    """

    if gap_loss_rate < 0 or not math.isfinite(gap_loss_rate):
        raise ValueError("gap_loss_rate must be non-negative and finite")
    if adverse_loss_rate_per_second < 0 or not math.isfinite(
        adverse_loss_rate_per_second
    ):
        raise ValueError(
            "adverse_loss_rate_per_second must be non-negative and finite"
        )
    if continuation_budget < 0 or not math.isfinite(continuation_budget):
        raise ValueError("continuation_budget must be non-negative and finite")
    if required_margin_ms < 0 or not math.isfinite(required_margin_ms):
        raise ValueError("required_margin_ms must be non-negative and finite")

    if latency is None:
        return TemporalAssessment(
            timing_complete=False,
            loop_latency_ms=None,
            edge_lifetime_ms=edge_lifetime_ms,
            latency_margin_ms=None,
            edge_feasible=False,
            temporal_damage_rate=None,
            temporal_capacity=None,
            blindspot="missing_latency_profile",
        )
    if edge_lifetime_ms is None:
        return TemporalAssessment(
            timing_complete=False,
            loop_latency_ms=latency.total_ms,
            edge_lifetime_ms=None,
            latency_margin_ms=None,
            edge_feasible=False,
            temporal_damage_rate=None,
            temporal_capacity=None,
            blindspot="missing_edge_lifetime",
        )
    if edge_lifetime_ms <= 0 or not math.isfinite(edge_lifetime_ms):
        raise ValueError("edge_lifetime_ms must be positive and finite")

    loop_ms = latency.total_ms
    margin_ms = edge_lifetime_ms - loop_ms
    damage_rate = gap_loss_rate + adverse_loss_rate_per_second * loop_ms / 1000.0
    capacity = (
        continuation_budget / damage_rate
        if damage_rate > 0
        else None
    )
    return TemporalAssessment(
        timing_complete=True,
        loop_latency_ms=loop_ms,
        edge_lifetime_ms=edge_lifetime_ms,
        latency_margin_ms=margin_ms,
        edge_feasible=margin_ms > required_margin_ms,
        temporal_damage_rate=damage_rate,
        temporal_capacity=capacity,
        blindspot=None,
    )
