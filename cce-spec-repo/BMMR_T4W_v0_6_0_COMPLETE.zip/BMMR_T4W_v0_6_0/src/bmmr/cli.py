"""Command-line demonstration of the executable BMMR kernel."""

from __future__ import annotations

import argparse
from dataclasses import asdict
import json

from .core import (
    Frame,
    Reactor,
    ReactorConfig,
    RouteObservation,
    result_as_dict,
)
from .observer import ObserverEstimate
from .timing import LatencyProfile


def demo_frames(events: int = 16) -> tuple[Frame, ...]:
    """Synthetic proof scenario, intentionally not market calibration."""

    frames: list[Frame] = []
    for event_id in range(events):
        regime_boost = min(event_id, 8) * 0.0015
        frames.append(
            Frame(
                event_id=event_id,
                observations=(
                    RouteObservation(
                        route_id="A-B-C-A",
                        predicted_edge=0.046 + regime_boost,
                        realized_return=0.061 + regime_boost,
                        cost_rate=0.003,
                        capacity=10_000.0,
                        stress_loss_rate=0.22,
                        evidence_family="triangular_cycle",
                        observer_estimates=(
                            ObserverEstimate("orderbook", 0.044 + regime_boost),
                            ObserverEstimate("crossvenue", 0.048 + regime_boost),
                        ),
                        latency=LatencyProfile(6, 4, 5, 2, 4, 14, 3),
                        edge_lifetime_ms=180,
                        gap_loss_rate=0.006,
                        adverse_loss_rate_per_second=0.05,
                        risk_factors=("phase_A", "liquidity_core", "triangle"),
                    ),
                    RouteObservation(
                        route_id="A-D-E-A",
                        predicted_edge=0.037 + regime_boost / 2,
                        realized_return=0.049 + regime_boost / 2,
                        cost_rate=0.003,
                        capacity=7_500.0,
                        stress_loss_rate=0.18,
                        evidence_family="cross_venue_cycle",
                        observer_estimates=(
                            ObserverEstimate("orderbook", 0.035 + regime_boost / 2),
                            ObserverEstimate("basis", 0.039 + regime_boost / 2),
                        ),
                        latency=LatencyProfile(7, 4, 6, 2, 5, 16, 4),
                        edge_lifetime_ms=210,
                        gap_loss_rate=0.005,
                        adverse_loss_rate_per_second=0.04,
                        risk_factors=("phase_A", "liquidity_core", "crossvenue"),
                    ),
                    RouteObservation(
                        route_id="A-X-A",
                        predicted_edge=-0.008,
                        realized_return=-0.012,
                        cost_rate=0.002,
                        capacity=5_000.0,
                        stress_loss_rate=0.25,
                        evidence_family="rejected_control",
                        observer_estimates=(
                            ObserverEstimate("control_a", -0.010),
                            ObserverEstimate("control_b", -0.006),
                        ),
                        latency=LatencyProfile(5, 3, 4, 2, 3, 12, 3),
                        edge_lifetime_ms=160,
                        gap_loss_rate=0.008,
                        adverse_loss_rate_per_second=0.06,
                        risk_factors=("phase_A", "control"),
                    ),
                ),
            )
        )
    return tuple(frames)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the deterministic BMMR reflection-boundary scenario."
    )
    parser.add_argument(
        "--events",
        type=int,
        default=16,
        help="number of synthetic event frames",
    )
    parser.add_argument(
        "--trace",
        action="store_true",
        help="include the complete canonical decision trace",
    )
    args = parser.parse_args()

    if args.events < 1:
        parser.error("--events must be at least 1")

    result = Reactor(ReactorConfig()).run(demo_frames(args.events))
    output = result_as_dict(result)
    if args.trace:
        output["trace"] = [asdict(record) for record in result.trace]
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
