"""Dimensionless thermodynamic workbody for BMMR-T4W.

This module implements an operational phase-field model (grade G1).  Its
free energy is a dimensionless storage/Lyapunov functional.  It becomes a
physical thermodynamic model (grade G2) only after an adapter supplies units,
heat-bath semantics, calibrated constitutive parameters and measured energy
and entropy balances.

The phase fraction is non-conserved (Allen--Cahn-like).  The carried resource
amount is conserved and moves through a deterministic graph diffusion step.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from enum import Enum
from math import isfinite, sqrt
from typing import Mapping


TOLERANCE = 1e-12


class ThermodynamicGrade(str, Enum):
    ANALOGY = "G0_analogy"
    OPERATIONAL = "G1_operational_thermodynamics"
    PHYSICAL = "G2_physical_thermodynamics"


def _finite(name: str, value: float) -> None:
    if not isfinite(value):
        raise ValueError(f"{name} must be finite")


def _unit_interval(name: str, value: float) -> None:
    _finite(name, value)
    if not 0.0 <= value <= 1.0:
        raise ValueError(f"{name} must lie in [0, 1]")


@dataclass(frozen=True, slots=True)
class PhaseTile:
    tile_id: str
    phase_fraction: float
    resource_amount: float
    resource_capacity: float
    temperature: float
    transition_temperature: float = 1.0
    latent_bias: float = 1.0
    barrier: float = 2.0
    kinetic_mobility: float = 1.0
    control_drive: float = 0.0

    def __post_init__(self) -> None:
        if not self.tile_id:
            raise ValueError("tile_id must be non-empty")
        _unit_interval("phase_fraction", self.phase_fraction)
        for name, value in (
            ("resource_amount", self.resource_amount),
            ("resource_capacity", self.resource_capacity),
            ("temperature", self.temperature),
            ("transition_temperature", self.transition_temperature),
            ("latent_bias", self.latent_bias),
            ("barrier", self.barrier),
            ("kinetic_mobility", self.kinetic_mobility),
        ):
            _finite(name, value)
            if value < 0.0:
                raise ValueError(f"{name} must be non-negative")
        _finite("control_drive", self.control_drive)
        if self.resource_capacity <= 0.0:
            raise ValueError("resource_capacity must be positive")
        if self.resource_amount > self.resource_capacity + TOLERANCE:
            raise ValueError("resource_amount cannot exceed capacity")
        if self.transition_temperature <= 0.0:
            raise ValueError("transition_temperature must be positive")
        if self.barrier <= 0.0:
            raise ValueError("barrier must be positive")

    @property
    def phase_bias(self) -> float:
        """Free-energy difference favouring locked (+) or mobile (-)."""

        thermal = self.latent_bias * (
            1.0 - self.temperature / self.transition_temperature
        )
        return thermal - self.control_drive

    @property
    def local_free_energy(self) -> float:
        q = self.phase_fraction
        return self.barrier * q * q * (1.0 - q) * (1.0 - q) + self.phase_bias * q

    @property
    def local_gradient(self) -> float:
        q = self.phase_fraction
        return 2.0 * self.barrier * q * (1.0 - q) * (1.0 - 2.0 * q) + self.phase_bias

    @property
    def resource_potential(self) -> float:
        return self.resource_amount / self.resource_capacity

    @property
    def phase_label(self) -> str:
        if self.phase_fraction <= 0.2:
            return "locked_terminal"
        if self.phase_fraction >= 0.8:
            return "mobile_terminal"
        return "interfacial"


@dataclass(frozen=True, slots=True, order=True)
class FieldCoupling:
    left: str
    right: str
    phase_strength: float
    transport_conductance: float
    frozen_leak: float = 0.0

    def __post_init__(self) -> None:
        if not self.left or not self.right or self.left == self.right:
            raise ValueError("coupling requires two distinct tile ids")
        if self.left > self.right:
            raise ValueError("coupling endpoints must be stored in canonical order")
        for name, value in (
            ("phase_strength", self.phase_strength),
            ("transport_conductance", self.transport_conductance),
            ("frozen_leak", self.frozen_leak),
        ):
            _finite(name, value)
            if value < 0.0:
                raise ValueError(f"{name} must be non-negative")


@dataclass(frozen=True, slots=True)
class Workbody:
    tiles: tuple[PhaseTile, ...]
    couplings: tuple[FieldCoupling, ...]
    grade: ThermodynamicGrade = ThermodynamicGrade.OPERATIONAL

    def __post_init__(self) -> None:
        ids = [tile.tile_id for tile in self.tiles]
        if not ids or len(ids) != len(set(ids)):
            raise ValueError("workbody tile ids must be non-empty and unique")
        if tuple(ids) != tuple(sorted(ids)):
            raise ValueError("tiles must be in canonical id order")
        known = set(ids)
        edge_ids = [(edge.left, edge.right) for edge in self.couplings]
        if len(edge_ids) != len(set(edge_ids)):
            raise ValueError("couplings must be unique")
        if tuple(edge_ids) != tuple(sorted(edge_ids)):
            raise ValueError("couplings must be in canonical endpoint order")
        if any(edge.left not in known or edge.right not in known for edge in self.couplings):
            raise ValueError("coupling references an unknown tile")

    @property
    def tile_map(self) -> dict[str, PhaseTile]:
        return {tile.tile_id: tile for tile in self.tiles}

    @property
    def phase_free_energy(self) -> float:
        by_id = self.tile_map
        local = sum(tile.local_free_energy for tile in self.tiles)
        interface = sum(
            0.5
            * edge.phase_strength
            * (by_id[edge.left].phase_fraction - by_id[edge.right].phase_fraction) ** 2
            for edge in self.couplings
        )
        return local + interface

    @property
    def resource_storage(self) -> float:
        return sum(
            tile.resource_amount * tile.resource_amount / (2.0 * tile.resource_capacity)
            for tile in self.tiles
        )

    @property
    def total_storage(self) -> float:
        return self.phase_free_energy + self.resource_storage

    @property
    def total_resource(self) -> float:
        return sum(tile.resource_amount for tile in self.tiles)

    @property
    def mean_phase_fraction(self) -> float:
        return sum(tile.phase_fraction for tile in self.tiles) / len(self.tiles)

    @property
    def phase_consensus(self) -> float:
        total_weight = sum(edge.phase_strength for edge in self.couplings)
        if total_weight <= TOLERANCE:
            return 1.0
        by_id = self.tile_map
        disagreement = sum(
            edge.phase_strength
            * (by_id[edge.left].phase_fraction - by_id[edge.right].phase_fraction) ** 2
            for edge in self.couplings
        )
        return max(0.0, min(1.0, 1.0 - disagreement / total_weight))

    def with_phase_fractions(self, values: Mapping[str, float]) -> "Workbody":
        unknown = set(values) - set(self.tile_map)
        if unknown:
            raise KeyError(f"unknown tile ids: {sorted(unknown)}")
        tiles = tuple(
            replace(tile, phase_fraction=values.get(tile.tile_id, tile.phase_fraction))
            for tile in self.tiles
        )
        return replace(self, tiles=tiles)

    def with_resource_amounts(self, values: Mapping[str, float]) -> "Workbody":
        unknown = set(values) - set(self.tile_map)
        if unknown:
            raise KeyError(f"unknown tile ids: {sorted(unknown)}")
        tiles = tuple(
            replace(tile, resource_amount=values.get(tile.tile_id, tile.resource_amount))
            for tile in self.tiles
        )
        return replace(self, tiles=tiles)

    def with_controls(
        self,
        *,
        temperatures: Mapping[str, float] | None = None,
        drives: Mapping[str, float] | None = None,
    ) -> "Workbody":
        temperatures = temperatures or {}
        drives = drives or {}
        unknown = (set(temperatures) | set(drives)) - set(self.tile_map)
        if unknown:
            raise KeyError(f"unknown tile ids: {sorted(unknown)}")
        tiles = tuple(
            replace(
                tile,
                temperature=temperatures.get(tile.tile_id, tile.temperature),
                control_drive=drives.get(tile.tile_id, tile.control_drive),
            )
            for tile in self.tiles
        )
        return replace(self, tiles=tiles)

    def phase_gradient(self) -> dict[str, float]:
        by_id = self.tile_map
        gradient = {tile.tile_id: tile.local_gradient for tile in self.tiles}
        for edge in self.couplings:
            delta = by_id[edge.left].phase_fraction - by_id[edge.right].phase_fraction
            gradient[edge.left] += edge.phase_strength * delta
            gradient[edge.right] -= edge.phase_strength * delta
        return gradient

    def to_dict(self) -> dict[str, object]:
        return {
            "grade": self.grade.value,
            "tiles": [asdict(tile) | {"phase_label": tile.phase_label} for tile in self.tiles],
            "couplings": [asdict(edge) for edge in self.couplings],
            "observables": {
                "phase_free_energy": self.phase_free_energy,
                "resource_storage": self.resource_storage,
                "total_storage": self.total_storage,
                "total_resource": self.total_resource,
                "mean_phase_fraction": self.mean_phase_fraction,
                "phase_consensus": self.phase_consensus,
            },
        }


@dataclass(frozen=True, slots=True)
class RelaxationReport:
    before_energy: float
    after_energy: float
    dissipated: float
    gradient_norm: float
    accepted_step: float
    iterations: int
    monotone: bool


def relax_phase(
    workbody: Workbody,
    *,
    step: float = 0.25,
    iterations: int = 1,
    max_backtracks: int = 40,
) -> tuple[Workbody, RelaxationReport]:
    """Projected gradient relaxation with deterministic backtracking.

    For fixed controls this function accepts only non-increasing phase free
    energy.  It therefore certifies an operational dissipation inequality; it
    does not claim a physical heat balance.
    """

    _finite("step", step)
    if step <= 0.0:
        raise ValueError("step must be positive")
    if iterations < 1 or max_backtracks < 1:
        raise ValueError("iterations and max_backtracks must be positive")

    initial = workbody.phase_free_energy
    current = workbody
    last_step = 0.0
    first_gradient = current.phase_gradient()
    gradient_norm = sqrt(sum(value * value for value in first_gradient.values()))

    for _ in range(iterations):
        gradient = current.phase_gradient()
        trial_step = step
        accepted = current
        for _backtrack in range(max_backtracks):
            candidates = {}
            for tile in current.tiles:
                raw = tile.phase_fraction - (
                    trial_step * tile.kinetic_mobility * gradient[tile.tile_id]
                )
                candidates[tile.tile_id] = max(0.0, min(1.0, raw))
            proposal = current.with_phase_fractions(candidates)
            if proposal.phase_free_energy <= current.phase_free_energy + TOLERANCE:
                accepted = proposal
                last_step = trial_step
                break
            trial_step *= 0.5
        if accepted is current:
            break
        current = accepted

    final = current.phase_free_energy
    dissipated = max(0.0, initial - final)
    return current, RelaxationReport(
        before_energy=initial,
        after_energy=final,
        dissipated=dissipated,
        gradient_norm=gradient_norm,
        accepted_step=last_step,
        iterations=iterations,
        monotone=final <= initial + TOLERANCE,
    )


@dataclass(frozen=True, slots=True)
class DrivenCycleReport:
    initial_energy: float
    driven_energy: float
    final_energy: float
    external_work: float
    dissipated: float
    balance_residual: float
    passive: bool
    monotone_relaxation: bool


def driven_cycle(
    workbody: Workbody,
    *,
    temperatures: Mapping[str, float] | None = None,
    drives: Mapping[str, float] | None = None,
    step: float = 0.25,
    iterations: int = 8,
) -> tuple[Workbody, DrivenCycleReport]:
    initial = workbody.phase_free_energy
    controlled = workbody.with_controls(temperatures=temperatures, drives=drives)
    driven = controlled.phase_free_energy
    external_work = driven - initial
    relaxed, relaxation = relax_phase(
        controlled,
        step=step,
        iterations=iterations,
    )
    final = relaxed.phase_free_energy
    residual = (final - initial) - (external_work - relaxation.dissipated)
    return relaxed, DrivenCycleReport(
        initial_energy=initial,
        driven_energy=driven,
        final_energy=final,
        external_work=external_work,
        dissipated=relaxation.dissipated,
        balance_residual=residual,
        passive=not temperatures and not drives,
        monotone_relaxation=relaxation.monotone,
    )


@dataclass(frozen=True, slots=True)
class TransportReport:
    before_storage: float
    after_storage: float
    dissipated: float
    resource_before: float
    resource_after: float
    conservation_residual: float
    transfers: tuple[tuple[str, str, float], ...]


def transport_step(workbody: Workbody, *, step: float = 0.25) -> tuple[Workbody, TransportReport]:
    """Move a conserved carrier down its graph potential.

    The phase fraction gates the edge conductance.  Each pairwise transfer is
    clipped at the pair's equal-potential point, so resource storage cannot
    increase.  Edges are processed in canonical order for replayability.
    """

    _finite("step", step)
    if step <= 0.0:
        raise ValueError("step must be positive")
    before_storage = workbody.resource_storage
    before_resource = workbody.total_resource
    tiles = workbody.tile_map
    amounts = {tile_id: tile.resource_amount for tile_id, tile in tiles.items()}
    transfers: list[tuple[str, str, float]] = []

    for edge in workbody.couplings:
        left = tiles[edge.left]
        right = tiles[edge.right]
        left_mu = amounts[edge.left] / left.resource_capacity
        right_mu = amounts[edge.right] / right.resource_capacity
        delta_mu = left_mu - right_mu
        if abs(delta_mu) <= TOLERANCE:
            continue
        phase_gate = edge.frozen_leak + (
            (1.0 - edge.frozen_leak)
            * left.phase_fraction
            * right.phase_fraction
        )
        conductance = edge.transport_conductance * phase_gate
        requested = step * conductance * abs(delta_mu)
        if requested <= TOLERANCE:
            continue
        if delta_mu > 0.0:
            source, target = left, right
        else:
            source, target = right, left
        equalising = abs(delta_mu) / (
            1.0 / source.resource_capacity + 1.0 / target.resource_capacity
        )
        amount = min(
            requested,
            equalising,
            amounts[source.tile_id],
            target.resource_capacity - amounts[target.tile_id],
        )
        if amount <= TOLERANCE:
            continue
        amounts[source.tile_id] -= amount
        amounts[target.tile_id] += amount
        transfers.append((source.tile_id, target.tile_id, amount))

    updated = workbody.with_resource_amounts(amounts)
    after_storage = updated.resource_storage
    after_resource = updated.total_resource
    return updated, TransportReport(
        before_storage=before_storage,
        after_storage=after_storage,
        dissipated=max(0.0, before_storage - after_storage),
        resource_before=before_resource,
        resource_after=after_resource,
        conservation_residual=after_resource - before_resource,
        transfers=tuple(transfers),
    )
