"""BMMR causal and wealth-phase evaluation laboratory command line."""

from __future__ import annotations

import argparse
from pathlib import Path

from .core import ReactorConfig
from .dataset import load_dataset
from .experiment import run_benchmark, run_experiment, walk_forward
from .operation_algebra import reference_operation_witness
from .reporting import write_lab_artifacts
from .stress import stress_suite
from .wealth_phase import load_wealth_phase, wealth_phase_artifact


DEFAULT_WEALTH_PHASE = (
    Path(__file__).resolve().parents[2] / "examples" / "demo_wealth_phase.json"
)


def full_run(
    dataset_path: str | Path,
    output: str | Path,
    folds: int = 4,
    wealth_phase_path: str | Path | None = None,
) -> None:
    dataset = load_dataset(dataset_path)
    loaded_wealth = load_wealth_phase(
        wealth_phase_path if wealth_phase_path is not None else DEFAULT_WEALTH_PHASE
    )
    wealth = wealth_phase_artifact(loaded_wealth)
    operation_witness = reference_operation_witness()
    config = ReactorConfig()
    dynamic = run_experiment(
        dataset, config, "dynamic_reflection", loaded_wealth.digest
    )
    replay = run_experiment(
        dataset, config, "dynamic_reflection", loaded_wealth.digest
    )
    replay_match = (
        dynamic.descriptor.run_id == replay.descriptor.run_id
        and dynamic.result.trace_digest == replay.result.trace_digest
        and dynamic.result.trace == replay.result.trace
    )
    benchmark = run_benchmark(dataset, config, loaded_wealth.digest)
    stresses = {
        name: run_experiment(
            stressed,
            config,
            f"stress_{name}",
            loaded_wealth.digest,
        )
        for name, stressed in stress_suite(dataset).items()
    }
    fold_count = min(folds, len(dataset.frames))
    fold_results = walk_forward(
        dataset, config, fold_count, loaded_wealth.digest
    )
    write_lab_artifacts(
        output, dataset, config, dynamic, benchmark, stresses,
        fold_results, replay_match, wealth, operation_witness,
    )
    print(f"run_id={dynamic.descriptor.run_id}")
    print(f"dataset_digest={dataset.digest}")
    print(f"trace_digest={dynamic.result.trace_digest}")
    print(f"deterministic_replay_match={str(replay_match).lower()}")
    print(f"output={Path(output).resolve()}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the BMMR v0.5 wealth-phase evaluation and replay laboratory."
    )
    parser.add_argument("command", choices=("full",), nargs="?", default="full")
    parser.add_argument("--dataset", required=True, help="CSV or JSONL dataset")
    parser.add_argument(
        "--wealth-phase",
        default=str(DEFAULT_WEALTH_PHASE),
        help="wealth-phase JSON input",
    )
    parser.add_argument("--output", default="output/lab", help="artifact directory")
    parser.add_argument("--folds", type=int, default=4, help="chronological folds")
    args = parser.parse_args()
    if args.folds < 2:
        parser.error("--folds must be at least 2")
    full_run(args.dataset, args.output, args.folds, args.wealth_phase)


if __name__ == "__main__":
    main()
