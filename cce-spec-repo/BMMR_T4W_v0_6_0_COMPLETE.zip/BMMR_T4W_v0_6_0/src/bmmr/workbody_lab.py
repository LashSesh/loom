"""Deterministic reference laboratory for the BMMR-T4W workbody."""

from __future__ import annotations

import argparse
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path
from typing import Any, Sequence

from .tesseract import (
    TesseractMode,
    canonical_transition_path,
    changed_axis,
    topology_certificate as tesseract_topology_certificate,
)
from .thermodynamic_workbody import (
    FieldCoupling,
    PhaseTile,
    Workbody,
    driven_cycle,
    transport_step,
)
from .tpomc_repairs import (
    damping_certificate,
    dimension_certificate,
    mandorla_certificate,
    observability_certificate,
    support_certificate,
    topology_certificate,
)
from .wealth_phase import load_wealth_phase, wealth_phase_artifact


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_WEALTH = PROJECT_ROOT / "examples" / "demo_wealth_phase.json"


def canonical_json(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def digest_bytes(value: bytes) -> str:
    return sha256(value).hexdigest()


def digest_file(path: Path) -> str:
    return digest_bytes(path.read_bytes())


def write_json(path: Path, value: object) -> None:
    path.write_bytes(canonical_json(value) + b"\n")


def reference_workbody() -> Workbody:
    tiles = tuple(
        sorted(
            (
                PhaseTile("A", 0.05, 0.90, 1.0, 0.60),
                PhaseTile("B", 0.05, 0.10, 1.0, 0.60),
                PhaseTile("C", 0.05, 0.00, 1.0, 0.60),
                PhaseTile("D", 0.05, 0.00, 1.0, 0.60),
            ),
            key=lambda tile: tile.tile_id,
        )
    )
    couplings = tuple(
        sorted(
            (
                FieldCoupling("A", "B", 4.0, 1.0),
                FieldCoupling("A", "D", 4.0, 1.0),
                FieldCoupling("B", "C", 4.0, 1.0),
                FieldCoupling("C", "D", 4.0, 1.0),
            ),
            key=lambda edge: (edge.left, edge.right),
        )
    )
    return Workbody(tiles, couplings)


def mode_from_wealth(snapshot: dict[str, Any]) -> TesseractMode:
    valuation = snapshot["valuation"]
    threshold = snapshot["thresholds"]["anisotropy_order_threshold"]
    return TesseractMode.from_observables(
        accounting_closed=valuation["accounting_closed"],
        liquid=valuation["liquid"],
        solvent=valuation["solvent"],
        mobility=float(valuation["liquid"]),
        mobility_threshold=0.5,
        order_parameter=snapshot["anisotropy"]["order_parameter"],
        order_threshold=threshold,
        causal_information_active=snapshot["informationally_active"],
    )


def edge_path_artifact(path: tuple[TesseractMode, ...]) -> dict[str, object]:
    transitions = []
    for index, (source, target) in enumerate(zip(path, path[1:])):
        axis = changed_axis(source, target)
        transitions.append(
            {
                "index": index,
                "source": source.mode_id,
                "target": target.mode_id,
                "axis": axis.name.lower(),
                "direction": target.bits[int(axis)] - source.bits[int(axis)],
                "hamming_distance": 1,
            }
        )
    return {
        "source": path[0].mode_id,
        "target": path[-1].mode_id,
        "vertices": [mode.mode_id for mode in path],
        "transitions": transitions,
    }


def phase_field_artifact() -> dict[str, object]:
    initial = reference_workbody()
    initial_mode = TesseractMode(1, 0, int(initial.phase_consensus >= 0.95), 0)

    driven, drive_report = driven_cycle(
        initial,
        temperatures={"A": 2.0},
        drives={"A": 3.0},
        step=0.10,
        iterations=100,
    )
    transport_reports = []
    transported = driven
    for _ in range(24):
        transported, transport_report = transport_step(transported, step=0.50)
        transport_reports.append(transport_report)
    final_mode = TesseractMode(
        1,
        int(transported.mean_phase_fraction >= 0.80),
        int(transported.phase_consensus >= 0.95),
        1,
    )
    path = canonical_transition_path(initial_mode, final_mode)

    first_transport = next(
        (report for report in transport_reports if report.transfers),
        transport_reports[0],
    )
    final_transport = transport_reports[-1]
    return {
        "schema": "bmmr.t4w.phase-field.v1",
        "semantics": (
            "dimensionless G1 storage and dissipation; no claim of physical heat, "
            "temperature or material constants"
        ),
        "initial": initial.to_dict(),
        "drive": {
            "controls": {"temperature": {"A": 2.0}, "drive": {"A": 3.0}},
            "report": asdict(drive_report),
            "state": driven.to_dict(),
        },
        "transport": {
            "steps": len(transport_reports),
            "first_active_report": asdict(first_transport),
            "final_report": asdict(final_transport),
            "state": transported.to_dict(),
        },
        "invariants": {
            "phase_relaxation_nonincreasing": drive_report.monotone_relaxation,
            "energy_balance_residual": drive_report.balance_residual,
            "resource_conserved": abs(final_transport.conservation_residual) <= 1e-12,
            "resource_storage_nonincreasing": all(
                report.after_storage <= report.before_storage + 1e-12
                for report in transport_reports
            ),
            "phase_transition_observed": initial_mode != final_mode,
        },
        "mode_path": edge_path_artifact(path),
    }


def tpomc_repair_artifact() -> dict[str, object]:
    isometric_stitcher = ((1.0, 0.0), (0.0, 1.0), (0.0, 0.0))
    isometric_mirror = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0))
    zero_stitcher = ((0.0, 0.0), (0.0, 0.0), (0.0, 0.0))
    zero_mirror = ((0.0, 0.0, 0.0), (0.0, 0.0, 0.0))

    nested_good = support_certificate(
        (frozenset({"a", "b", "c"}), frozenset({"b", "c"}), frozenset({"c"})),
        ("a", "b", "c"),
    )
    nested_bad = support_certificate(
        (frozenset({"a", "b", "c"}), frozenset({"b", "c"}), frozenset({"c"})),
        ("a", "b", "a"),
    )
    return {
        "schema": "bmmr.t4w.tpomc-repairs.v1",
        "adjunction_vs_observability": {
            "certified_isometry": observability_certificate(
                isometric_stitcher, isometric_mirror
            ).to_dict(),
            "zero_operator_counterexample": observability_certificate(
                zero_stitcher, zero_mirror
            ).to_dict(),
        },
        "mandorla": {
            "measured_nonempty": asdict(
                mandorla_certificate(
                    (0.8, 0.9, 0.2),
                    (0.9, 0.8, 0.9),
                    threshold_u=0.75,
                    threshold_v=0.75,
                    minimum_measure=0.5,
                )
            ),
            "regular_but_empty_counterexample": asdict(
                mandorla_certificate(
                    (0.0, 1.0),
                    (1.0, 0.0),
                    threshold_u=0.75,
                    threshold_v=0.75,
                    minimum_measure=0.1,
                )
            ),
        },
        "shrinking_support": {
            "certified": asdict(nested_good),
            "unsupported_state_counterexample": asdict(nested_bad),
        },
        "identity_damping": {
            "already_contractive": asdict(damping_certificate(0.8, 0.25)),
            "expansive_counterexample": asdict(damping_certificate(1.2, 0.50)),
        },
        "effective_dimension": asdict(dimension_certificate(2.0, (1.0, 0.1, 0.0))),
        "topological_condensation": asdict(
            topology_certificate(
                ((1, 1, 0), (1, 1, 0), (1, 1, 0)),
                ((1, 1, 0), (1, 0, 0), (1, 0, 0)),
            )
        ),
    }


def wealth_tesseract_artifact(wealth_path: Path) -> dict[str, object]:
    wealth = wealth_phase_artifact(load_wealth_phase(wealth_path))
    base_mode = mode_from_wealth(wealth["base"])
    stress_mode = mode_from_wealth(wealth["stress"])
    path = canonical_transition_path(base_mode, stress_mode)
    return {
        "schema": "bmmr.t4w.wealth-bridge.v1",
        "input_digest": digest_file(wealth_path),
        "base_regime": wealth["base"]["regime"],
        "stress_regime": wealth["stress"]["regime"],
        "base_mode": base_mode.mode_id,
        "stress_mode": stress_mode.mode_id,
        "mode_path": edge_path_artifact(path),
        "interpretation": (
            "The four bits are witnessed macro predicates; they are not spatial dimensions "
            "and they do not forecast returns."
        ),
    }


def source_code_digest() -> str:
    module_names = (
        "tesseract.py",
        "thermodynamic_workbody.py",
        "tpomc_repairs.py",
        "wealth_phase.py",
        "workbody_lab.py",
    )
    payload = []
    for name in module_names:
        path = Path(__file__).with_name(name)
        payload.append((name, digest_file(path)))
    return digest_bytes(canonical_json(payload))


def build_report(
    topology: dict[str, object],
    phase: dict[str, object],
    repairs: dict[str, object],
    wealth: dict[str, object],
    run_id: str,
) -> str:
    phase_initial = phase["initial"]["observables"]
    phase_final = phase["transport"]["state"]["observables"]
    damping = repairs["identity_damping"]["expansive_counterexample"]
    zero_obs = repairs["adjunction_vs_observability"]["zero_operator_counterexample"]
    return f"""# BMMR-T4W v0.6.0 – Referenzlauf

Run-ID: `{run_id}`

## Ergebnis

Der Tesserakt ist kombinatorisch geschlossen: 16 Knoten, 32 Kanten,
24 Quadratflächen, 8 Kuben und ein 4-Körper; `boundary_squared_zero` ist
`{str(topology['boundary_squared_zero']).lower()}`.

Der dimensionlose Phasenfeld-Zeuge wechselte von Modus
`{phase['mode_path']['source']}` nach `{phase['mode_path']['target']}`.
Die mittlere mobile Phase stieg von {phase_initial['mean_phase_fraction']:.6f}
auf {phase_final['mean_phase_fraction']:.6f}. Die konservierte Ressource blieb
bei {phase_final['total_resource']:.6f}; ihr Speicherfunktional sank von
{phase_initial['resource_storage']:.6f} auf {phase_final['resource_storage']:.6f}.

Die Wealth-Bridge bildet den synthetischen Basiszustand auf
`{wealth['base_mode']}` und den Stresszustand auf `{wealth['stress_mode']}` ab.
Der diagonale Wechsel wird in einzelne Facettenübergänge zerlegt.

## Negative Zeugen

- Der Null-Stitcher erfüllt die Adjunktion, ist aber beobachtbar =
  `{str(zero_obs['observable']).lower()}`.
- Bei L=1.2 und Identitätsgewicht 0.5 lautet die allgemeine Schranke
  {damping['mixed_lipschitz_bound']:.6f}; Kontraktion =
  `{str(damping['contraction_certified']).lower()}`.
- Eine leere Mandorla und eine nur operational geschlossene Topologie bleiben
  im JSON-Artefakt sichtbar.

## Geltungsgrenze

Der Lauf zertifiziert eine G1-Systemthermodynamik: dimensionslose
Speicherfunktion, Dissipation, konservierten Transport, Phasengrenzen und
Replay. Er zertifiziert keine Joule-, Kelvin-, Wärmebad-, Markt- oder
Profitabilitätsphysik.
"""


def run_lab(output: Path, wealth_path: Path = DEFAULT_WEALTH) -> dict[str, object]:
    output.mkdir(parents=True, exist_ok=True)
    topology = tesseract_topology_certificate()
    phase = phase_field_artifact()
    repairs = tpomc_repair_artifact()
    wealth = wealth_tesseract_artifact(wealth_path)
    descriptor_core = {
        "schema": "bmmr.t4w.run-descriptor.v1",
        "version": "0.6.0",
        "code_digest": source_code_digest(),
        "wealth_input_digest": digest_file(wealth_path),
        "numeric_domain": "IEEE-754 binary64 with deterministic ordering and 1e-12 checks",
        "ambient_randomness": False,
        "ambient_time": False,
        "thermodynamic_grade": "G1_operational_thermodynamics",
    }
    run_id = digest_bytes(canonical_json(descriptor_core))
    descriptor = descriptor_core | {"run_id": run_id}

    write_json(output / "tesseract_topology.json", topology)
    write_json(output / "phase_field.json", phase)
    write_json(output / "tpomc_repairs.json", repairs)
    write_json(output / "wealth_tesseract.json", wealth)
    write_json(output / "run_descriptor.json", descriptor)
    (output / "REPORT.md").write_text(
        build_report(topology, phase, repairs, wealth, run_id),
        encoding="utf-8",
    )

    manifest_path = output / "MANIFEST.sha256.json"
    files = sorted(
        path
        for path in output.iterdir()
        if path.is_file() and path != manifest_path
    )
    manifest = {
        "schema": "bmmr.t4w.manifest.v1",
        "run_id": run_id,
        "files": {path.name: digest_file(path) for path in files},
    }
    write_json(manifest_path, manifest)
    return {
        "run_id": run_id,
        "output": str(output),
        "files": sorted((*manifest["files"], "MANIFEST.sha256.json")),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=PROJECT_ROOT / "output" / "t4w_v0_6")
    parser.add_argument("--wealth-phase", type=Path, default=DEFAULT_WEALTH)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    print(json.dumps(run_lab(args.output, args.wealth_phase), indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
