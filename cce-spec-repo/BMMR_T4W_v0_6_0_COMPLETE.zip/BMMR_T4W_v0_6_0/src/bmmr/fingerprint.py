"""Canonical implementation fingerprint used by the run descriptor."""

from __future__ import annotations

from hashlib import sha256
from pathlib import Path


def implementation_digest(package_root: str | Path | None = None) -> str:
    root = (
        Path(package_root)
        if package_root is not None
        else Path(__file__).resolve().parent
    )
    files = sorted(path for path in root.rglob("*.py") if path.is_file())
    digest = sha256()
    for path in files:
        relative = path.relative_to(root).as_posix().encode("utf-8")
        payload = path.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(payload).to_bytes(8, "big"))
        digest.update(payload)
    return digest.hexdigest()
