"""Deterministic counterfactual stress transformations."""

from __future__ import annotations

from dataclasses import replace

from .core import Frame
from .dataset import DatasetFrame, MarketDataset


def stress_dataset(dataset: MarketDataset, scenario: str) -> MarketDataset:
    if scenario not in {
        "base",
        "adverse_returns",
        "fee_shock",
        "capacity_collapse",
        "latency_spike",
        "observer_divergence",
        "combined",
    }:
        raise ValueError(f"unknown stress scenario: {scenario}")
    if scenario == "base":
        return dataset

    transformed: list[DatasetFrame] = []
    for item in dataset.frames:
        observations = []
        for observation in item.frame.observations:
            realized = observation.realized_return
            cost = observation.cost_rate
            capacity = observation.capacity
            stress_loss = observation.stress_loss_rate
            latency = observation.latency
            edge_lifetime_ms = observation.edge_lifetime_ms
            observer_estimates = observation.observer_estimates
            if scenario in {"adverse_returns", "combined"}:
                realized -= max(0.0125, abs(realized) * 0.65)
                stress_loss *= 1.35
            if scenario in {"fee_shock", "combined"}:
                cost = cost * 2.5 + 0.001
            if scenario in {"capacity_collapse", "combined"}:
                capacity *= 0.20
            if scenario in {"latency_spike", "combined"} and latency is not None:
                latency = replace(
                    latency,
                    feed_ms=latency.feed_ms * 2.0,
                    detect_ms=latency.detect_ms * 2.5,
                    infer_ms=latency.infer_ms * 3.0,
                    decide_ms=latency.decide_ms * 2.0,
                    transmit_ms=latency.transmit_ms * 2.0,
                    fill_ms=latency.fill_ms * 5.0,
                    reconcile_ms=latency.reconcile_ms * 2.0,
                )
                if edge_lifetime_ms is not None:
                    edge_lifetime_ms *= 0.55
            if scenario in {"observer_divergence", "combined"} and observer_estimates:
                observer_estimates = tuple(
                    replace(
                        estimate,
                        predicted_edge=(
                            estimate.predicted_edge
                            + (0.035 if index % 2 == 0 else -0.035)
                        ),
                    )
                    for index, estimate in enumerate(observer_estimates)
                )
            observations.append(
                replace(
                    observation,
                    realized_return=realized,
                    cost_rate=cost,
                    capacity=capacity,
                    stress_loss_rate=stress_loss,
                    latency=latency,
                    edge_lifetime_ms=edge_lifetime_ms,
                    observer_estimates=observer_estimates,
                )
            )
        transformed.append(
            DatasetFrame(
                frame=Frame(item.frame.event_id, tuple(observations)),
                phase_b_in_a=item.phase_b_in_a,
                timestamp=item.timestamp,
                regime=f"{item.regime}|stress:{scenario}",
            )
        )
    return MarketDataset(tuple(transformed), f"{dataset.source_name}:{scenario}")


def stress_suite(dataset: MarketDataset) -> dict[str, MarketDataset]:
    return {
        scenario: stress_dataset(dataset, scenario)
        for scenario in (
            "base",
            "adverse_returns",
            "fee_shock",
            "capacity_collapse",
            "latency_spike",
            "observer_divergence",
            "combined",
        )
    }
