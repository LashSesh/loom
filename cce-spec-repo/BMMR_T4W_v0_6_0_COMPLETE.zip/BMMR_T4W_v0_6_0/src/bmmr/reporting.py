"""Auditable experiment artifacts and human-readable lab report."""

from __future__ import annotations

import csv
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path
from collections.abc import Mapping

from .core import ReactorConfig, result_as_dict
from .conformance import evaluate_conformance
from .dataset import MarketDataset
from .experiment import ExperimentResult
from .residue import residue_artifact


def _json_dump(path: Path, value: object) -> None:
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )


def experiment_as_dict(experiment: ExperimentResult) -> dict[str, object]:
    return {
        "run_id": experiment.descriptor.run_id,
        "descriptor": asdict(experiment.descriptor),
        "metrics": asdict(experiment.metrics),
        "result": result_as_dict(experiment.result),
    }


def _number(value: float | None) -> str:
    return "n/a" if value is None else f"{value:.6f}"


def write_lab_artifacts(
    output_dir: str | Path,
    dataset: MarketDataset,
    config: ReactorConfig,
    dynamic: ExperimentResult,
    benchmark: dict[str, ExperimentResult],
    stresses: dict[str, ExperimentResult],
    folds: tuple[ExperimentResult, ...],
    replay_match: bool,
    wealth_phase: Mapping[str, object] | None = None,
    operation_witness: Mapping[str, object] | None = None,
) -> tuple[Path, ...]:
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)

    _json_dump(destination / "run_descriptor.json", {
        **asdict(dynamic.descriptor),
        "run_id": dynamic.descriptor.run_id,
    })
    _json_dump(destination / "summary.json", experiment_as_dict(dynamic))
    residue = residue_artifact(dynamic.result.trace)
    _json_dump(destination / "residue.json", residue)
    _json_dump(
        destination / "benchmark.json",
        {name: experiment_as_dict(item) for name, item in benchmark.items()},
    )
    _json_dump(
        destination / "stress.json",
        {name: experiment_as_dict(item) for name, item in stresses.items()},
    )
    _json_dump(
        destination / "walk_forward.json",
        [experiment_as_dict(item) for item in folds],
    )
    _json_dump(destination / "verification.json", {
        "schema": "bmmr.verification.v3",
        "implementation_digest": dynamic.descriptor.implementation_digest,
        "dataset_digest": dataset.digest,
        "wealth_phase_digest": dynamic.descriptor.wealth_phase_digest,
        "run_id": dynamic.descriptor.run_id,
        "trace_digest": dynamic.result.trace_digest,
        "deterministic_replay_match": replay_match,
    })
    _json_dump(
        destination / "conformance.json",
        evaluate_conformance(
            dataset,
            dynamic,
            replay_match,
            wealth_phase,
            operation_witness,
        ),
    )
    if wealth_phase is not None:
        _json_dump(destination / "wealth_phase.json", dict(wealth_phase))
    if operation_witness is not None:
        _json_dump(
            destination / "operation_algebra.json",
            dict(operation_witness),
        )
    _json_dump(
        destination / "operational.json",
        {
            "schema": "bmmr.operational.v1",
            "events": [
                {
                    "event_id": record.event_id,
                    "binding_constraint": record.binding_constraint,
                    "max_loop_latency_ms": record.max_loop_latency_ms,
                    "minimum_latency_margin_ms": record.minimum_latency_margin_ms,
                    "temporal_damage_utilization": record.temporal_damage_utilization,
                    "timing_blindspots": record.timing_blindspots,
                    "observer_blindspots": record.observer_blindspots,
                    "max_observer_parallax": record.max_observer_parallax,
                    "drift_reanchor_routes": record.drift_reanchor_routes,
                    "dependency_chordal": record.dependency_chordal,
                    "dependency_fill_in_edges": record.dependency_fill_in_edges,
                    "dependency_treewidth_upper_bound": (
                        record.dependency_treewidth_upper_bound
                    ),
                    "max_risk_factor_utilization": (
                        record.max_risk_factor_utilization
                    ),
                }
                for record in dynamic.result.trace
            ],
        },
    )

    with (destination / "trace.jsonl").open("w", encoding="utf-8") as handle:
        for record in dynamic.result.trace:
            handle.write(
                json.dumps(
                    asdict(record),
                    sort_keys=True,
                    ensure_ascii=True,
                    allow_nan=False,
                )
                + "\n"
            )

    with (destination / "benchmark.csv").open(
        "w", encoding="utf-8", newline=""
    ) as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "profile", "balanced_value_a", "finalized_value_a", "net_result_a",
            "max_drawdown_fraction", "max_leverage", "max_family_share",
            "max_risk_factor_utilization", "max_temporal_damage_utilization", "ruined",
            "trace_digest",
        ])
        for name, item in benchmark.items():
            writer.writerow([
                name,
                item.metrics.balanced_value_a,
                item.metrics.finalized_value_a,
                item.metrics.net_result_a,
                item.metrics.max_drawdown_fraction,
                item.result.max_leverage,
                item.metrics.max_family_share,
                item.metrics.max_risk_factor_utilization,
                item.metrics.max_temporal_damage_utilization,
                item.metrics.ruined,
                item.result.trace_digest,
            ])

    benchmark_rows = "\n".join(
        "| {name} | {balance} | {vault} | {net} | {drawdown} | {leverage} | {ruined} |".format(
            name=name,
            balance=_number(item.metrics.balanced_value_a),
            vault=_number(item.metrics.finalized_value_a),
            net=_number(item.metrics.net_result_a),
            drawdown=_number(item.metrics.max_drawdown_fraction),
            leverage=_number(item.result.max_leverage),
            ruined=str(item.metrics.ruined).lower(),
        )
        for name, item in benchmark.items()
    )
    stress_rows = "\n".join(
        "| {name} | {balance} | {net} | {drawdown} | {shortfall} | {ruined} |".format(
            name=name,
            balance=_number(item.metrics.balanced_value_a),
            net=_number(item.metrics.net_result_a),
            drawdown=_number(item.metrics.max_drawdown_fraction),
            shortfall=_number(item.metrics.external_shortfall),
            ruined=str(item.metrics.ruined).lower(),
        )
        for name, item in stresses.items()
    )
    fold_rows = "\n".join(
        "| {fold} | {first}-{last} | {balance} | {net} | {drawdown} |".format(
            fold=index,
            first=item.descriptor.first_event_id,
            last=item.descriptor.last_event_id,
            balance=_number(item.metrics.balanced_value_a),
            net=_number(item.metrics.net_result_a),
            drawdown=_number(item.metrics.max_drawdown_fraction),
        )
        for index, item in enumerate(folds, start=1)
    )
    residue_summary = residue["summary"]
    wealth_section = ""
    if wealth_phase is not None:
        base = wealth_phase["base"]
        stress_phase = wealth_phase["stress"]
        transition = wealth_phase["transition"]
        wealth_section = f"""
## Wealth-Phase-Kern

- Basisregime: `{base['regime']}`
- robust liquidierbarer Horizontwert: {_number(base['valuation']['robust_horizon_value'])} {base['valuation']['numeraire']}
- Solvenzmarge: {_number(base['valuation']['solvency_margin'])}
- anisotroper Ordnungsparameter: {_number(base['anisotropy']['order_parameter'])}
- kausales Informationsbudget: {_number(base['information']['mutual_information_nats'])} nats
- nutzbare obere Log-Wachstumsgrenze nach Drag: {_number(base['information']['usable_log_growth_bound'])} nats
- Stressregime: `{stress_phase['regime']}`
- sichtbarer Phasenwechsel: `{str(transition['changed']).lower()}`
- Grenzursachen: {', '.join(transition['reasons'])}

Die Wealth-Phase ist eine operative Zustandsklasse aus Anspruechen,
Verbindlichkeiten, Konversionsrechten, Beobachtung und Constraints. Der
Informationswert bleibt eine obere Schranke in Log-Wachstumseinheiten. Er ist
weder erwarteter PnL noch die Behauptung einer physikalischen Materiephase.
"""

    report = f"""# BMMR v0.5.0 - Wealth-Phase- und temporaler Evaluationslauf

## Identität

- Run-ID: `{dynamic.descriptor.run_id}`
- Implementierungs-Digest: `{dynamic.descriptor.implementation_digest}`
- Datensatz-Digest: `{dataset.digest}`
- Wealth-Phase-Digest: `{dynamic.descriptor.wealth_phase_digest}`
- Trace-Digest: `{dynamic.result.trace_digest}`
- Ereignisse: {len(dataset.frames)}
- Quelle: `{dataset.source_name}`
- Deterministisches Replay identisch: `{str(replay_match).lower()}`

Die Run-ID bindet Korpusversion, unveränderlichen Konfigurations-Snapshot,
Implementierungs-Digest, Datensatz-Digest, Profil und Ereignisgrenzen. Eine
Ergebniszahl ohne diese Identität gehört nicht zu diesem Lauf.

## Operative Realisierbarkeit

- maximale Loop-Latenz: {_number(max((r.max_loop_latency_ms or 0.0) for r in dynamic.result.trace))} ms
- kleinste Edge-Latenzreserve: {_number(min((r.minimum_latency_margin_ms or 0.0) for r in dynamic.result.trace))} ms
- maximale temporale Schadensauslastung: {_number(dynamic.metrics.max_temporal_damage_utilization)}
- maximale Risikofaktorauslastung: {_number(dynamic.metrics.max_risk_factor_utilization)}
- Timing-Ablehnungsrate: {_number(dynamic.metrics.temporal_rejection_rate)}
- Beobachter-Ablehnungsrate: {_number(dynamic.metrics.observer_rejection_rate)}
- Drift-Ablehnungsrate: {_number(dynamic.metrics.drift_rejection_rate)}

Eine Route ist nur realisierbar, wenn ihr vollständiger Entscheidungsloop vor
dem Edge-Verfall endet und der während dieses Loops modellierte Schaden im
Fortsetzungsbudget liegt. Observer-Parallaxe und Drift werden getrennt
geführt; Erwartungen bereiten Evidenz vor, realisierte Nachbeobachtungen
verankern sie erst für spätere Ereignisse.

## Residuenregister

- gereifte Residuen: {residue_summary['total']}
- verpasste positive Gegenfakten: {residue_summary['missed_positive']}
- vermiedene negative Gegenfakten: {residue_summary['avoided_negative']}
- mittlere realisierte Residuenrendite: {_number(residue_summary['mean_realized_net_return'])}

Das Register bewertet verworfene Beobachtungen nur auf Einheitsrendite. Es
erfindet keine hypothetische Positionsgröße und damit keinen PnL.

{wealth_section}

## Profilvergleich

| Profil | Balance A | Vault A | Netto A | Max. Drawdown | Max. Hebel | Ruin |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
{benchmark_rows}

Die Pole sind Diagnoseprofile. Das dynamische Profil interpoliert nicht nach
Belieben, sondern wird auf die erste bindende Grenze aus Evidenz,
Familienkonzentration, Liquidität oder Fortsetzungsbudget projiziert.

## Stresslandschaft

| Szenario | Balance A | Netto A | Max. Drawdown | Außenfehlbetrag | Ruin |
| --- | ---: | ---: | ---: | ---: | --- |
{stress_rows}

## Chronologische Folds

| Fold | Events | Balance A | Netto A | Max. Drawdown |
| ---: | --- | ---: | ---: | ---: |
{fold_rows}

Die Folds verwenden eingefrorene Parameter und überschneidungsfreie,
chronologische Abschnitte. Sie sind ein Stabilitätstest, kein behauptetes
Training und keine Optimierung.

## Ergebnisgrenzen

Dieser Lauf prüft Rechen-, Bilanz-, Zeit-, Beobachter-, Residuen-,
Wealth-Phase-, Informationsbudget-, Operationsalgebra-, Projektions- und
Replay-Semantik. Er ist
keine Behauptung zukünftiger Rendite. Der beiliegende Demodatensatz ist
synthetisch. Für eine empirische Aussage müssen vorhergesagte Kanten streng
kausal erzeugt, Kosten und Kapazität aus ausführbaren Marktdaten rekonstruiert
und Stressverluste gegen reale Tail-Ereignisse kalibriert werden.
"""
    (destination / "REPORT.md").write_text(report, encoding="utf-8")

    start = """BMMR v0.5.0 - START HERE

1. REPORT.md lesen.
2. benchmark.csv fuer den Profilvergleich oeffnen.
3. conformance.json und verification.json pruefen Laufvertrag und Digests.
4. wealth_phase.json zeigt Claims, Konversionsgeometrie, Informationsbudget
   und den getraceten Stress-Phasenwechsel.
5. operation_algebra.json zeigt, warum nur unabhaengige Operationen
   kommutieren duerfen.
6. residue.json und operational.json zeigen Gegenfakten und Zeitgrenzen.
7. Den Lauf reproduzieren:
   PYTHONPATH=src python3 -m bmmr.lab full --dataset examples/demo_market.csv --wealth-phase examples/demo_wealth_phase.json --output output/replay
8. Tests ausfuehren:
   PYTHONPATH=src python3 -m unittest discover -s tests -v

Die PDF im Wurzelverzeichnis ist die konsolidierte Masterspezifikation.
"""
    (destination / "START_HERE.txt").write_text(start, encoding="utf-8")

    artifacts = sorted(
        path
        for path in destination.iterdir()
        if path.is_file() and path.name != "MANIFEST.sha256.json"
    )
    manifest = {path.name: sha256(path.read_bytes()).hexdigest() for path in artifacts}
    _json_dump(destination / "MANIFEST.sha256.json", manifest)
    return tuple(sorted(path for path in destination.iterdir() if path.is_file()))
