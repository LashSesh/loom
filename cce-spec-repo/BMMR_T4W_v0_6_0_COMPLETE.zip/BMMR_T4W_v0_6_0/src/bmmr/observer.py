"""Typed observer ensemble and parallax assessment."""

from __future__ import annotations

from dataclasses import dataclass
import math
from statistics import median


@dataclass(frozen=True, slots=True)
class ObserverEstimate:
    """One declared evidence family looking at the same route."""

    family: str
    predicted_edge: float

    def __post_init__(self) -> None:
        if not self.family:
            raise ValueError("observer family must not be empty")
        if not math.isfinite(self.predicted_edge):
            raise ValueError("observer predicted_edge must be finite")


@dataclass(frozen=True, slots=True)
class ObserverAssessment:
    observer_complete: bool
    independent_families: int
    consensus_edge: float | None
    parallax: float | None
    consensus_deviation: float | None
    stable: bool
    blindspot: str | None


def assess_observers(
    estimates: tuple[ObserverEstimate, ...],
    declared_edge: float,
    minimum_families: int,
    maximum_parallax: float,
    maximum_consensus_deviation: float,
) -> ObserverAssessment:
    """Collapse aliases within a family and compare independent families.

    Multiple estimates from the same family are averaged before the ensemble
    median is formed.  Aliases can therefore refine one view but cannot create
    artificial independence.
    """

    if minimum_families < 1:
        raise ValueError("minimum_families must be positive")
    if maximum_parallax < 0 or not math.isfinite(maximum_parallax):
        raise ValueError("maximum_parallax must be non-negative and finite")
    if maximum_consensus_deviation < 0 or not math.isfinite(
        maximum_consensus_deviation
    ):
        raise ValueError(
            "maximum_consensus_deviation must be non-negative and finite"
        )

    grouped: dict[str, list[float]] = {}
    for estimate in estimates:
        grouped.setdefault(estimate.family, []).append(estimate.predicted_edge)
    family_values = tuple(
        sum(values) / len(values)
        for _, values in sorted(grouped.items())
    )
    count = len(family_values)
    if count < minimum_families:
        return ObserverAssessment(
            observer_complete=False,
            independent_families=count,
            consensus_edge=median(family_values) if family_values else None,
            parallax=(
                max(family_values) - min(family_values)
                if family_values
                else None
            ),
            consensus_deviation=None,
            stable=False,
            blindspot="insufficient_independent_observers",
        )

    center = float(median(family_values))
    parallax = max(family_values) - min(family_values)
    deviation = abs(declared_edge - center)
    stable = (
        parallax <= maximum_parallax
        and deviation <= maximum_consensus_deviation
    )
    return ObserverAssessment(
        observer_complete=True,
        independent_families=count,
        consensus_edge=center,
        parallax=parallax,
        consensus_deviation=deviation,
        stable=stable,
        blindspot=None,
    )
