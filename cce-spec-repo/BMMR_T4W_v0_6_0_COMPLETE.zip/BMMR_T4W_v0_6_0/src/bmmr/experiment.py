"""Causal experiment descriptors, metrics, profiles and walk-forward runs."""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from hashlib import sha256
import json

from .core import Reactor, ReactorConfig, RunResult
from .dataset import MarketDataset
from .fingerprint import implementation_digest
from .residue import build_residue_ledger, summarize_residues


CORPUS_VERSION = "0.5.0"


@dataclass(frozen=True, slots=True)
class RunDescriptor:
    schema: str
    corpus_version: str
    implementation_digest: str
    dataset_digest: str
    wealth_phase_digest: str
    profile_id: str
    config: dict[str, object]
    first_event_id: int
    last_event_id: int
    frame_count: int

    @property
    def run_id(self) -> str:
        payload = json.dumps(
            asdict(self),
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
            allow_nan=False,
        )
        return sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class ExperimentMetrics:
    balanced_value_a: float
    finalized_value_a: float
    continuation_value_a: float
    balanced_value_b: float
    net_result_a: float
    max_drawdown_fraction: float
    profit_factor: float | None
    positive_events: int
    negative_events: int
    reflection_rate: float
    max_reflection_utilization: float
    max_temporal_damage_utilization: float
    max_family_share: float
    max_risk_factor_utilization: float
    temporal_rejection_rate: float
    observer_rejection_rate: float
    drift_rejection_rate: float
    residue_missed_positive_rate: float
    external_shortfall: float
    ruined: bool


@dataclass(frozen=True, slots=True)
class ExperimentResult:
    descriptor: RunDescriptor
    result: RunResult
    metrics: ExperimentMetrics


def _max_drawdown(values: list[float]) -> float:
    peak = values[0]
    maximum = 0.0
    for value in values:
        peak = max(peak, value)
        if peak > 0:
            maximum = max(maximum, (peak - value) / peak)
    return maximum


def run_experiment(
    dataset: MarketDataset,
    config: ReactorConfig,
    profile_id: str = "dynamic_reflection",
    wealth_phase_digest: str = "",
) -> ExperimentResult:
    descriptor = RunDescriptor(
        schema="bmmr.run.v3",
        corpus_version=CORPUS_VERSION,
        implementation_digest=implementation_digest(),
        dataset_digest=dataset.digest,
        wealth_phase_digest=wealth_phase_digest,
        profile_id=profile_id,
        config=asdict(config),
        first_event_id=dataset.frames[0].frame.event_id,
        last_event_id=dataset.frames[-1].frame.event_id,
        frame_count=len(dataset.frames),
    )
    result = Reactor(config).run(dataset.core_frames)
    initial_value = config.initial_commitment * (1.0 - config.liquidation_haircut)
    balance_path = [initial_value] + [
        record.vault_after
        + record.reactor_equity_after * (1.0 - config.liquidation_haircut)
        for record in result.trace
    ]
    gains = [record.net_pnl for record in result.trace if record.net_pnl > 0]
    losses = [record.net_pnl for record in result.trace if record.net_pnl < 0]
    profit_factor = sum(gains) / abs(sum(losses)) if losses else None
    phase_b_in_a = dataset.frames[-1].phase_b_in_a
    events = max(1, len(result.trace))
    decisions = max(
        1,
        sum(
            len(record.primary) + len(record.mirror)
            for record in result.trace
        ),
    )
    residues = summarize_residues(build_residue_ledger(result.trace))
    metrics = ExperimentMetrics(
        balanced_value_a=result.ledger.balanced_objective_value,
        finalized_value_a=result.ledger.finalized_objective_value,
        continuation_value_a=result.ledger.continuation_value,
        balanced_value_b=result.ledger.balanced_objective_value / phase_b_in_a,
        net_result_a=result.ledger.net_result,
        max_drawdown_fraction=_max_drawdown(balance_path),
        profit_factor=profit_factor,
        positive_events=len(gains),
        negative_events=len(losses),
        reflection_rate=result.reflection_limited_events / events,
        max_reflection_utilization=result.max_reflection_utilization,
        max_temporal_damage_utilization=(
            result.max_temporal_damage_utilization
        ),
        max_family_share=result.max_family_share,
        max_risk_factor_utilization=result.max_risk_factor_utilization,
        temporal_rejection_rate=result.timing_rejections / decisions,
        observer_rejection_rate=result.observer_rejections / decisions,
        drift_rejection_rate=result.drift_rejections / decisions,
        residue_missed_positive_rate=(
            residues.missed_positive / residues.total
            if residues.total
            else 0.0
        ),
        external_shortfall=result.ledger.external_shortfall,
        ruined=result.ledger.ruined,
    )
    return ExperimentResult(descriptor, result, metrics)


def benchmark_profiles(base: ReactorConfig) -> dict[str, ReactorConfig]:
    """Return the two poles and their dynamic reflection, not safety rankings."""

    preservation = replace(
        base,
        base_leverage=1.0,
        maximum_leverage=1.0,
        amplification_source="internal_equity_only",
    )
    expansion = replace(
        base,
        base_leverage=base.maximum_leverage,
        amplification_source=(
            "derivative_margin"
            if base.amplification_source == "internal_equity_only"
            else base.amplification_source
        ),
    )
    return {
        "preservation_pole": preservation,
        "dynamic_reflection": base,
        "expansion_pole": expansion,
    }


def run_benchmark(
    dataset: MarketDataset,
    base: ReactorConfig,
    wealth_phase_digest: str = "",
) -> dict[str, ExperimentResult]:
    return {
        name: run_experiment(dataset, config, name, wealth_phase_digest)
        for name, config in benchmark_profiles(base).items()
    }


def walk_forward(
    dataset: MarketDataset,
    config: ReactorConfig,
    folds: int = 4,
    wealth_phase_digest: str = "",
) -> tuple[ExperimentResult, ...]:
    """Evaluate chronological, non-overlapping folds with frozen parameters."""

    if folds < 2 or folds > len(dataset.frames):
        raise ValueError("folds must be between 2 and the number of frames")
    boundaries = [round(index * len(dataset.frames) / folds) for index in range(folds + 1)]
    results = []
    for index in range(folds):
        subset = dataset.slice(boundaries[index], boundaries[index + 1])
        results.append(
            run_experiment(
                subset,
                config,
                f"walk_forward_{index + 1}",
                wealth_phase_digest,
            )
        )
    return tuple(results)
