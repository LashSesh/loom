"""Matured counterfactual register for rejected route observations."""

from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
from typing import Iterable

from .core import TraceRecord


@dataclass(frozen=True, slots=True)
class ResidueRecord:
    event_id: int
    route_id: str
    residue_class: str
    reason: str
    status: str
    predicted_net_edge: float
    realized_net_return: float
    counterfactual_label: str
    next_action: str


@dataclass(frozen=True, slots=True)
class ResidueSummary:
    total: int
    missed_positive: int
    avoided_negative: int
    flat: int
    mean_realized_net_return: float | None
    reason_counts: tuple[tuple[str, int], ...]
    class_counts: tuple[tuple[str, int], ...]


def _taxonomy(reason: str) -> tuple[str, str]:
    mapping = {
        "missing_timing_evidence": ("timing", "instrument_latency"),
        "nonpositive_latency_margin": ("timing", "reduce_loop_latency"),
        "observer_blindspot": ("observer", "add_independent_observer"),
        "observer_parallax": ("observer", "resolve_view_disagreement"),
        "model_drift_reanchor": ("drift", "recalibrate_or_version_model"),
        "insufficient_witness_evidence": ("evidence", "await_matured_outcome"),
        "below_activation_hysteresis": ("evidence", "continue_observation"),
        "nonpositive_predicted_net_edge": ("edge", "remain_in_mirror"),
        "zero_capacity": ("liquidity", "find_prepared_carrier"),
    }
    return mapping.get(reason, ("unclassified", "classify_residue"))


def build_residue_ledger(trace: Iterable[TraceRecord]) -> tuple[ResidueRecord, ...]:
    records: list[ResidueRecord] = []
    for event in trace:
        for decision in event.mirror:
            reason = decision.rejection_reason or "unclassified"
            residue_class, next_action = _taxonomy(reason)
            if decision.realized_net_return > 0:
                label = "missed_positive"
            elif decision.realized_net_return < 0:
                label = "avoided_negative"
            else:
                label = "flat"
            records.append(
                ResidueRecord(
                    event_id=event.event_id,
                    route_id=decision.route_id,
                    residue_class=residue_class,
                    reason=reason,
                    status="matured",
                    predicted_net_edge=decision.predicted_net_edge,
                    realized_net_return=decision.realized_net_return,
                    counterfactual_label=label,
                    next_action=next_action,
                )
            )
    return tuple(records)


def summarize_residues(records: Iterable[ResidueRecord]) -> ResidueSummary:
    items = tuple(records)
    labels = Counter(item.counterfactual_label for item in items)
    reasons = Counter(item.reason for item in items)
    classes = Counter(item.residue_class for item in items)
    mean = (
        sum(item.realized_net_return for item in items) / len(items)
        if items
        else None
    )
    return ResidueSummary(
        total=len(items),
        missed_positive=labels["missed_positive"],
        avoided_negative=labels["avoided_negative"],
        flat=labels["flat"],
        mean_realized_net_return=mean,
        reason_counts=tuple(sorted(reasons.items())),
        class_counts=tuple(sorted(classes.items())),
    )


def residue_artifact(trace: Iterable[TraceRecord]) -> dict[str, object]:
    records = build_residue_ledger(trace)
    return {
        "schema": "bmmr.residue.v1",
        "summary": asdict(summarize_residues(records)),
        "records": [asdict(item) for item in records],
    }
