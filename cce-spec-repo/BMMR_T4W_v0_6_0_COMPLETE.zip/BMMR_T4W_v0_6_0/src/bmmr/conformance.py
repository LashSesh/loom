"""Executable BMMR v0.5 conformance checks."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import asdict, dataclass

from .dataset import MarketDataset
from .experiment import ExperimentResult
from .residue import build_residue_ledger


@dataclass(frozen=True, slots=True)
class ConformanceCheck:
    check_id: str
    name: str
    passed: bool
    evidence: str


def evaluate_conformance(
    dataset: MarketDataset,
    experiment: ExperimentResult,
    replay_match: bool,
    wealth_phase: Mapping[str, object] | None = None,
    operation_witness: Mapping[str, object] | None = None,
) -> dict[str, object]:
    trace = experiment.result.trace
    mirror_count = sum(len(record.mirror) for record in trace)
    residues = build_residue_ledger(trace)
    checks: list[ConformanceCheck] = [
        ConformanceCheck(
            "BMMR-0",
            "content-addressed identity",
            bool(
                experiment.descriptor.implementation_digest
                and experiment.descriptor.dataset_digest == dataset.digest
            ),
            "implementation and dataset digests are bound into the run id",
        ),
        ConformanceCheck(
            "BMMR-1",
            "temporal realizability",
            all(
                record.timing_blindspots == 0
                and record.temporal_damage
                <= record.reflection_budget + 1e-9
                for record in trace
            ),
            "all observations are timed and aggregate loop damage remains inside budget",
        ),
        ConformanceCheck(
            "BMMR-2",
            "observer parallax discipline",
            all(record.observer_blindspots == 0 for record in trace),
            "every route carries the required independent observer families",
        ),
        ConformanceCheck(
            "BMMR-3",
            "no silent residue",
            len(residues) == mirror_count
            and all(item.reason and item.next_action for item in residues),
            "every rejected decision has a matured, classified residue record",
        ),
        ConformanceCheck(
            "BMMR-4",
            "overlapping risk factors",
            all(record.max_risk_factor_utilization <= 1.0 + 1e-9 for record in trace),
            "every declared risk-factor exposure remains inside its local budget",
        ),
        ConformanceCheck(
            "BMMR-5",
            "deterministic replay",
            replay_match,
            "same descriptor and data reproduce the exact trace digest",
        ),
    ]
    if wealth_phase is not None:
        base = wealth_phase.get("base", {})
        transition = wealth_phase.get("transition", {})
        if not isinstance(base, Mapping) or not isinstance(transition, Mapping):
            raise ValueError("malformed wealth-phase artifact")
        valuation = base.get("valuation", {})
        information = base.get("information", {})
        if not isinstance(valuation, Mapping) or not isinstance(information, Mapping):
            raise ValueError("malformed wealth-phase snapshot")
        gross = float(information.get("gross_log_growth_bound", -1.0))
        usable = float(information.get("usable_log_growth_bound", -1.0))
        checks.extend(
            (
                ConformanceCheck(
                    "BMMR-6",
                    "executable wealth ontology",
                    bool(
                        valuation.get("accounting_closed")
                        and valuation.get("liquid")
                        and valuation.get("solvent")
                    ),
                    "base claims and due obligations close under the declared horizon conversion network",
                ),
                ConformanceCheck(
                    "BMMR-7",
                    "causal information-to-wealth bound",
                    bool(
                        information.get("causal_available")
                        and 0.0 <= usable <= gross + 1e-12
                    ),
                    "usable information remains a cost-adjusted upper bound in log-growth units",
                ),
                ConformanceCheck(
                    "BMMR-8",
                    "observable phase transition",
                    bool(transition.get("changed") and transition.get("reasons")),
                    "stress changes at least one declared order parameter and records the boundary crossing",
                ),
                ConformanceCheck(
                    "BMMR-9",
                    "declared approximation boundary",
                    bool(
                        wealth_phase.get("implementation_scope")
                        and wealth_phase.get("ontological_status")
                    ),
                    "the finite reference solver and non-physical phase semantics are explicitly scoped",
                ),
            )
        )
    if operation_witness is not None:
        independent = operation_witness.get("independent_pair", {})
        conflicting = operation_witness.get("conflicting_pair", {})
        if not isinstance(independent, Mapping) or not isinstance(conflicting, Mapping):
            raise ValueError("malformed operation-algebra witness")
        checks.append(
            ConformanceCheck(
                "BMMR-10",
                "partial rather than free commutation",
                bool(
                    independent.get("structurally_independent")
                    and independent.get("observationally_commutes")
                    and not conflicting.get("structurally_independent")
                    and not conflicting.get("observationally_commutes")
                ),
                "independent resource operations commute while a shared-resource counterexample does not",
            )
        )
    return {
        "schema": "bmmr.conformance.v2",
        "overall_pass": all(item.passed for item in checks),
        "checks": [asdict(item) for item in checks],
    }
