"""Combinatorial tesseract used as the macro-mode body of BMMR-T4W.

The tesseract is not treated as a hidden physical dimension.  It is the
four-fold product of independently witnessed binary predicates:

* closure: obligations and conversion paths are operationally closed;
* mobility: the carrier layer is mobile rather than locked;
* order: directed/anisotropic order exceeds its registered threshold;
* information: causal information changes an admissible control policy.

Every mode change is decomposed into Hamming-distance-one edge transitions.
This makes the causal boundary crossing explicit and auditable.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from enum import IntEnum
from itertools import product
from math import comb
from typing import Iterable, Mapping


class TesseractAxis(IntEnum):
    CLOSURE = 0
    MOBILITY = 1
    ORDER = 2
    INFORMATION = 3


AXIS_NAMES = tuple(axis.name.lower() for axis in TesseractAxis)


@dataclass(frozen=True, slots=True, order=True)
class TesseractMode:
    closure: int
    mobility: int
    order: int
    information: int

    def __post_init__(self) -> None:
        if any(bit not in (0, 1) for bit in self.bits):
            raise ValueError("tesseract mode coordinates must be binary")

    @property
    def bits(self) -> tuple[int, int, int, int]:
        return (self.closure, self.mobility, self.order, self.information)

    @property
    def mode_id(self) -> str:
        return "".join(str(bit) for bit in self.bits)

    @property
    def active_axes(self) -> tuple[str, ...]:
        return tuple(name for name, bit in zip(AXIS_NAMES, self.bits) if bit)

    def replace_axis(self, axis: TesseractAxis, value: int) -> "TesseractMode":
        if value not in (0, 1):
            raise ValueError("axis value must be binary")
        bits = list(self.bits)
        bits[int(axis)] = value
        return TesseractMode(*bits)

    @classmethod
    def from_observables(
        cls,
        *,
        accounting_closed: bool,
        liquid: bool,
        solvent: bool,
        mobility: float,
        mobility_threshold: float,
        order_parameter: float,
        order_threshold: float,
        causal_information_active: bool,
    ) -> "TesseractMode":
        for name, value in (
            ("mobility", mobility),
            ("mobility_threshold", mobility_threshold),
            ("order_parameter", order_parameter),
            ("order_threshold", order_threshold),
        ):
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must lie in [0, 1]")
        return cls(
            int(accounting_closed and liquid and solvent),
            int(mobility >= mobility_threshold),
            int(order_parameter >= order_threshold),
            int(causal_information_active),
        )


def all_modes() -> tuple[TesseractMode, ...]:
    return tuple(TesseractMode(*bits) for bits in product((0, 1), repeat=4))


def hamming_distance(left: TesseractMode, right: TesseractMode) -> int:
    return sum(a != b for a, b in zip(left.bits, right.bits))


def adjacent(left: TesseractMode, right: TesseractMode) -> bool:
    return hamming_distance(left, right) == 1


def changed_axis(left: TesseractMode, right: TesseractMode) -> TesseractAxis:
    changed = [
        TesseractAxis(index)
        for index, (a, b) in enumerate(zip(left.bits, right.bits))
        if a != b
    ]
    if len(changed) != 1:
        raise ValueError("a primitive transition must cross exactly one facet")
    return changed[0]


def canonical_transition_path(
    source: TesseractMode,
    target: TesseractMode,
    axis_order: Iterable[TesseractAxis] = tuple(TesseractAxis),
) -> tuple[TesseractMode, ...]:
    """Return a deterministic edge path from source to target.

    Diagonal jumps are not admitted.  A simultaneous threshold observation can
    still be represented, but it is serialised according to ``axis_order`` so
    that every individual boundary crossing receives its own evidence line.
    """

    order = tuple(axis_order)
    if set(order) != set(TesseractAxis) or len(order) != 4:
        raise ValueError("axis_order must contain every tesseract axis once")
    current = source
    path = [source]
    for axis in order:
        wanted = target.bits[int(axis)]
        if current.bits[int(axis)] != wanted:
            current = current.replace_axis(axis, wanted)
            path.append(current)
    if current != target:
        raise AssertionError("canonical path construction failed")
    return tuple(path)


FaceCoordinate = int | None


@dataclass(frozen=True, slots=True, order=True)
class CubicalCell:
    """An oriented face of the unit 4-cube.

    A coordinate is 0 or 1 when fixed and ``None`` when free.  The orientation
    is the canonical increasing order of the free coordinate indices.
    """

    coordinates: tuple[FaceCoordinate, FaceCoordinate, FaceCoordinate, FaceCoordinate]

    def __post_init__(self) -> None:
        if len(self.coordinates) != 4:
            raise ValueError("a T4W cubical cell must have four coordinates")
        if any(value not in (0, 1, None) for value in self.coordinates):
            raise ValueError("cell coordinates must be 0, 1 or None")

    @property
    def dimension(self) -> int:
        return sum(value is None for value in self.coordinates)

    @property
    def cell_id(self) -> str:
        return "".join("*" if value is None else str(value) for value in self.coordinates)

    def boundary(self) -> dict["CubicalCell", int]:
        """Return the oriented cubical boundary as an integer chain."""

        result: dict[CubicalCell, int] = defaultdict(int)
        free = [index for index, value in enumerate(self.coordinates) if value is None]
        for rank, index in enumerate(free):
            sign = -1 if rank % 2 else 1
            high = list(self.coordinates)
            low = list(self.coordinates)
            high[index] = 1
            low[index] = 0
            result[CubicalCell(tuple(high))] += sign
            result[CubicalCell(tuple(low))] -= sign
        return {cell: coefficient for cell, coefficient in result.items() if coefficient}


def chain_boundary(chain: Mapping[CubicalCell, int]) -> dict[CubicalCell, int]:
    result: dict[CubicalCell, int] = defaultdict(int)
    for cell, outer_coefficient in chain.items():
        for face, inner_coefficient in cell.boundary().items():
            result[face] += outer_coefficient * inner_coefficient
    return {cell: coefficient for cell, coefficient in result.items() if coefficient}


def all_cells(dimension: int | None = None) -> tuple[CubicalCell, ...]:
    cells = tuple(CubicalCell(tuple(values)) for values in product((0, 1, None), repeat=4))
    if dimension is None:
        return tuple(sorted(cells, key=lambda cell: (cell.dimension, cell.cell_id)))
    if dimension < 0 or dimension > 4:
        raise ValueError("dimension must lie in [0, 4]")
    return tuple(cell for cell in cells if cell.dimension == dimension)


def cell_count(dimension: int) -> int:
    if dimension < 0 or dimension > 4:
        raise ValueError("dimension must lie in [0, 4]")
    return comb(4, dimension) * (2 ** (4 - dimension))


def topology_certificate() -> dict[str, object]:
    top_cell = CubicalCell((None, None, None, None))
    first_boundary = top_cell.boundary()
    second_boundary = chain_boundary(first_boundary)
    return {
        "dimension": 4,
        "axis_names": AXIS_NAMES,
        "cell_counts": {str(k): cell_count(k) for k in range(5)},
        "euler_characteristic": sum(((-1) ** k) * cell_count(k) for k in range(5)),
        "boundary_squared_zero": second_boundary == {},
        "top_cell_boundary_terms": len(first_boundary),
    }
