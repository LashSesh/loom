"""Strict, hash-addressed market dataset contract for BMMR experiments."""

from __future__ import annotations

import csv
from dataclasses import asdict, dataclass
from hashlib import sha256
import json
from pathlib import Path
from typing import Iterable, Mapping

from .core import Frame, RouteObservation
from .observer import ObserverEstimate
from .timing import LatencyProfile


REQUIRED_COLUMNS = {
    "event_id",
    "route_id",
    "predicted_edge",
    "realized_return",
    "cost_rate",
    "capacity",
}


@dataclass(frozen=True, slots=True)
class DatasetFrame:
    frame: Frame
    phase_b_in_a: float = 1.0
    timestamp: str | None = None
    regime: str = "unspecified"

    def __post_init__(self) -> None:
        if self.phase_b_in_a <= 0:
            raise ValueError("phase_b_in_a must be positive")


@dataclass(frozen=True, slots=True)
class MarketDataset:
    frames: tuple[DatasetFrame, ...]
    source_name: str

    def __post_init__(self) -> None:
        if not self.frames:
            raise ValueError("dataset must contain at least one frame")
        event_ids = [item.frame.event_id for item in self.frames]
        if event_ids != sorted(event_ids) or len(event_ids) != len(set(event_ids)):
            raise ValueError("dataset event_id values must be unique and increasing")

    @property
    def digest(self) -> str:
        payload = {
            "schema": "bmmr.dataset.v2",
            "frames": [
                {
                    "event_id": item.frame.event_id,
                    "timestamp": item.timestamp,
                    "regime": item.regime,
                    "phase_b_in_a": item.phase_b_in_a,
                    "observations": [
                        asdict(observation)
                        for observation in sorted(
                            item.frame.observations,
                            key=lambda value: value.route_id,
                        )
                    ],
                }
                for item in self.frames
            ],
        }
        encoded = json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
            allow_nan=False,
        ).encode("utf-8")
        return sha256(encoded).hexdigest()

    @property
    def core_frames(self) -> tuple[Frame, ...]:
        return tuple(item.frame for item in self.frames)

    def slice(self, start: int, stop: int) -> "MarketDataset":
        selected = self.frames[start:stop]
        if not selected:
            raise ValueError("dataset slice must not be empty")
        return MarketDataset(selected, f"{self.source_name}[{start}:{stop}]")


def _optional_text(row: Mapping[str, object], key: str) -> str | None:
    value = row.get(key)
    if value is None or str(value).strip() == "":
        return None
    return str(value).strip()


def _float(row: Mapping[str, object], key: str, default: float | None = None) -> float:
    raw = row.get(key)
    if raw is None or str(raw).strip() == "":
        if default is None:
            raise ValueError(f"missing numeric field {key}")
        return default
    try:
        return float(str(raw).strip())
    except ValueError as exc:
        raise ValueError(f"invalid numeric field {key}: {raw!r}") from exc


def _optional_float(row: Mapping[str, object], key: str) -> float | None:
    raw = row.get(key)
    if raw is None or str(raw).strip() == "":
        return None
    try:
        return float(str(raw).strip())
    except ValueError as exc:
        raise ValueError(f"invalid numeric field {key}: {raw!r}") from exc


def _split_values(value: str | None) -> tuple[str, ...]:
    if value is None:
        return ()
    return tuple(item.strip() for item in value.split("|") if item.strip())


def _observer_estimates(
    row: Mapping[str, object], line_number: int
) -> tuple[ObserverEstimate, ...]:
    families = _split_values(_optional_text(row, "observer_families"))
    raw_edges = _split_values(_optional_text(row, "observer_edges"))
    if bool(families) != bool(raw_edges):
        raise ValueError(
            f"row {line_number} must provide observer_families and observer_edges together"
        )
    if len(families) != len(raw_edges):
        raise ValueError(
            f"row {line_number} observer family and edge counts differ"
        )
    try:
        edges = tuple(float(value) for value in raw_edges)
    except ValueError as exc:
        raise ValueError(
            f"row {line_number} contains an invalid observer edge"
        ) from exc
    return tuple(
        ObserverEstimate(family, edge)
        for family, edge in zip(families, edges)
    )


def _latency_profile(
    row: Mapping[str, object], line_number: int
) -> LatencyProfile | None:
    keys = (
        "latency_feed_ms",
        "latency_detect_ms",
        "latency_infer_ms",
        "latency_decide_ms",
        "latency_transmit_ms",
        "latency_fill_ms",
        "latency_reconcile_ms",
    )
    values = tuple(_optional_float(row, key) for key in keys)
    if all(value is None for value in values):
        return None
    if any(value is None for value in values):
        raise ValueError(
            f"row {line_number} must provide every latency component or none"
        )
    return LatencyProfile(*tuple(float(value) for value in values if value is not None))


def dataset_from_rows(
    rows: Iterable[Mapping[str, object]],
    source_name: str = "memory",
) -> MarketDataset:
    grouped: dict[int, list[RouteObservation]] = {}
    metadata: dict[int, tuple[float, str | None, str]] = {}
    seen = False
    for line_number, row in enumerate(rows, start=2):
        seen = True
        missing = REQUIRED_COLUMNS - set(row)
        if missing:
            raise ValueError(
                f"row {line_number} missing columns: {', '.join(sorted(missing))}"
            )
        try:
            event_id = int(str(row["event_id"]).strip())
        except ValueError as exc:
            raise ValueError(f"invalid event_id on row {line_number}") from exc
        phase_b_in_a = _float(row, "phase_b_in_a", 1.0)
        timestamp = _optional_text(row, "timestamp")
        regime = _optional_text(row, "regime") or "unspecified"
        event_metadata = (phase_b_in_a, timestamp, regime)
        if event_id in metadata and metadata[event_id] != event_metadata:
            raise ValueError(f"inconsistent frame metadata for event {event_id}")
        metadata[event_id] = event_metadata
        grouped.setdefault(event_id, []).append(
            RouteObservation(
                route_id=str(row["route_id"]).strip(),
                predicted_edge=_float(row, "predicted_edge"),
                realized_return=_float(row, "realized_return"),
                cost_rate=_float(row, "cost_rate"),
                capacity=_float(row, "capacity"),
                stress_loss_rate=_float(row, "stress_loss_rate", 0.22),
                phase_from=_optional_text(row, "phase_from") or "A",
                phase_to=_optional_text(row, "phase_to") or "A",
                evidence_family=_optional_text(row, "evidence_family") or "default",
                observer_estimates=_observer_estimates(row, line_number),
                latency=_latency_profile(row, line_number),
                edge_lifetime_ms=_optional_float(row, "edge_lifetime_ms"),
                gap_loss_rate=_float(row, "gap_loss_rate", 0.0),
                adverse_loss_rate_per_second=_float(
                    row, "adverse_loss_rate_per_second", 0.0
                ),
                risk_factors=_split_values(
                    _optional_text(row, "risk_factors")
                ),
            )
        )
    if not seen:
        raise ValueError("dataset contains no rows")

    frames = tuple(
        DatasetFrame(
            frame=Frame(event_id, tuple(grouped[event_id])),
            phase_b_in_a=metadata[event_id][0],
            timestamp=metadata[event_id][1],
            regime=metadata[event_id][2],
        )
        for event_id in sorted(grouped)
    )
    return MarketDataset(frames=frames, source_name=source_name)


def load_dataset(path: str | Path) -> MarketDataset:
    source = Path(path)
    suffix = source.suffix.lower()
    if suffix == ".csv":
        with source.open("r", encoding="utf-8", newline="") as handle:
            return dataset_from_rows(csv.DictReader(handle), source.name)
    if suffix in {".jsonl", ".ndjson"}:
        with source.open("r", encoding="utf-8") as handle:
            rows = [json.loads(line) for line in handle if line.strip()]
        return dataset_from_rows(rows, source.name)
    raise ValueError("dataset must be CSV, JSONL or NDJSON")
