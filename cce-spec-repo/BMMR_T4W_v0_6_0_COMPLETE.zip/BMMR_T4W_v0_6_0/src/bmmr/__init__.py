"""BMMR-T4W: market reactor plus thermodynamic tesseract workbody."""

__version__ = "0.6.0"

from .core import (
    Frame,
    Ledger,
    Reactor,
    ReactorConfig,
    RouteObservation,
    RunResult,
)
from .dataset import DatasetFrame, MarketDataset, load_dataset
from .experiment import ExperimentResult, run_experiment
from .observer import ObserverEstimate
from .timing import LatencyProfile
from .information_phase import InformationBudget, mutual_information_nats
from .wealth_phase import (
    Claim,
    ConversionEdge,
    ConversionNetwork,
    Liability,
    WealthPhaseSnapshot,
    WealthState,
    evaluate_wealth_phase,
)
from .tesseract import TesseractAxis, TesseractMode
from .thermodynamic_workbody import (
    FieldCoupling,
    PhaseTile,
    ThermodynamicGrade,
    Workbody,
)

__all__ = [
    "Frame",
    "Ledger",
    "Reactor",
    "ReactorConfig",
    "RouteObservation",
    "RunResult",
    "DatasetFrame",
    "MarketDataset",
    "load_dataset",
    "ExperimentResult",
    "run_experiment",
    "ObserverEstimate",
    "LatencyProfile",
    "InformationBudget",
    "mutual_information_nats",
    "Claim",
    "Liability",
    "WealthState",
    "ConversionEdge",
    "ConversionNetwork",
    "WealthPhaseSnapshot",
    "evaluate_wealth_phase",
    "TesseractAxis",
    "TesseractMode",
    "ThermodynamicGrade",
    "PhaseTile",
    "FieldCoupling",
    "Workbody",
]
