"""Prepared-carrier ladder with evidence-gated migration."""

from __future__ import annotations

from dataclasses import dataclass
import math


@dataclass(frozen=True, slots=True)
class CarrierSpec:
    carrier_id: str
    priority: int
    invariant_key: str

    def __post_init__(self) -> None:
        if not self.carrier_id:
            raise ValueError("carrier_id must not be empty")
        if not self.invariant_key:
            raise ValueError("invariant_key must not be empty")


@dataclass(frozen=True, slots=True)
class CarrierSignal:
    carrier_id: str
    friction: float
    shock: float
    coherence: float
    operational_readiness: float
    capacity_reserve: float

    def __post_init__(self) -> None:
        for name, value in (
            ("friction", self.friction),
            ("shock", self.shock),
            ("coherence", self.coherence),
            ("operational_readiness", self.operational_readiness),
            ("capacity_reserve", self.capacity_reserve),
        ):
            if not 0 <= value <= 1 or not math.isfinite(value):
                raise ValueError(f"{name} must be finite and in [0, 1]")

    @property
    def migration_readiness(self) -> float:
        return (
            self.coherence
            + self.operational_readiness
            + self.capacity_reserve
        ) / 3.0


@dataclass(frozen=True, slots=True)
class CarrierLadderConfig:
    friction_threshold: float = 0.70
    shock_threshold: float = 0.80
    readiness_threshold: float = 0.72
    minimum_dwell_events: int = 2

    def __post_init__(self) -> None:
        for name, value in (
            ("friction_threshold", self.friction_threshold),
            ("shock_threshold", self.shock_threshold),
            ("readiness_threshold", self.readiness_threshold),
        ):
            if not 0 <= value <= 1:
                raise ValueError(f"{name} must be in [0, 1]")
        if self.minimum_dwell_events < 0:
            raise ValueError("minimum_dwell_events must be non-negative")


@dataclass(frozen=True, slots=True)
class MigrationRecord:
    event_id: int
    source: str
    target: str
    active_friction: float
    active_shock: float
    target_readiness: float
    invariant_key: str
    version: int


class CarrierLadder:
    """Deterministic migration controller; preparation alone never switches."""

    def __init__(
        self,
        specs: tuple[CarrierSpec, ...],
        active_carrier: str,
        config: CarrierLadderConfig | None = None,
    ) -> None:
        if not specs:
            raise ValueError("carrier ladder requires at least one carrier")
        self.specs = {spec.carrier_id: spec for spec in specs}
        if len(self.specs) != len(specs):
            raise ValueError("carrier_id values must be unique")
        if active_carrier not in self.specs:
            raise ValueError("active carrier must exist in specs")
        invariants = {spec.invariant_key for spec in specs}
        if len(invariants) != 1:
            raise ValueError("all carriers must preserve the same invariant_key")
        self.active_carrier = active_carrier
        self.config = config or CarrierLadderConfig()
        self.last_migration_event: int | None = None
        self.version = 0
        self.history: list[MigrationRecord] = []

    def step(
        self,
        event_id: int,
        signals: tuple[CarrierSignal, ...],
    ) -> MigrationRecord | None:
        by_id = {signal.carrier_id: signal for signal in signals}
        if len(by_id) != len(signals):
            raise ValueError("carrier signals must be unique")
        if self.active_carrier not in by_id:
            raise ValueError("active carrier signal is required")
        if any(carrier_id not in self.specs for carrier_id in by_id):
            raise ValueError("signal references an unknown carrier")

        active = by_id[self.active_carrier]
        pressure = (
            active.friction >= self.config.friction_threshold
            or active.shock >= self.config.shock_threshold
        )
        dwell_ok = (
            self.last_migration_event is None
            or event_id - self.last_migration_event
            >= self.config.minimum_dwell_events
        )
        if not pressure or not dwell_ok:
            return None

        eligible = [
            signal
            for signal in signals
            if signal.carrier_id != self.active_carrier
            and signal.migration_readiness >= self.config.readiness_threshold
        ]
        if not eligible:
            return None
        target = max(
            eligible,
            key=lambda signal: (
                signal.migration_readiness,
                signal.capacity_reserve,
                -self.specs[signal.carrier_id].priority,
                signal.carrier_id,
            ),
        )
        source_id = self.active_carrier
        self.active_carrier = target.carrier_id
        self.last_migration_event = event_id
        self.version += 1
        record = MigrationRecord(
            event_id=event_id,
            source=source_id,
            target=target.carrier_id,
            active_friction=active.friction,
            active_shock=active.shock,
            target_readiness=target.migration_readiness,
            invariant_key=self.specs[target.carrier_id].invariant_key,
            version=self.version,
        )
        self.history.append(record)
        return record
