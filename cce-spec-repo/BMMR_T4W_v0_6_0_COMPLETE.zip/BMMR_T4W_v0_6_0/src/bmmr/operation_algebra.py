"""Partially commutative resource operations with prefix viability checks."""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from math import isclose, isfinite


ResourceMap = Mapping[str, float]
Transition = Callable[[ResourceMap], ResourceMap]
ViabilityPredicate = Callable[[ResourceMap], bool]


def _canonical_state(state: ResourceMap) -> tuple[tuple[str, float], ...]:
    values = tuple(sorted((str(key), float(value)) for key, value in state.items()))
    if any(not isfinite(value) for _, value in values):
        raise ValueError("resource states must be finite")
    return values


@dataclass(frozen=True, slots=True)
class ResourceOperation:
    """A typed state transformer with an explicit read/write footprint."""

    name: str
    reads: frozenset[str]
    writes: frozenset[str]
    transition: Transition = field(compare=False, repr=False)

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("operation name must be non-empty")
        if not self.writes:
            raise ValueError("an operation must declare at least one write")

    def apply(self, state: ResourceMap) -> dict[str, float]:
        missing = self.reads.difference(state)
        if missing:
            raise KeyError(f"missing resources for {self.name}: {sorted(missing)}")
        before = dict(_canonical_state(state))
        after = dict(_canonical_state(self.transition(before)))
        changed = {
            key
            for key in before.keys() | after.keys()
            if not isclose(before.get(key, 0.0), after.get(key, 0.0), abs_tol=1e-12)
        }
        undeclared = changed.difference(self.writes)
        if undeclared:
            raise ValueError(
                f"operation {self.name} changed undeclared resources: "
                f"{sorted(undeclared)}"
            )
        return after


def structurally_independent(
    left: ResourceOperation,
    right: ResourceOperation,
) -> bool:
    """Return the conservative trace-monoid independence relation."""

    return not (
        left.writes & right.writes
        or left.writes & right.reads
        or right.writes & left.reads
    )


@dataclass(frozen=True, slots=True)
class CommutationCertificate:
    left: str
    right: str
    structurally_independent: bool
    observationally_commutes: bool
    left_then_right: tuple[tuple[str, float], ...]
    right_then_left: tuple[tuple[str, float], ...]


def commutation_certificate(
    left: ResourceOperation,
    right: ResourceOperation,
    state: ResourceMap,
    tolerance: float = 1e-12,
) -> CommutationCertificate:
    left_right = right.apply(left.apply(state))
    right_left = left.apply(right.apply(state))
    keys = left_right.keys() | right_left.keys()
    commutes = all(
        isclose(
            left_right.get(key, 0.0),
            right_left.get(key, 0.0),
            abs_tol=tolerance,
            rel_tol=tolerance,
        )
        for key in keys
    )
    return CommutationCertificate(
        left.name,
        right.name,
        structurally_independent(left, right),
        commutes,
        _canonical_state(left_right),
        _canonical_state(right_left),
    )


@dataclass(frozen=True, slots=True)
class ViabilityCertificate:
    viable: bool
    failed_after_operation: str | None
    prefix_states: tuple[tuple[tuple[str, float], ...], ...]


def certify_prefix_viability(
    operations: Sequence[ResourceOperation],
    initial_state: ResourceMap,
    predicate: ViabilityPredicate,
) -> ViabilityCertificate:
    """Check the viability predicate after every operation prefix."""

    current = dict(_canonical_state(initial_state))
    prefixes = [_canonical_state(current)]
    if not predicate(current):
        return ViabilityCertificate(False, "<initial>", tuple(prefixes))
    for operation in operations:
        current = operation.apply(current)
        prefixes.append(_canonical_state(current))
        if not predicate(current):
            return ViabilityCertificate(False, operation.name, tuple(prefixes))
    return ViabilityCertificate(True, None, tuple(prefixes))


def additive_operation(
    name: str,
    deltas: Mapping[str, float],
    reads: Sequence[str] = (),
) -> ResourceOperation:
    """Build a small deterministic operation used by tests and witnesses."""

    canonical_deltas = dict(_canonical_state(deltas))

    def transition(state: ResourceMap) -> ResourceMap:
        updated = dict(state)
        for key, delta in canonical_deltas.items():
            updated[key] = updated.get(key, 0.0) + delta
        return updated

    return ResourceOperation(
        name=name,
        reads=frozenset(reads),
        writes=frozenset(canonical_deltas),
        transition=transition,
    )


def reference_operation_witness() -> dict[str, object]:
    """Expose one commuting and one conflicting pair as an audit witness."""

    state = {"cash": 100.0, "reserve": 10.0, "signal": 0.0}
    mark_signal = additive_operation("mark_signal", {"signal": 1.0})
    add_reserve = additive_operation("add_reserve", {"reserve": 5.0})

    def spend_half(state_map: ResourceMap) -> ResourceMap:
        updated = dict(state_map)
        updated["cash"] = updated["cash"] * 0.5
        return updated

    halve_cash = ResourceOperation(
        "halve_cash", frozenset({"cash"}), frozenset({"cash"}), spend_half
    )
    add_cash = additive_operation("add_cash", {"cash": 10.0}, reads=("cash",))
    independent = commutation_certificate(mark_signal, add_reserve, state)
    conflicting = commutation_certificate(halve_cash, add_cash, state)
    return {
        "schema": "bmmr.operation-algebra-witness.v1",
        "independent_pair": {
            "left": independent.left,
            "right": independent.right,
            "structurally_independent": independent.structurally_independent,
            "observationally_commutes": independent.observationally_commutes,
        },
        "conflicting_pair": {
            "left": conflicting.left,
            "right": conflicting.right,
            "structurally_independent": conflicting.structurally_independent,
            "observationally_commutes": conflicting.observationally_commutes,
        },
    }
