"""Causal information budgets expressed in log-wealth units.

The module deliberately does not identify information with money.  It exposes
the narrower, defensible bridge used by growth-optimal portfolio theory:
mutual information can upper-bound the improvement in expected log-wealth
growth produced by causal side information.  Equality needs additional market
assumptions and is never inferred here.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from math import exp, isfinite, log
from typing import Sequence


def mutual_information_nats(
    joint: Sequence[Sequence[float]],
) -> float:
    """Return I(X;Y) in nats for a finite joint mass table.

    Inputs need not sum to one, but every entry must be finite and
    non-negative and the total mass must be positive.
    """

    rows = tuple(tuple(float(value) for value in row) for row in joint)
    if not rows or not rows[0]:
        raise ValueError("joint distribution must be a non-empty matrix")
    width = len(rows[0])
    if any(len(row) != width for row in rows):
        raise ValueError("joint distribution must be rectangular")
    if any(not isfinite(value) or value < 0.0 for row in rows for value in row):
        raise ValueError("joint masses must be finite and non-negative")
    total = sum(sum(row) for row in rows)
    if total <= 0.0:
        raise ValueError("joint distribution must have positive mass")

    probabilities = tuple(
        tuple(value / total for value in row)
        for row in rows
    )
    row_mass = tuple(sum(row) for row in probabilities)
    column_mass = tuple(
        sum(probabilities[index][column] for index in range(len(rows)))
        for column in range(width)
    )
    information = 0.0
    for row_index, row in enumerate(probabilities):
        for column_index, probability in enumerate(row):
            if probability <= 0.0:
                continue
            denominator = row_mass[row_index] * column_mass[column_index]
            information += probability * log(probability / denominator)
    return max(0.0, information)


@dataclass(frozen=True, slots=True)
class InformationBudget:
    """A causal side-information budget in dimensionless log-growth units."""

    mutual_information_nats: float
    causal_available: bool = True
    estimation_penalty_nats: float = 0.0
    execution_drag_nats: float = 0.0
    latency_drag_nats: float = 0.0
    model_class_penalty_nats: float = 0.0

    def __post_init__(self) -> None:
        values = (
            self.mutual_information_nats,
            self.estimation_penalty_nats,
            self.execution_drag_nats,
            self.latency_drag_nats,
            self.model_class_penalty_nats,
        )
        if any(not isfinite(value) or value < 0.0 for value in values):
            raise ValueError("information quantities must be finite and non-negative")

    @property
    def gross_log_growth_bound(self) -> float:
        """Maximum informational increment before implementation drag."""

        return self.mutual_information_nats if self.causal_available else 0.0

    @property
    def total_drag_nats(self) -> float:
        return (
            self.estimation_penalty_nats
            + self.execution_drag_nats
            + self.latency_drag_nats
            + self.model_class_penalty_nats
        )

    @property
    def usable_log_growth_bound(self) -> float:
        """Conservative remainder; still an upper bound, never a forecast."""

        return max(0.0, self.gross_log_growth_bound - self.total_drag_nats)

    @property
    def one_step_wealth_multiplier_bound(self) -> float:
        return exp(self.usable_log_growth_bound)

    @classmethod
    def from_joint(
        cls,
        joint: Sequence[Sequence[float]],
        **kwargs: float | bool,
    ) -> "InformationBudget":
        return cls(mutual_information_nats(joint), **kwargs)

    def as_dict(self) -> dict[str, float | bool | str]:
        return {
            "schema": "bmmr.information-budget.v1",
            **asdict(self),
            "gross_log_growth_bound": self.gross_log_growth_bound,
            "total_drag_nats": self.total_drag_nats,
            "usable_log_growth_bound": self.usable_log_growth_bound,
            "one_step_wealth_multiplier_bound": (
                self.one_step_wealth_multiplier_bound
            ),
            "interpretation": (
                "upper bound under a declared log-growth contract; "
                "not expected return and not a profitability guarantee"
            ),
        }
