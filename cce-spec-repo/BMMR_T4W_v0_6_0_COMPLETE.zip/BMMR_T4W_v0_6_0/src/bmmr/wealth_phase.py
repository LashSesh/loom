"""Executable wealth-phase ontology for the BMMR research kernel.

Wealth is represented as a typed configuration of claims, obligations,
conversion rights, information and admissibility constraints.  A "phase" is
an equivalence class induced by operational order parameters (solvency,
liquidatability, conversion topology, anisotropic mobility and causal
information activity), not a claim that money is a new physical substance.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
import json
from math import atan2, cos, exp, isfinite, log, sin, sqrt
from pathlib import Path
from typing import Iterable, Mapping, Sequence

from .information_phase import InformationBudget


EPSILON = 1e-12


def _finite_nonnegative(name: str, value: float) -> None:
    if not isfinite(value) or value < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")


@dataclass(frozen=True, slots=True)
class Claim:
    asset: str
    quantity: float
    venue: str = "ledger"
    settled: bool = True
    encumbered_quantity: float = 0.0
    settlement_delay_ms: float = 0.0
    provenance: str = "declared"

    def __post_init__(self) -> None:
        if not self.asset or not self.venue or not self.provenance:
            raise ValueError("claim identifiers must be non-empty")
        _finite_nonnegative("quantity", self.quantity)
        _finite_nonnegative("encumbered_quantity", self.encumbered_quantity)
        _finite_nonnegative("settlement_delay_ms", self.settlement_delay_ms)
        if self.encumbered_quantity > self.quantity + EPSILON:
            raise ValueError("encumbered quantity cannot exceed claim quantity")

    @property
    def unencumbered_quantity(self) -> float:
        return max(0.0, self.quantity - self.encumbered_quantity)


@dataclass(frozen=True, slots=True)
class Liability:
    asset: str
    quantity: float
    due_delay_ms: float = 0.0
    seniority: int = 0
    provenance: str = "declared"

    def __post_init__(self) -> None:
        if not self.asset or not self.provenance:
            raise ValueError("liability identifiers must be non-empty")
        _finite_nonnegative("quantity", self.quantity)
        _finite_nonnegative("due_delay_ms", self.due_delay_ms)
        if self.seniority < 0:
            raise ValueError("seniority must be non-negative")


@dataclass(frozen=True, slots=True)
class WealthState:
    numeraire: str
    claims: tuple[Claim, ...]
    liabilities: tuple[Liability, ...] = ()

    def __post_init__(self) -> None:
        if not self.numeraire:
            raise ValueError("numeraire must be non-empty")


@dataclass(frozen=True, slots=True)
class ConversionEdge:
    source: str
    target: str
    mid_rate: float
    proportional_cost: float
    uncertainty_haircut: float
    capacity_source: float
    latency_ms: float
    capacity_weight: float = 1.0
    route_id: str = "declared"

    def __post_init__(self) -> None:
        if not self.source or not self.target or self.source == self.target:
            raise ValueError("conversion edge needs two distinct assets")
        if not self.route_id:
            raise ValueError("route_id must be non-empty")
        if not isfinite(self.mid_rate) or self.mid_rate <= 0.0:
            raise ValueError("mid_rate must be finite and positive")
        for name, value in (
            ("proportional_cost", self.proportional_cost),
            ("uncertainty_haircut", self.uncertainty_haircut),
        ):
            if not isfinite(value) or value < 0.0 or value >= 1.0:
                raise ValueError(f"{name} must lie in [0, 1)")
        if not isfinite(self.capacity_source) or self.capacity_source <= 0.0:
            raise ValueError("capacity_source must be finite and positive")
        if not isfinite(self.capacity_weight) or self.capacity_weight <= 0.0:
            raise ValueError("capacity_weight must be finite and positive")
        _finite_nonnegative("latency_ms", self.latency_ms)

    @property
    def nominal_rate(self) -> float:
        return self.mid_rate * (1.0 - self.proportional_cost)

    @property
    def robust_rate(self) -> float:
        return self.nominal_rate * (1.0 - self.uncertainty_haircut)

    def impedance(self, horizon_ms: float) -> float:
        """Dimensionless execution drag, excluding the asset price ratio."""

        time_drag = self.latency_ms / max(horizon_ms, EPSILON)
        retained = (1.0 - self.proportional_cost) * (
            1.0 - self.uncertainty_haircut
        )
        return -log(retained) + time_drag


@dataclass(frozen=True, slots=True)
class ConversionPath:
    assets: tuple[str, ...]
    route_ids: tuple[str, ...]
    nominal_rate: float
    robust_rate: float
    source_capacity: float
    latency_ms: float

    def value(self, quantity: float, robust: bool) -> float:
        rate = self.robust_rate if robust else self.nominal_rate
        return min(quantity, self.source_capacity) * rate


@dataclass(frozen=True, slots=True)
class ConversionNetwork:
    edges: tuple[ConversionEdge, ...]

    def __post_init__(self) -> None:
        identities = [(edge.source, edge.target, edge.route_id) for edge in self.edges]
        if len(identities) != len(set(identities)):
            raise ValueError("conversion edge identities must be unique")

    @property
    def assets(self) -> tuple[str, ...]:
        return tuple(sorted({item for edge in self.edges for item in (edge.source, edge.target)}))

    def outgoing(self, asset: str) -> tuple[ConversionEdge, ...]:
        return tuple(
            sorted(
                (edge for edge in self.edges if edge.source == asset),
                key=lambda edge: (edge.target, edge.route_id),
            )
        )

    def simple_paths(
        self,
        source: str,
        target: str,
        horizon_ms: float,
        max_hops: int | None = None,
    ) -> tuple[ConversionPath, ...]:
        if source == target:
            return (ConversionPath((source,), (), 1.0, 1.0, float("inf"), 0.0),)
        if max_hops is None:
            max_hops = max(1, len(self.assets) - 1)
        paths: list[ConversionPath] = []

        def visit(
            current: str,
            visited: tuple[str, ...],
            routes: tuple[str, ...],
            nominal_rate: float,
            robust_rate: float,
            source_capacity: float,
            latency_ms: float,
        ) -> None:
            if len(routes) >= max_hops:
                return
            for edge in self.outgoing(current):
                if edge.target in visited:
                    continue
                new_latency = latency_ms + edge.latency_ms
                if new_latency > horizon_ms + EPSILON:
                    continue
                edge_source_capacity = edge.capacity_source / max(
                    nominal_rate, EPSILON
                )
                new_capacity = min(source_capacity, edge_source_capacity)
                new_nominal = nominal_rate * edge.nominal_rate
                new_robust = robust_rate * edge.robust_rate
                new_assets = (*visited, edge.target)
                new_routes = (*routes, edge.route_id)
                if edge.target == target:
                    paths.append(
                        ConversionPath(
                            new_assets,
                            new_routes,
                            new_nominal,
                            new_robust,
                            new_capacity,
                            new_latency,
                        )
                    )
                else:
                    visit(
                        edge.target,
                        new_assets,
                        new_routes,
                        new_nominal,
                        new_robust,
                        new_capacity,
                        new_latency,
                    )

        visit(source, (source,), (), 1.0, 1.0, float("inf"), 0.0)
        return tuple(
            sorted(paths, key=lambda path: (path.assets, path.route_ids))
        )

    def best_path(
        self,
        source: str,
        target: str,
        quantity: float,
        horizon_ms: float,
        robust: bool,
        require_full_capacity: bool = False,
    ) -> ConversionPath | None:
        candidates = self.simple_paths(source, target, horizon_ms)
        if require_full_capacity:
            candidates = tuple(
                path
                for path in candidates
                if path.source_capacity + EPSILON >= quantity
            )
        if not candidates:
            return None
        return max(
            candidates,
            key=lambda path: (
                path.value(quantity, robust),
                -path.latency_ms,
                path.route_ids,
            ),
        )


@dataclass(frozen=True, slots=True)
class WealthValuation:
    numeraire: str
    nominal_immediate_value: float
    robust_immediate_value: float
    nominal_horizon_value: float
    robust_horizon_value: float
    solvency_floor: float
    solvency_margin: float
    accounting_closed: bool
    liquid: bool
    solvent: bool
    immediate_unliquidatable_assets: tuple[str, ...]
    unliquidatable_assets: tuple[str, ...]
    immediate_uncovered_liabilities: tuple[str, ...]
    uncovered_liabilities: tuple[str, ...]


def _available_claim_quantity(
    claim: Claim,
    horizon_ms: float,
    immediate: bool,
) -> float:
    if immediate and not claim.settled:
        return 0.0
    if not immediate and not claim.settled and claim.settlement_delay_ms > horizon_ms:
        return 0.0
    return claim.unencumbered_quantity


def _portfolio_value(
    state: WealthState,
    network: ConversionNetwork,
    horizon_ms: float,
    robust: bool,
    immediate: bool,
) -> tuple[float, set[str], set[str]]:
    value = 0.0
    missing_claims: set[str] = set()
    missing_liabilities: set[str] = set()
    effective_horizon = 0.0 if immediate else horizon_ms
    for claim in state.claims:
        quantity = _available_claim_quantity(claim, horizon_ms, immediate)
        if claim.quantity > quantity + EPSILON:
            # Encumbered or not-yet-settled units are real claims, but they are
            # not part of the executable liquidation set at this horizon.
            missing_claims.add(claim.asset)
        if quantity <= EPSILON:
            continue
        if claim.asset == state.numeraire:
            value += quantity
            continue
        # Prefer a route that closes the complete claim.  If none exists, a
        # partial path may still contribute a conservative executable value,
        # but the asset remains explicitly unliquidatable.
        path = network.best_path(
            claim.asset,
            state.numeraire,
            quantity,
            effective_horizon,
            robust,
            require_full_capacity=True,
        )
        if path is None:
            path = network.best_path(
                claim.asset,
                state.numeraire,
                quantity,
                effective_horizon,
                robust,
            )
            missing_claims.add(claim.asset)
            if path is None:
                continue
        value += path.value(quantity, robust)

    for liability in sorted(state.liabilities, key=lambda item: item.seniority):
        if immediate and liability.due_delay_ms > EPSILON:
            continue
        if not immediate and liability.due_delay_ms > horizon_ms + EPSILON:
            continue
        if liability.asset == state.numeraire:
            value -= liability.quantity
            continue
        paths = network.simple_paths(
            state.numeraire,
            liability.asset,
            effective_horizon,
        )
        if not paths:
            missing_liabilities.add(liability.asset)
            continue
        # Liability quantity is expressed in the target asset; route capacity
        # is expressed in the source asset.  Compare them only after applying
        # the path rate, and value the obligation even when capacity closure
        # fails so an uncovered liability cannot silently improve net wealth.
        path = min(
            paths,
            key=lambda candidate: (
                liability.quantity
                / (
                    candidate.robust_rate
                    if robust
                    else candidate.nominal_rate
                ),
                candidate.latency_ms,
                candidate.route_ids,
            ),
        )
        rate = path.robust_rate if robust else path.nominal_rate
        required_source = liability.quantity / rate
        value -= required_source
        if path.source_capacity + EPSILON < required_source:
            missing_liabilities.add(liability.asset)
    return value, missing_claims, missing_liabilities


def value_wealth_state(
    state: WealthState,
    network: ConversionNetwork,
    horizon_ms: float,
    solvency_floor: float,
) -> WealthValuation:
    _finite_nonnegative("horizon_ms", horizon_ms)
    _finite_nonnegative("solvency_floor", solvency_floor)
    nominal_now, missing_now, uncovered_now = _portfolio_value(
        state, network, horizon_ms, False, True
    )
    robust_now, robust_missing_now, robust_uncovered_now = _portfolio_value(
        state, network, horizon_ms, True, True
    )
    nominal_horizon, missing_horizon, uncovered_horizon = _portfolio_value(
        state, network, horizon_ms, False, False
    )
    robust_horizon, robust_missing_horizon, robust_uncovered_horizon = _portfolio_value(
        state, network, horizon_ms, True, False
    )
    immediate_missing = tuple(sorted(missing_now | robust_missing_now))
    missing = tuple(sorted(missing_horizon | robust_missing_horizon))
    immediate_uncovered = tuple(sorted(uncovered_now | robust_uncovered_now))
    uncovered = tuple(sorted(uncovered_horizon | robust_uncovered_horizon))
    closed = not uncovered
    liquid = closed and not missing
    margin = robust_horizon - solvency_floor
    solvent = closed and margin >= -EPSILON
    return WealthValuation(
        state.numeraire,
        nominal_now,
        robust_now,
        nominal_horizon,
        robust_horizon,
        solvency_floor,
        margin,
        closed,
        liquid,
        solvent,
        immediate_missing,
        missing,
        immediate_uncovered,
        uncovered,
    )


def _strong_components(
    assets: Sequence[str],
    edges: Iterable[ConversionEdge],
) -> tuple[tuple[str, ...], ...]:
    nodes = tuple(sorted(set(assets)))
    adjacency = {node: [] for node in nodes}
    reverse = {node: [] for node in nodes}
    for edge in edges:
        if edge.source in adjacency and edge.target in adjacency:
            adjacency[edge.source].append(edge.target)
            reverse[edge.target].append(edge.source)
    visited: set[str] = set()
    order: list[str] = []

    def first(node: str) -> None:
        visited.add(node)
        for target in sorted(adjacency[node]):
            if target not in visited:
                first(target)
        order.append(node)

    for node in nodes:
        if node not in visited:
            first(node)
    visited.clear()
    components: list[tuple[str, ...]] = []

    def second(node: str, component: list[str]) -> None:
        visited.add(node)
        component.append(node)
        for target in sorted(reverse[node]):
            if target not in visited:
                second(target, component)

    for node in reversed(order):
        if node not in visited:
            component: list[str] = []
            second(node, component)
            components.append(tuple(sorted(component)))
    return tuple(sorted(components))


def _jacobi_eigensystem(
    matrix: Sequence[Sequence[float]],
) -> tuple[tuple[float, ...], tuple[tuple[float, ...], ...]]:
    size = len(matrix)
    if size == 0:
        return (), ()
    values = [list(row) for row in matrix]
    vectors = [[1.0 if row == column else 0.0 for column in range(size)] for row in range(size)]
    for _ in range(80 * size * size):
        p, q = 0, 0
        largest = 0.0
        for row in range(size):
            for column in range(row + 1, size):
                candidate = abs(values[row][column])
                if candidate > largest:
                    largest, p, q = candidate, row, column
        if largest < 1e-14:
            break
        app, aqq, apq = values[p][p], values[q][q], values[p][q]
        angle = 0.5 * atan2(2.0 * apq, aqq - app)
        cosine = cos(angle)
        sine = sin(angle)
        for index in range(size):
            if index in (p, q):
                continue
            aip, aiq = values[index][p], values[index][q]
            values[index][p] = values[p][index] = cosine * aip - sine * aiq
            values[index][q] = values[q][index] = sine * aip + cosine * aiq
        values[p][p] = cosine * cosine * app - 2.0 * sine * cosine * apq + sine * sine * aqq
        values[q][q] = sine * sine * app + 2.0 * sine * cosine * apq + cosine * cosine * aqq
        values[p][q] = values[q][p] = 0.0
        for index in range(size):
            vip, viq = vectors[index][p], vectors[index][q]
            vectors[index][p] = cosine * vip - sine * viq
            vectors[index][q] = sine * vip + cosine * viq
    pairs = sorted(
        (
            values[index][index],
            tuple(vectors[row][index] for row in range(size)),
        )
        for index in range(size)
    )
    pairs.reverse()
    return tuple(item[0] for item in pairs), tuple(item[1] for item in pairs)


@dataclass(frozen=True, slots=True)
class AnisotropyReport:
    coordinate_assets: tuple[str, ...]
    order_tensor: tuple[tuple[float, ...], ...]
    order_parameter: float
    principal_direction: tuple[float, ...]
    spectral_gap: float
    active_edge_count: int


def analyze_anisotropy(
    network: ConversionNetwork,
    numeraire: str,
    relevant_assets: Sequence[str],
    horizon_ms: float,
) -> AnisotropyReport:
    coordinates = tuple(sorted(set(relevant_assets).difference({numeraire})))
    dimension = len(coordinates)
    if dimension <= 1:
        return AnisotropyReport(
            coordinates,
            tuple(tuple(0.0 for _ in range(dimension)) for _ in range(dimension)),
            0.0,
            tuple(1.0 for _ in range(dimension)),
            0.0,
            0,
        )
    index = {asset: position for position, asset in enumerate(coordinates)}
    tensor = [[0.0 for _ in range(dimension)] for _ in range(dimension)]
    total_weight = 0.0
    active_count = 0
    relevant = set(relevant_assets)
    for edge in network.edges:
        if (
            edge.latency_ms > horizon_ms + EPSILON
            or edge.source not in relevant
            or edge.target not in relevant
        ):
            continue
        direction = [0.0 for _ in range(dimension)]
        if edge.source != numeraire:
            direction[index[edge.source]] -= 1.0
        if edge.target != numeraire:
            direction[index[edge.target]] += 1.0
        norm = sqrt(sum(value * value for value in direction))
        if norm <= EPSILON:
            continue
        direction = [value / norm for value in direction]
        weight = edge.capacity_weight * exp(-edge.impedance(horizon_ms))
        total_weight += weight
        active_count += 1
        for row in range(dimension):
            for column in range(dimension):
                tensor[row][column] += weight * direction[row] * direction[column]
    if total_weight <= EPSILON:
        return AnisotropyReport(
            coordinates,
            tuple(tuple(0.0 for _ in range(dimension)) for _ in range(dimension)),
            0.0,
            tuple(0.0 for _ in range(dimension)),
            0.0,
            0,
        )
    for row in range(dimension):
        for column in range(dimension):
            tensor[row][column] /= total_weight
        tensor[row][row] -= 1.0 / dimension
    frobenius_sq = sum(value * value for row in tensor for value in row)
    order = min(1.0, sqrt(dimension / (dimension - 1.0) * frobenius_sq))
    eigenvalues, eigenvectors = _jacobi_eigensystem(tensor)
    gap = eigenvalues[0] - eigenvalues[1] if len(eigenvalues) > 1 else 0.0
    return AnisotropyReport(
        coordinates,
        tuple(tuple(value for value in row) for row in tensor),
        order,
        eigenvectors[0] if eigenvectors else (),
        gap,
        active_count,
    )


@dataclass(frozen=True, slots=True)
class WealthPhaseThresholds:
    horizon_ms: float
    solvency_floor: float
    anisotropy_order_threshold: float
    active_information_threshold_nats: float

    def __post_init__(self) -> None:
        _finite_nonnegative("horizon_ms", self.horizon_ms)
        _finite_nonnegative("solvency_floor", self.solvency_floor)
        for name, value in (
            ("anisotropy_order_threshold", self.anisotropy_order_threshold),
            ("active_information_threshold_nats", self.active_information_threshold_nats),
        ):
            if not isfinite(value) or value < 0.0:
                raise ValueError(f"{name} must be finite and non-negative")


@dataclass(frozen=True, slots=True)
class WealthPhaseSnapshot:
    name: str
    regime: str
    valuation: WealthValuation
    information: InformationBudget
    anisotropy: AnisotropyReport
    conversion_components: tuple[tuple[str, ...], ...]
    controller_expends_work: bool
    informationally_active: bool
    thresholds: WealthPhaseThresholds

    def as_dict(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "schema": "bmmr.wealth-phase-snapshot.v1",
            "name": self.name,
            "regime": self.regime,
            "valuation": asdict(self.valuation),
            "information": self.information.as_dict(),
            "anisotropy": asdict(self.anisotropy),
            "conversion_components": self.conversion_components,
            "controller_expends_work": self.controller_expends_work,
            "informationally_active": self.informationally_active,
            "thresholds": asdict(self.thresholds),
        }
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False)
        payload["phase_id"] = sha256(canonical.encode("utf-8")).hexdigest()
        return payload


def _relevant_assets(
    state: WealthState,
    horizon_ms: float,
) -> tuple[str, ...]:
    assets = {state.numeraire}
    assets.update(
        claim.asset
        for claim in state.claims
        if _available_claim_quantity(claim, horizon_ms, False) > EPSILON
    )
    assets.update(
        liability.asset
        for liability in state.liabilities
        if liability.due_delay_ms <= horizon_ms + EPSILON
    )
    return tuple(sorted(assets))


def evaluate_wealth_phase(
    name: str,
    state: WealthState,
    network: ConversionNetwork,
    information: InformationBudget,
    thresholds: WealthPhaseThresholds,
    controller_expends_work: bool,
) -> WealthPhaseSnapshot:
    valuation = value_wealth_state(
        state,
        network,
        thresholds.horizon_ms,
        thresholds.solvency_floor,
    )
    relevant = _relevant_assets(state, thresholds.horizon_ms)
    active_edges = tuple(
        edge
        for edge in network.edges
        if edge.latency_ms <= thresholds.horizon_ms + EPSILON
    )
    components = _strong_components(relevant, active_edges)
    anisotropy = analyze_anisotropy(
        network, state.numeraire, relevant, thresholds.horizon_ms
    )
    information_active = bool(
        controller_expends_work
        and information.causal_available
        and information.usable_log_growth_bound
        >= thresholds.active_information_threshold_nats
    )
    ordered = (
        anisotropy.order_parameter
        >= thresholds.anisotropy_order_threshold
    )
    if not valuation.accounting_closed or not valuation.solvent:
        regime = "insolvent_or_unclosed"
    elif not valuation.liquid or len(components) > 1:
        regime = "locked_or_fragmented"
    elif information_active and ordered:
        regime = "informationally_active_anisotropic_fluid"
    elif information_active:
        regime = "informationally_active_fluid"
    elif ordered:
        regime = "anisotropic_fluid"
    else:
        regime = "isotropic_fluid"
    return WealthPhaseSnapshot(
        name,
        regime,
        valuation,
        information,
        anisotropy,
        components,
        controller_expends_work,
        information_active,
        thresholds,
    )


@dataclass(frozen=True, slots=True)
class PhaseTransition:
    changed: bool
    source_regime: str
    target_regime: str
    reasons: tuple[str, ...]


def detect_phase_transition(
    source: WealthPhaseSnapshot,
    target: WealthPhaseSnapshot,
) -> PhaseTransition:
    reasons: list[str] = []
    if source.regime != target.regime:
        reasons.append("regime_changed")
    if source.valuation.solvent != target.valuation.solvent:
        reasons.append("solvency_boundary_crossed")
    if source.valuation.liquid != target.valuation.liquid:
        reasons.append("liquidation_closure_changed")
    if len(source.conversion_components) != len(target.conversion_components):
        reasons.append("conversion_topology_changed")
    source_ordered = source.anisotropy.order_parameter >= source.thresholds.anisotropy_order_threshold
    target_ordered = target.anisotropy.order_parameter >= target.thresholds.anisotropy_order_threshold
    if source_ordered != target_ordered:
        reasons.append("orientational_order_boundary_crossed")
    if source.informationally_active != target.informationally_active:
        reasons.append("information_activity_boundary_crossed")
    return PhaseTransition(
        bool(reasons), source.regime, target.regime, tuple(reasons)
    )


@dataclass(frozen=True, slots=True)
class WealthScenario:
    name: str
    state: WealthState
    network: ConversionNetwork
    information: InformationBudget
    thresholds: WealthPhaseThresholds
    controller_expends_work: bool


@dataclass(frozen=True, slots=True)
class LoadedWealthPhase:
    schema: str
    digest: str
    base: WealthScenario
    stress: WealthScenario


def _scenario_from_mapping(name: str, value: Mapping[str, object]) -> WealthScenario:
    state_data = value["state"]
    if not isinstance(state_data, Mapping):
        raise ValueError("state must be an object")
    claims = tuple(Claim(**item) for item in state_data.get("claims", ()))
    liabilities = tuple(
        Liability(**item) for item in state_data.get("liabilities", ())
    )
    state = WealthState(str(state_data["numeraire"]), claims, liabilities)
    edges = tuple(ConversionEdge(**item) for item in value.get("conversions", ()))
    information_data = value["information"]
    if not isinstance(information_data, Mapping):
        raise ValueError("information must be an object")
    joint = information_data.get("joint")
    if not isinstance(joint, Sequence):
        raise ValueError("information joint table must be an array")
    info_kwargs = {
        key: information_data[key]
        for key in (
            "causal_available",
            "estimation_penalty_nats",
            "execution_drag_nats",
            "latency_drag_nats",
            "model_class_penalty_nats",
        )
        if key in information_data
    }
    information = InformationBudget.from_joint(joint, **info_kwargs)
    thresholds_data = value["thresholds"]
    if not isinstance(thresholds_data, Mapping):
        raise ValueError("thresholds must be an object")
    thresholds = WealthPhaseThresholds(**thresholds_data)
    return WealthScenario(
        name,
        state,
        ConversionNetwork(edges),
        information,
        thresholds,
        bool(value.get("controller_expends_work", False)),
    )


def load_wealth_phase(path: str | Path) -> LoadedWealthPhase:
    source = Path(path)
    data = json.loads(source.read_text(encoding="utf-8"))
    if data.get("schema") != "bmmr.wealth-phase-input.v1":
        raise ValueError("unsupported wealth-phase input schema")
    digest = sha256(
        json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    ).hexdigest()
    return LoadedWealthPhase(
        data["schema"],
        digest,
        _scenario_from_mapping("base", data["base"]),
        _scenario_from_mapping("stress", data["stress"]),
    )


def wealth_phase_artifact(loaded: LoadedWealthPhase) -> dict[str, object]:
    base = evaluate_wealth_phase(
        loaded.base.name,
        loaded.base.state,
        loaded.base.network,
        loaded.base.information,
        loaded.base.thresholds,
        loaded.base.controller_expends_work,
    )
    stress = evaluate_wealth_phase(
        loaded.stress.name,
        loaded.stress.state,
        loaded.stress.network,
        loaded.stress.information,
        loaded.stress.thresholds,
        loaded.stress.controller_expends_work,
    )
    transition = detect_phase_transition(base, stress)
    return {
        "schema": "bmmr.wealth-phase-artifact.v1",
        "input_digest": loaded.digest,
        "ontological_status": (
            "operational dynamical phase over financial claims, conversion rights, "
            "information and constraints; no physical phase-of-matter claim"
        ),
        "base": base.as_dict(),
        "stress": stress.as_dict(),
        "transition": asdict(transition),
        "information_to_wealth_contract": (
            "usable information is reported only as an upper bound on incremental "
            "log-wealth growth under the declared causal contract"
        ),
        "implementation_scope": (
            "finite simple-path liquidation witnesses; not a full generalized-flow "
            "or live order-book solver"
        ),
    }
