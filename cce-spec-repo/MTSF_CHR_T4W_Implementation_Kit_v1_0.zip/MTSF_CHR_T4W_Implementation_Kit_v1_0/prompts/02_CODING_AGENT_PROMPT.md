# Coding Agent Prompt - MTSF-CHR-T4W

Arbeite im aktuellen LOOM/CCE-Repository. Das Paket `MTSF_CHR_T4W_Implementation_Kit_v1_0` ist der Zielvertrag. Falls ein vom Research-Agent erzeugtes `IMPLEMENTATION_DELTA.md` vorliegt, ist es die repositoryspezifische Pfadabbildung; es darf die Zielidentität nicht verändern.

## Ausführungsregel

Implementiere die Work Packages P0-P10 strikt sequenziell. Vor jeder Phase:

- lies ihre Eingänge und Exit-Gates;
- prüfe bestehende Tests;
- ändere nur die vorgesehenen Pfade;
- erzeuge positive und negative Zeugen;
- führe fmt, clippy, Unit-, Property-, Conformance- und Roundtriptests aus;
- schreibe einen `PHASE_REPORT_Px.md` mit Dateien, Tests, Gates, Residuen und Digests.

## Zentrale Invarianten

- `DomainAdapter` 11/11.
- Ground Truth bleibt technisch getrennt.
- T4W bleibt Vorwärtsmodell und Zielontologie.
- Vector-Theremin wählt Beobachtungsoperatoren/Interventionen; es erzeugt keine Wahrheit.
- Historienmehrdeutigkeit bleibt sichtbar.
- harte Gates sind boolesch, begründet und fail-closed.
- kein neues `.loom`-Segment in Phase 1.
- keine CoreExtension ohne den im Paket definierten Defizitnachweis.
- keine direkte Änderung generierter Katalogdaten.
- keine Floatbytes als kanonische Identität.

## Abschluss

Der Auftrag ist erst abgeschlossen, wenn `DEFINITION_OF_DONE.md` vollständig nachgewiesen ist und ein Endbericht folgende Artefakte referenziert:

- Reference-Cubes R1-R7;
- Negative-Cubes N1-N24;
- Blind-Benchmark und Baselines;
- Adapter-Parität;
- PHC/LOOM/.loom-Konformität;
- Replay- und Reanalyseidentität;
- vollständiges Residuenregister;
- No-Core-Regression.

Ein nicht erfülltes Gate führt zu Hold/Sink und bleibt offen; es wird nicht rhetorisch abgeschlossen.
