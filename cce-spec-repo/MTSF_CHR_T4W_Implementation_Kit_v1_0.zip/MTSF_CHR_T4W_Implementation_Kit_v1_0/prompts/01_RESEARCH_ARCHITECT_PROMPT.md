# Research/Architecture Agent Prompt

Du erhältst das Paket `MTSF_CHR_T4W_Implementation_Kit_v1_0` und einen aktuellen Checkout des LOOM/CCE-Repositories.

## Auftrag

Erzeuge keine neue Architektur. Verifiziere stattdessen, wie die im Paket fixierte Zielidentität im aktuellen Repository minimal-invasiv und vollständig realisiert wird. Lies die Dateien in der Reihenfolge aus `README_START_HERE.md`. Danach:

1. inventarisiere den Repositorystand, Trait-Signaturen, Crate-DAG, vorhandene Formatsegmente und Konformitätstests;
2. vergleiche sie mit `REPOSITORY_INTEGRATION_PLAN.md`;
3. erstelle `IMPLEMENTATION_DELTA.md` mit exakten Pfaden, Typen, Abhängigkeiten, Testdateien und Migrationen;
4. verifiziere, ob die Originalquellen des T4W-Referenzkerns vorhanden sind; fehlt etwas, führe es als Residuum, erfinde keine Parität;
5. ordne jeden Implementierungsschritt einem Work Package, einer Traceability-ID, einem Gate und mindestens einem positiven/negativen Witness zu;
6. liefere einen sequenziellen Buildplan, der keine Phase vor ihrem Ausgangsgate beginnt;
7. öffne eine CoreExtension nur bei reproduzierbarem Ausdrucksdefizit; ansonsten bleibe im DomainAdapter;
8. klassifiziere jede Abweichung als Pfadupdate, API-Delta, echte Semantikänderung oder Residuum.

## Verboten

- LOOM, PHC, CCE oder `.loom` neu erfinden;
- den 213-Domänen-Katalog direkt editieren;
- Ground Truth in den Rekonstruktionspfad leaken;
- synthetische Closure als G2-Physik oder Profitabilität ausgeben;
- unsichtbare Approximation oder Residuenabsorption;
- eine technische Entscheidung nur aus Namensähnlichkeit treffen.

## Ausgabe

- `IMPLEMENTATION_DELTA.md`
- `REPO_PATH_MAP.json`
- `DEPENDENCY_DAG_REPORT.md`
- `RESOURCE_GAP_REPORT.md`
- `PHASED_BUILD_PLAN.md`
- `FINAL_CODING_PROMPT.md`

Beende den Auftrag erst, wenn die Coding-Prompt ohne weitere Architekturentscheidung ausführbar ist.
