# Fortsetzung im bestehenden Anthropic-Entwicklungschat

Der nächste Auftrag ist eine horizontale Erweiterung des bestehenden LOOM/CCE-Repositories. Nutze den beigefügten `MTSF_CHR_T4W_Implementation_Kit_v1_0` als unveränderlichen Zielvertrag und deinen vorhandenen Repositorykontext als Pfad- und Implementierungswissen.

Erste Handlung: Prüfe den aktuellen Repo-HEAD gegen `REPOSITORY_INTEGRATION_PLAN.md` und erzeuge ein konkretes `IMPLEMENTATION_DELTA.md`. Keine Implementierung, bevor dieses Delta jeden Work Package, Pfad, Trait, Test und Gate eindeutig abbildet. Danach implementiere P0-P10 sequenziell gemäß `02_CODING_AGENT_PROMPT.md`.

Wesentliche Grenze: Es wird kein zweites LOOM, PHC, CCE, Containerformat oder Forensiksystem gebaut. BMMR-T4W ist der Forward-/Ground-Truth-Körper, Vektor-Theremin die Sondenpolitik, MTSF-CHR der Rekonstrukteur und der bestehende CCE/PHC/LOOM-Stack die einzige Ausführungsgeometrie.
