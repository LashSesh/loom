# Ressourcenaufnahme und Beilageliste

## A. Im Bundle enthalten - für den Projektstart ausreichend

1. BMMR-T4W Masterspezifikation v0.6.0.
2. Vektor-Theremin Mastermonografie v1.0.
3. Projektiver Chronovisor / MTSF-CHR v1.0 samt Profil.
4. MTSF v1.1 CCE/LOOM-Rebase.
5. LOOM/CCE-Repository-Snapshot.
6. BMMR Zielidentitäts-/Agentenspezifikation v0.7.0.
7. PSP Formal Specification v1.0.0.
8. Projektiver Hypercube-Codec v0.1.
9. LOOM Generative Inversion v0.2.
10. QOFC Band II und Addendum C für G13/Closure-Herkunft.

Diese Quellen sind im Ordner `sources/` als Referenzen enthalten. Normativ für die Implementation ist zuerst der aktive Repositorystand, dann die in diesem Kit fixierte Integrationsspezifikation, danach die beigefügten Quellwerke.

## B. Noch beizulegen, sofern vorhanden

### B1 - Stark empfohlen / für Paritätsnachweis praktisch erforderlich

**Originaler T4W-Referenzkern einschließlich Tests**:

```text
tesseract.py
thermodynamic_workbody.py
tpomc_repairs.py
workbody_lab.py
zugehörige Fixtures, Run Descriptor, Manifest und 91 Tests
```

Ohne diese Dateien kann der Agent T4W aus der Spezifikation neu implementieren. Er kann dann jedoch keine bit- oder verhaltensgleiche Parität zur bereits existierenden Referenzimplementation behaupten. Das Residuum lautet `missing_t4w_reference_core`.

### B2 - Empfohlen, falls bereits vorhanden

- Quellcode oder Prototyp des Vektor-Theremins.
- Originale maschinenlesbare Schemas/Trace-Daten des T4W-Referenzlaufs.
- der aktuellste, nicht nur der hier beigefügte LOOM/CCE-Checkout.
- bestehende BMMR-Marktadapter, Datenmodelle oder Ausführungsprototypen.

### B3 - Erst für spätere Produktadapter

- kausal versionierte Level-2-/Trade-Daten;
- Gebühren-, Spread-, Slippage-, Queue- und Fillmodelle;
- Walk-forward-Splits und Leakage-Policy;
- Hardware-/Sensorprotokolle für eine physische Theremin-Instanz;
- reale Materialparameter und Messdaten für G2-Thermodynamik.

Diese Ressourcen sind **nicht** erforderlich, um den synthetischen CHR-T4W-Kern zu implementieren und zu validieren.

## C. Freshness-Regel

Vor Implementierungsbeginn wird geprüft, ob der beigefügte Repository-Snapshot noch der aktive Stand ist. Bei Abweichung:

1. neuen Checkout binden;
2. Trait-, Crate- und Formatdelta erfassen;
3. dieses Kit als Zielvertrag beibehalten;
4. Pfad- und API-Annahmen versioniert aktualisieren;
5. keine ältere Repositoryform über die neue erzwingen.
