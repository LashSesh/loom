# MTSF-CHR-T4W v1.0 - Implementation Kit

Dieses Paket ist der kanonische Projekt- und Implementierungsbausatz für die erste vollständige Domäneninstanz des Projektiven Chronovisors auf dem **BMMR-T4W**. Es führt vier bereits fixierte Systeme zusammen, ohne sie zu verschmelzen:

1. **BMMR-T4W** als Vorwärtsgenerator, Ground-Truth-Workbody und Zielontologie.
2. **Vektor-Theremin** als aktive, kontinuierliche Beobachtungs- und Sondenpolitik.
3. **MTSF-CHR** als inverse temporale Rekonstruktionssemantik.
4. **CCE/PHC/LOOM** als einzige normative Gate-, Transport-, Ausführungs-, Container- und Replaygeometrie.

Die Zielgleichung lautet:

```text
T4W-Run -> verdeckte Evidenzprojektion -> adaptive Vektor-Sonden ->
CHR-Rekonstruktion -> CCE-Gates -> PHC/LOOM-Materialisierung ->
Reanalyse -> blinder Ground-Truth-Vergleich
```

## Verbindliche Leseordnung

1. `docs/MTSF_CHR_T4W_Masterrahmen_v1_0.pdf`
2. `TARGET_IDENTITY.yaml`
3. `ARCHITECTURE_CONTRACT.md`
4. `IMPLEMENTATION_BLUEPRINT.md`
5. `REPOSITORY_INTEGRATION_PLAN.md`
6. `TEST_AND_VALIDATION_PLAN.md`
7. `DEFINITION_OF_DONE.md`
8. `RESOURCE_INTAKE.md`
9. `machine/` und `scaffold/`
10. erst danach die Agentenprompts in `prompts/`

## Status

Das Paket ist eine **implementierungsreife Integrationsspezifikation**, keine Behauptung, dass die Implementation bereits existiert oder empirisch validiert ist. Ein grüner synthetischer Roundtrip beweist Systemkohärenz und Rekonstruktionsfähigkeit innerhalb der registrierten Modellklasse; er beweist weder physische G2-Thermodynamik noch Marktvorteil.

## Arbeitsmodus

- Der bestehende LOOM/CCE-Kern wird nicht neu entworfen.
- Phase 1 ist eine horizontale Domänenintegration über `DomainAdapter`.
- Eine CoreExtension ist gesperrt, bis ein reproduzierbares Ausdrucksdefizit vorliegt.
- Das vorhandene T4W-Referenzprogramm ist als externes Ground-Truth-Orakel einzubinden, sofern die Originalquellen verfügbar sind.
- Sämtliche offenen Punkte werden als Residuen geführt; keine Lücke wird rhetorisch geschlossen.
