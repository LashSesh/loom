# Architekturvertrag MTSF-CHR-T4W v1.0

## 1. Systemgrenze

Die Domäneninstanz rekonstruiert Zustände, Ereignisse, Parameter und Steuerungen eines BMMR-T4W-Laufs aus partieller Evidenz. Der vollständige Lauf bleibt bis zur Auswertung verborgen. Die Implementation muss zwischen **Generator**, **Beobachtungsmodell**, **Sondenpolitik**, **Rekonstrukteur**, **Closure-Verfassung** und **Darstellung** unterscheiden.

## 2. Kanonische Operatorfolge

```text
G_T4W -> O_Q -> E -> V_select -> R_CHR -> C_CHR-T4W ->
CCE -> PHC -> LOOM -> Artifact -> Reanalyze -> C' -> BlindCompare
```

- `G_T4W`: deterministischer oder registriert stochastischer Vorwärtsgenerator.
- `O_Q`: durch eine Sondenfamilie parametrisierte Beobachtungsoperatoren.
- `E`: content-addressierte, zeit- und provenienzgebundene Evidenz.
- `V_select`: aktive Sondenwahl nach Informationsgewinn, Kosten und Störwirkung.
- `R_CHR`: inverse Rekonstruktion als Historienquotient, nicht als ungeprüfte Einzelerzählung.
- `CCE`: harte Gates, sichtbare Residuen, Trace und Roundtrip.
- `PHC/LOOM`: lokale Projektionen, Workcells, Materialisierung und `.loom`-Replay.

## 3. Zustands- und Typtrennung

Folgende Typen dürfen nicht ineinander kollabieren:

- `GroundTruthState` - nur Generator und blinder Evaluator.
- `ObservedEvidence` - tatsächlich bereitgestellte Spur.
- `DerivedFeature` - aus Evidenz berechnete Größe.
- `HistoryCandidate` - modellkompatible Hypothese.
- `HistoryEquivalenceClass` - unter der Evidenz nicht unterscheidbare Kandidaten.
- `CounterfactualBranch` - Interventionsergebnis.
- `ProspectiveBranch` - bedingte Zukunft.
- `RenderElement` - ausschließlich Projektion eines bereits typisierten Crystal-Inhalts.

## 4. Numerische Firewall

Der T4W-Simulator darf für nichtsignaturrelevante Numerik `f64` verwenden. Kanonische Identität, Hashes, Gates und Replay dürfen nicht von plattformabhängigen Floatbytes abhängen. Jeder numerische Wert erhält:

- Typ und Geltungsstufe,
- Einheit oder explizite Dimensionslosigkeit,
- Quantisierung/Skala im Run Descriptor,
- deterministische kanonische Darstellung,
- Toleranzvertrag für Äquivalenz.

Empfohlene kanonische Form:

```text
CanonicalScalar { mantissa: i128, scale10: i32, unit: UnitTag, status: ProofStatus }
```

## 5. Blindheitsvertrag

Während der Rekonstruktion darf kein Pfad auf Ground Truth zugreifen. Ground Truth liegt in einem separaten Evaluation Artifact oder Prozess. Der Reconstructor erhält ausschließlich Evidenz, Modellklasse, Constraints und zulässige Sonden. Jeder unzulässige Zugriff ist `ground_truth_leakage` und muss den Run blockieren.

## 6. Aktive Sonden

Eine Sonde ist entweder:

- **passiv**: wählt Projektion, Fenster, Route oder Messmodus ohne Zustandsänderung;
- **aktiv**: setzt eine deklarierte Intervention und bilanziert Kosten, Störwirkung und Kausalität.

Ein ProbeRequest muss `kind`, `target`, `window`, `route`, `phase`, `cost_budget`, `disturbance_budget`, `expected_information_gain` und `authorization` binden.

## 7. Repositoryvertrag

Die Supplied-Repo-Version führt `DomainAdapter` mit 11 Pflichtpunkten in `cce-materialize`. Phase 1 implementiert MTSF-CHR-T4W als horizontale Domäneninstanz. Die konkrete Dateiposition wird gegen den aktiven Repositorystand verifiziert. Direkte Änderungen an generierten Katalogdateien sind verboten; eine spätere Katalogpromotion erfolgt über die normative Quelle und ihren Generator.

## 8. Closurebegriff

```text
ClosedCHR_T4W = 1
```

gilt nur, wenn Adapter-Parität, Domain-Gates, Reference-Cubes, Negative-Cubes, Replay, Reanalyse, sichtbare Residuen und Blindvergleich erfüllt sind. Closure behauptet Modell- und Evidenzkohärenz. Sie behauptet keine physische G2-Thermodynamik und keine Marktprofitabilität.
