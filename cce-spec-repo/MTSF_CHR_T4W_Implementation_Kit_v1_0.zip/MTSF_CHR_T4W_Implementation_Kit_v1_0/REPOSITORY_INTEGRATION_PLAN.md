# Repository-Integrationsplan

## 1. Grounding des gelieferten Snapshots

Im bereitgestellten LOOM/CCE-Snapshot befindet sich der typstarke `DomainAdapter` in:

```text
cce/crates/cce-materialize/src/adapter.rs
```

Er verlangt 11 Punkte: Wunschschema, Kanonisierung, PHC-Encode, LOOM-Weave, Materialisierung, Reanalyse, Äquivalenz, Gates, Residuen/Counter-Horizon, native Ausgabe und Test-Assets. Der neue Adapter muss `check_adapter_parity_typed` bestehen.

## 2. Minimal-invasive Einfügung

Phase 1:

- neues Modul `mtsf_chr_t4w` unter `cce-materialize`;
- keine Änderung an `cce-core`-Objekten;
- keine Änderung am `.loom`-Format;
- vorhandene PHC-, Weave-, Gate-, Ledger- und Replaytypen wiederverwenden;
- neue Daten als Domain-Payloads in vorhandenen Segmenten abbilden;
- Feature-Flag oder expliziter Domain-Selector, falls der Runner dies vorsieht.

## 3. Katalogstatus

Der Snapshot enthält einen generierten 213-Domänen-Katalog. Dieser darf nicht direkt editiert werden. Vorgehen:

1. Adapter zunächst als **unpromoted research profile** implementieren.
2. Reference- und Negative-Cubes sowie ClosedCCE-Roundtrip schließen.
3. danach ein append-only Spec-Amendment für den Katalog erzeugen;
4. Registry über den vorhandenen Generator neu erzeugen;
5. Produkt-Level zunächst PL0/PL1, Aufstieg ausschließlich durch Zeugen.

## 4. Abhängigkeitsrichtung

Das neue Modul darf von vorhandenen Kern-, PHC-, LOOM- und Observe-Crates abhängen. Der Kern darf nicht vom neuen Modul abhängen. Dadurch bleibt die Crate-DAG azyklisch.

## 5. Numerik

- Simulation intern: registrierte Gleitkommanumerik zulässig.
- Kanonisierung: quantisierte, deterministische Repräsentation.
- Run Descriptor bindet Solver, Schrittweite, Toleranzen, Quantisierung, Seed, Reihenfolge und Hardware-unabhängige Vergleichsregeln.
- Reanalyse vergleicht kanonische Klassen, nicht rohe Floatbytes.

## 6. `.loom`-Abbildung

Keine neuen Segmente in Phase 1. Empfohlene Nutzung vorhandener Klassen:

- Evidence: Beobachtungen, ProbeResponses, Ground-Truth-Digest ohne Inhalt;
- PHC: Achsen, Zellen, Projektionen und Workcells;
- GateReports: CHR-/T4W-/Blindheitsgates;
- Residue: offene Historien, Observabilitätslücken, Modellmissspezifikation;
- Ledger: Probe-, Candidate-, Gate-, Commit- und Evaluationsevents;
- ReplayManifest: Solver-, Seed-, Quantisierungs- und Modellbindung;
- CandidateOutputs/Domain payload: ChrT4wCrystal und ChronoView.

## 7. Merge- und Commitdisziplin

Jede Implementierungsphase erzeugt:

- Code und Tests;
- `PHASE_REPORT.md`;
- aktualisierte Traceability;
- neues/geschlossenes Residuum;
- keine semantische Umdeutung ohne Versionssprung.

## 8. CoreExtension-Sperre

Eine CoreExtension ist erst zulässig, wenn alle folgenden Bedingungen erfüllt sind:

1. ein erforderlicher CHR-T4W-Inhalt kann mit vorhandenen Domain-Payload-, Evidence-, Residue-, Gate- und Ledgertypen nicht verlustfrei dargestellt werden;
2. das Defizit ist durch einen minimalen failing test reproduzierbar;
3. eine Domain-only-Lösung ist nachweislich unmöglich oder semantisch falsch;
4. die Erweiterung ist für mindestens eine zweite Domäne wiederverwendbar oder als ausdrücklich domänenspezifischer Extension-Port vorgesehen;
5. der normative S14-Pfad des Repositories wird eingehalten.
