# Implementierungsblueprint

## A. Funktionskerne

### A1 - T4W Forward Core

Verantwortet:

- `Q4 = {0,1}^4`, Zellbestand, Randoperator und primitive Facettenpfade;
- bistabiles Phasenfeld und gekoppelte Relaxation;
- externen Drive und Bilanz `DeltaF = Wext - D + Rnum`;
- konservierten Trägerfluss und Speicherfunktional;
- vollständige Ground-Truth-Trajektorie und Trace.

### A2 - Evidence Projector

Erzeugt aus Ground Truth kontrollierte Beobachtungsregime:

- vollständige/partielle Zustandsprojektion;
- zeitliche Intervalle und verzögerte Messungen;
- Rauschen, Dropouts und abhängige Quellen;
- verdeckte Drives/Parameter;
- gültige und ungültige negative Evidenz;
- versionierte Sensor- und Beobachtungsmodelle.

### A3 - Vector Probe Engine

Implementiert:

- passive Projektionen;
- deklarierte aktive Interventionen;
- 4pi-Phase/Parität als Scan- und Replayindex;
- G13-Routerpfade;
- Informationsgewinn-, Kosten- und Störungsbewertung;
- adaptive Sondenwahl und Stop/Hold-Regeln.

### A4 - CHR Reconstructor

Implementiert progressiv:

1. Zustandsrekonstruktion;
2. Ereignis- und Regimeerkennung;
3. Drive-Rekonstruktion;
4. Parameteridentifikation;
5. Generator-/Policy-Hypothesen;
6. Historienäquivalenz;
7. Zukunfts- und Kontrafaktikkegel.

### A5 - DomainAdapter und Materialisierung

Liefert die 11 Pflichtpunkte des Repository-Traits, Domain-Gates, Residuen, Reference-/Negative-Cubes, ChronoView und Roundtrip.

## B. Modellklassenleiter

- `M0 ExactKnown`: Dynamik und Parameter bekannt, Zustand partiell beobachtet.
- `M1 ParameterUnknown`: Struktur bekannt, ausgewählte Parameter latent.
- `M2 DriveUnknown`: externe Drives und Umschaltzeiten latent.
- `M3 TopologyUnknown`: Kanten/Seams/Leitfähigkeiten teilweise latent.
- `M4 StochasticRegistered`: registrierte Übergangsraten und Zufallsquelle.
- `M5 AdapterEmpirical`: reale Domänendaten, Ground Truth nur partiell.

Keine Stufe darf übersprungen werden. M5 darf erst nach stabiler M0-M4-Konformität begonnen werden.

## C. Modulplan im vorhandenen Repository

Grounded auf dem gelieferten Snapshot:

```text
cce/crates/cce-materialize/src/mtsf_chr_t4w/
  mod.rs
  model.rs
  canon.rs
  forward.rs
  evidence.rs
  probe.rs
  router.rs
  reconstruct.rs
  gates.rs
  residues.rs
  projections.rs
  weave.rs
  render.rs
  reference.rs
  negative.rs

cce/conformance/tests/
  mtsf_chr_t4w_reference.rs
  mtsf_chr_t4w_negative.rs
  mtsf_chr_t4w_roundtrip.rs
  mtsf_chr_t4w_blindness.rs
  mtsf_chr_t4w_baselines.rs
```

Die endgültige Position muss gegen den aktiven Checkout verifiziert werden. Eine spätere Extraktion generischer Teile in eigene Crates ist nur nach wiederholter Nutzung in mindestens zwei unabhängigen Domänen zulässig.

## D. PHC-Achsen

Mindestens:

```text
time, t4w_mode, cell, phase_fraction, carrier, drive, policy,
evidence_origin, epistemic_status, probe, router, scan_phase, parity,
hypothesis, closure, branch, evaluation_split
```

## E. Workcell-Weave

```text
IngestCase
-> CanonicalizeRunDescriptor
-> GenerateOrLoadGroundTruth
-> ProjectEvidence
-> BindProvenance
-> InferPartialTime
-> BuildRouterProfile
-> PlanInitialProbes
-> ExecuteProbes
-> GenerateCandidates
-> PropagateT4WConstraints
-> DisintegrateCandidates
-> QuotientHistories
-> ReconstructStateAndGenerator
-> ProjectFuture
-> BuildChrT4wCrystal
-> RunDomainGates
-> EncodePHC
-> LOOMWeave
-> MaterializeChronoView
-> Reanalyze
-> BlindEvaluate
-> SealOrHold
```

## F. Algorithmische Priorität

1. deterministische Referenzfälle vor Optimierung;
2. exakte Enumeration kleiner Systeme als Orakel;
3. erst danach Beam Search/SMC/MCMC/Variational Inference;
4. jede Approximation gegen das kleine exakte Orakel prüfen;
5. Performanceverbesserung darf Gate- oder Residuenverhalten nicht verändern.

## G. Zwei Betriebsprofile

- `preview_hold`: schnell, approximativ, kein Closurezertifikat.
- `certified_closed`: vollständige Gates, Replay, Reanalyse und Blindvergleich.

Beide Profile verwenden denselben Crystal; nur der Nachweisumfang unterscheidet sich.
