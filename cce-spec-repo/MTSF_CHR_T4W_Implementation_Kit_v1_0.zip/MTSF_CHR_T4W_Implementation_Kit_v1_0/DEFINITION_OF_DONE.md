# Definition of Done - MTSF-CHR-T4W v1.0

```text
DoD_CHR_T4W = 1 iff
  ResourceIntegrity
  and TargetIdentityFrozen
  and DomainAdapterParity_11_of_11
  and T4WForwardParity
  and EvidenceProjectionDeterministic
  and GroundTruthBlindness
  and VectorProbeContract
  and ReconstructionSoundness
  and T4WInvariantGates
  and CHRTemporalGates
  and ReferenceCubesGreen
  and NegativeCubesBlocked
  and BaselineAndAblationReports
  and PHC_LOOM_Conformance
  and ReplayClassIdentity
  and ReanalysisClassIdentity
  and VisibleResidues
  and NoCoreRegression
```

## Abhakliste

- [ ] Aktiver Repositorystand inventarisiert und Digest gebunden.
- [ ] Alle Pflichtquellen vorhanden oder als blockierendes Residuum registriert.
- [ ] `ChrT4wCrystal`, `ChrT4wWeave`, `ChrT4wArtifact` typisiert.
- [ ] T4W-Vorwärtskern besitzt Differential- oder Reimplementierungsparität.
- [ ] Ground-Truth- und Reconstruction-Pfade technisch getrennt.
- [ ] Mindestens Modellklassen M0-M3 implementiert und getestet.
- [ ] Passive und aktive ProbeRequests getrennte Typen.
- [ ] Adaptive Probeauswahl hat Kosten-/Störungsbudget und Hold-Regel.
- [ ] G13-Routerprofil exakt, versioniert und nicht als Gesamtontologie behandelt.
- [ ] Sämtliche T4W- und CHR-Gates fail-closed.
- [ ] Historienäquivalenz bleibt sichtbar; keine erzwungene Singleton-Ausgabe.
- [ ] Zukunft, Kontrafaktik und Vergangenheit typgetrennt.
- [ ] Reference-Cubes R1-R7 grün.
- [ ] Negative-Cubes N1-N24 am vorgesehenen Gate blockiert.
- [ ] Exakter Tiny-Benchmark dient als Orakel für Approximationen.
- [ ] Baselinevergleich und Ablationen reproduzierbar.
- [ ] PHC encode/project und LOOM weave/materialize funktionieren.
- [ ] `.loom` verify/mount/replay besteht ohne neues Formatsegment.
- [ ] Reanalyse fällt auf dieselbe kanonische Crystal-Klasse zurück.
- [ ] Blindvergleich enthält State-, Event-, Parameter-, Coverage- und Overclaimmetriken.
- [ ] Preview/Hold und Certified/Closed sind getrennte Betriebsprofile.
- [ ] Kein Physik-, Profitabilitäts- oder Universalitätsclaim aus synthetischer Evidenz.
- [ ] Keine CCE-Core-Regression, keine direkte Registry-Editierung.
- [ ] Abschlussbericht enthält jedes offene Residuum.

## Ausdrücklich außerhalb der ersten DoD

- physische G2-Kalibrierung in Joule/Kelvin/Sekunden;
- Live-Trading oder Kapitalallokation;
- Hardware-Vektor-Theremin;
- allgemeine neue `.loom`-Segmente;
- Promotion in den kanonischen 213-Domänen-Katalog;
- Behauptung universeller Sondenoptimalität;
- Vollausbau realer Domänenadapter.
