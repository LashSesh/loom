# Nichtproduktives Implementierungsscaffold

Dieser Ordner ist eine Typ- und Dateistrukturhilfe. Er ist absichtlich unvollständig und darf nicht als implementierter Adapter ausgegeben werden. Der Coding-Agent überträgt die Dateien in die gegen den aktiven Repositorystand verifizierten Pfade und ersetzt alle `unimplemented!()`-Stellen durch nachgewiesene Implementation plus Tests.
