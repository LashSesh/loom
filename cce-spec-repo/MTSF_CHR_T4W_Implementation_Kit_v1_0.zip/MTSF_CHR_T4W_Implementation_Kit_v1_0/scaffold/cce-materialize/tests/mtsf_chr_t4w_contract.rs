// This file defines the intended test groups. The active repository path and imports
// must be resolved by the coding agent.

#[test]
#[ignore = "contract scaffold - implement in work package P8"]
fn reference_cubes_r1_to_r7_are_green() { unimplemented!() }

#[test]
#[ignore = "contract scaffold - implement in work package P8"]
fn negative_cubes_n1_to_n24_are_blocked() { unimplemented!() }

#[test]
#[ignore = "contract scaffold - implement in work package P7"]
fn phc_loom_reanalysis_preserves_canonical_class() { unimplemented!() }

#[test]
#[ignore = "contract scaffold - implement in work package P9"]
fn reconstruction_has_no_ground_truth_read_path() { unimplemented!() }
