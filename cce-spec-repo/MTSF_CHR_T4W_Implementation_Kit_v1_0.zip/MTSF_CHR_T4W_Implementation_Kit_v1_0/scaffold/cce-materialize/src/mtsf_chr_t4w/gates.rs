//! Contract scaffold for gates.
//! Replace with tested implementation; do not mark complete while unimplemented.

pub fn contract_placeholder() -> ! {
    unimplemented!("gates implementation is a required work package")
}
