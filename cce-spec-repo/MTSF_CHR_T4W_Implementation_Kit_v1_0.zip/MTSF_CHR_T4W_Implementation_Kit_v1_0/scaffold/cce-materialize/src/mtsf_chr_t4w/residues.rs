//! Contract scaffold for residues.
//! Replace with tested implementation; do not mark complete while unimplemented.

pub fn contract_placeholder() -> ! {
    unimplemented!("residues implementation is a required work package")
}
