pub mod canon;
pub mod evidence;
pub mod forward;
pub mod gates;
pub mod model;
pub mod negative;
pub mod probe;
pub mod projections;
pub mod reconstruct;
pub mod reference;
pub mod residues;
pub mod router;
pub mod render;
pub mod weave;

// Implement DomainAdapter only after the current repository trait has been verified.
