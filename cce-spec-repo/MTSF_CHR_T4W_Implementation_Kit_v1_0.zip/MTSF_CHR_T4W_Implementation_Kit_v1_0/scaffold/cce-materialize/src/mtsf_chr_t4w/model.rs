#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CanonicalScalar {
    pub mantissa: i128,
    pub scale10: i32,
    pub unit: String,
    pub status: ProofStatus,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProofStatus { Defined, Derived, Implemented, External, ModelSpecific, Open, Refuted }

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct T4wMode(pub [bool; 4]);

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct T4wState {
    pub time: CanonicalScalar,
    pub mode: T4wMode,
    pub phase: Vec<CanonicalScalar>,
    pub carrier: Vec<CanonicalScalar>,
    pub thermostat: Vec<CanonicalScalar>,
    pub drive: Vec<CanonicalScalar>,
    pub run_descriptor: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ChrT4wCrystal {
    pub case_id: String,
    pub evidence_ids: Vec<String>,
    pub history_classes: Vec<String>,
    pub future_branches: Vec<String>,
    pub probe_ids: Vec<String>,
    pub residues: Vec<String>,
    pub certificates: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ChrT4wWeave { pub workcell_ids: Vec<String> }
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ChrT4wArtifact { pub chronoview_json: Vec<u8>, pub report_bytes: Vec<u8> }
