# Test- und Validierungsplan

## 1. Prüfarten

1. **Unit Tests** für Formeln, Typen und Gates.
2. **Property Tests** für Invarianten und Kanonisierung.
3. **Differential Tests** gegen den vorhandenen T4W-Referenzkern.
4. **Reference-Cubes** als positive End-to-End-Zeugen.
5. **Negative-Cubes** als verpflichtende Blockierfälle.
6. **Blind Reconstruction Benchmarks** mit separater Ground Truth.
7. **Baseline-Vergleiche** gegen HMM/State-Space-Smoother, Process Mining, Causal Discovery und einfache Filter.
8. **Ablationen** der CHR-Kanäle, des Routers, der aktiven Sonden und der 4pi-Parität.
9. **Replay/Container Tests** über PHC/LOOM/.loom.
10. **Performance Tests** mit unverändertem semantischem Ergebnis.

## 2. Benchmarkleiter

### B0 - Exact Tiny

Kleine Graphen und kurze Läufe; vollständige Kandidatenenumeration. Dient als mathematisches Orakel.

### B1 - Partial State

Parameter und Drives bekannt; nur Teile von `q`, `r` und `Q4` sichtbar.

### B2 - Hidden Drive

Umschaltzeit und Amplitude des externen Drives unbekannt.

### B3 - Hidden Parameters

Ausgewählte `A_i`, `M_i`, `J_ij`, `L_ij` oder `C_i` latent.

### B4 - Mixed Ambiguity

Mehrere evidenzäquivalente Historien müssen als Klasse erhalten bleiben.

### B5 - Active Probe

Adaptive Sonde muss weniger Evidenzkosten benötigen als eine feste Sondenfolge bei gleicher Rekonstruktionsgüte.

### B6 - Stochastic Registered

Registrierte Seeds/Übergangsraten; probabilistische Kalibrierung und Coverage.

### B7 - Real Adapter Shadow

Erst nach B0-B6: reale, versionierte Domänendaten im Shadowbetrieb.

## 3. Kernmetriken

- State RMSE/MAE auf verborgenem Zustand.
- Mode accuracy und primitive-transition F1.
- Parameterfehler und identifizierbare Parameterdimension.
- Historienklassen-Coverage: enthält die wahre Historie die ausgegebene Klasse?
- Overclaim rate: singleton behauptet, obwohl Ambiguität besteht.
- Negative-Witness precision/recall.
- Probe information gain pro Kosten- und Störungseinheit.
- ReplayFidelity und Roundtrip-Fidelity.
- Residue completeness.
- Wall time, Peak Memory, Candidate Count, Workcell Parallel Efficiency.

## 4. Blindheitsprüfung

- Ground Truth in separatem Prozess/Dateibaum.
- Reconstructor-User darf den Pfad nicht lesen.
- OS-/Test-Harness prüft Dateizugriffe.
- Ground-Truth-Digest darf vor Abschluss gebunden werden, aber Inhalt bleibt unzugänglich.
- Evaluation wird erst nach Seal/Hold des Rekonstruktionsartifacts ausgeführt.

## 5. Statistische Kalibrierung

Für probabilistische Ausgaben:

- Coverage von Credible Sets;
- Calibration Error;
- proper scoring rules;
- getrennte Train/Validation/Test-Splits;
- Seed- und Hyperparameterbindung im Run Descriptor;
- keine Auswahl des besten Test-Runs nach Sichtung.

## 6. Ablationen

Mindestens:

- ohne negativen Evidenzkanal;
- ohne Desintegrationsledger;
- ohne aktive Sondenwahl;
- ohne G13-Routingprofil;
- ohne 4pi-Paritätsindex;
- ohne Quellenabhängigkeitsmodell;
- ohne Reanalyse;
- ohne T4W-Invarianten;
- mit fester versus adaptiver Probe;
- exakte versus approximative Rekonstruktion.

## 7. Akzeptanz

Ein Feature ist nur fertig, wenn positiver Zeuge, negativer Zeuge, Replay und Traceability vorhanden sind. Ein statistisch besserer Score ersetzt kein hartes Gate.
